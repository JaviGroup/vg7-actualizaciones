<?php
/**
 * /llms.txt: resumen del sitio en Markdown para los modelos de lenguaje y los agentes de IA (https://llmstxt.org/).
 *
 * Lighthouse (categoría "Navegación agéntica") lo pide y comprueba que sea Markdown con un título H1, algún enlace y una extensión razonable.
 * Se sirve desde WordPress (no hace falta crear ningún archivo ni actualizar los enlaces permanentes); si algún día se sube un llms.txt real a la
 * raíz del sitio, el servidor lo entrega primero. El texto sale de Datos del sitio y de las páginas que existan; se puede cambiar con el filtro
 * vgm_llms_txt. No lleva precios ni plazos (cambian en los bloques y quedarían desactualizados).
 */

defined( 'ABSPATH' ) || exit;

/**
 * Contenido del llms.txt.
 *
 * @return string
 */
function vgm_llms_txt() {
	$clean = function ( $text ) {
		return trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $text ) ) );
	};

	$name    = $clean( get_bloginfo( 'name' ) );
	$lines   = array();
	$lines[] = '# ' . ( '' !== $name ? $name : 'Viva Marketing' );
	$lines[] = '';
	$lines[] = '> ' . rtrim( $clean( vg7_opt( 'footer_text' ) ), '.' ) . '. Internet ultra rápido y televisión para el hogar, con soporte en español.';
	$lines[] = '';
	$lines[] = 'Cuatro planes de internet residencial (Viva Lite desde 300 Mbps, Viva Plus y Viva Pro desde 500 Mbps y Viva Infinity desde 1000 Mbps). Para conocer los precios vigentes y confirmar la cobertura en una dirección, usa el formulario de contacto o el teléfono.';
	$lines[] = '';
	$lines[] = '## Páginas';
	$lines[] = '';
	$lines[] = '- [Inicio](' . esc_url_raw( home_url( '/' ) ) . '): qué ofrece el servicio, los planes, las opiniones de los clientes y cómo contratar en cuatro pasos.';

	$pages = array(
		'planes'   => array( 'Planes', 'los cuatro planes con su velocidad, precio y ventajas, cómo contratar y las preguntas frecuentes.' ),
		'contacto' => array( 'Contacto', 'formulario para pedir información y consultar cobertura, con teléfono y correo.' ),
	);
	foreach ( $pages as $slug => $page ) {
		if ( get_page_by_path( $slug ) ) {
			$lines[] = '- [' . $page[0] . '](' . esc_url_raw( home_url( '/' . $slug . '/' ) ) . '): ' . $page[1];
		}
	}

	$phone = $clean( vg7_opt( 'phone' ) );
	$email = $clean( vg7_opt( 'email' ) );
	if ( '' !== $phone || '' !== $email ) {
		$lines[] = '';
		$lines[] = '## Contacto';
		$lines[] = '';
		if ( '' !== $phone ) {
			$lines[] = '- Teléfono: ' . $phone;
		}
		if ( '' !== $email ) {
			$lines[] = '- Correo: ' . $email;
		}
	}

	return (string) apply_filters( 'vgm_llms_txt', implode( "\n", $lines ) . "\n" );
}

/**
 * Entrega /llms.txt cuando WordPress no encontró otra cosa en esa dirección (respeta instalaciones en una subcarpeta).
 */
function vgm_servir_llms_txt() {
	if ( ! is_404() ) {
		return;
	}
	$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- solo se compara con una ruta fija.
	$base = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
	if ( $base . '/llms.txt' !== $path ) {
		return;
	}
	status_header( 200 );
	header( 'Content-Type: text/markdown; charset=utf-8' );
	header( 'Cache-Control: public, max-age=3600' );
	echo vgm_llms_txt(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- texto plano (Markdown); cada dato se limpia arriba.
	exit;
}
add_action( 'template_redirect', 'vgm_servir_llms_txt', 1 );
