<?php
/**
 * Sprite de iconos del sitio (los mismos trazos del diseño aprobado, ids con prefijo "i-"). Se imprime una vez al abrir el body;
 * el header, el footer y los bloques los usan con <svg class="ico"><use href="#i-check"/></svg> (o vgm_icon() del plugin de bloques).
 * Los trazos los pone la clase .ico (base.css). El plugin de bloques puede añadir símbolos con el filtro vgm_sprite_symbols.
 * Los íconos de redes (fb, ig, tt, yt, in, x-logo, wa) se llaman igual que los de vg7_social_links() del tema padre.
 * El degradado #g-dial lo usa el arco del velocímetro de planes.
 */

defined( 'ABSPATH' ) || exit;

function vgm_sprite() {
	echo vgm_sprite_html(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema.
}
add_action( 'wp_body_open', 'vgm_sprite', 1 );

/**
 * Markup del sprite (los bloques lo incluyen en la vista previa del editor, que es otro documento).
 */
function vgm_sprite_html() {
	$f       = 'fill="currentColor" stroke="none"';
	$symbols = apply_filters(
		'vgm_sprite_symbols',
		array(
			'arrow'  => '<path d="M5 12h14M13 6l6 6-6 6"/>',
			'down'   => '<path d="M12 5v14M6 13l6 6 6-6"/>',
			'check'  => '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
			'phone'  => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
			'mail'   => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
			'doc'    => '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/>',
			'play'   => '<circle cx="12" cy="12" r="9.5"/><path d="M10 8.5v7l6-3.5z"/>',
			'bolt'   => '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
			'tag'    => '<path d="M3 4h8l10 10-7 7L4 11z"/><circle cx="8" cy="8" r="1.4"/>',
			'chat'   => '<path d="M21 12a8.5 8.5 0 0 1-12.3 7.6L3.5 21l1.4-4.6A8.5 8.5 0 1 1 21 12z"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01"/>',
			'home'   => '<path d="M3 11 12 3l9 8M5 9.5V21h14V9.5M10 21v-6h4v6"/>',
			'star'   => '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
			'fb'     => '<path d="M14.5 8H17V4.5h-2.5A4.5 4.5 0 0 0 10 9v2.5H7.5V15H10v6h3.5v-6h2.7l.8-3.5h-3.5V9.2c0-.7.5-1.2 1-1.2z"/>',
			'ig'     => '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".8" fill="currentColor"/>',
			'yt'     => '<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="m10 9.5 5 2.5-5 2.5z"/>',
			'tt'     => '<path d="M14 3v11.5a3.5 3.5 0 1 1-3.5-3.5"/><path d="M14 3c.3 2.4 1.9 4.2 4.5 4.5"/>',
			'in'     => '<path ' . $f . ' d="M6.5 8H3.8v12h2.7zM5.1 3.5A1.6 1.6 0 1 0 5.1 6.7a1.6 1.6 0 0 0 0-3.2zM20.2 20h-2.7v-6c0-1.5-.6-2.2-1.7-2.2-1 0-1.7.7-1.7 2.2v6h-2.7V8h2.6v1.2a3.3 3.3 0 0 1 2.8-1.4c2 0 3.4 1.3 3.4 4z"/>',
			'x-logo' => '<path ' . $f . ' d="M17.8 3h3.1l-6.8 7.8 8 10.2h-6.3l-4.9-6.4L5.3 21H2.2l7.3-8.3L1.9 3h6.4l4.4 5.9zm-1.1 16.2h1.7L7.4 4.7H5.6z"/>',
			'wa'     => '<path ' . $f . ' d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm5.3 14.1c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.3-.3.6-.3.8-.3h.6c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .5l-.3.5-.4.4c-.1.1-.3.3-.1.6.2.3.7 1.2 1.6 1.9 1.1.9 2 1.2 2.3 1.4.3.1.5.1.6-.1l.9-1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.3z"/>',
		)
	);
	$out = '<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><defs><linearGradient id="g-dial" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#66D097"/><stop offset="1" stop-color="#F8B93F"/></linearGradient></defs>';
	foreach ( $symbols as $id => $markup ) {
		$out .= '<symbol id="i-' . esc_attr( $id ) . '" viewBox="0 0 24 24">' . $markup . '</symbol>';
	}
	return $out . '</svg>';
}
