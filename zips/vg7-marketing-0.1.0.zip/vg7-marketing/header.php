<?php
/**
 * Header de Viva Marketing: logo, menú, botón de llamada y barra de avance; en móvil, hoja a pantalla completa con enlaces grandes numerados.
 * Los datos salen de Apariencia → Personalizar → Datos del sitio y el menú de Apariencia → Menús.
 */

defined( 'ABSPATH' ) || exit;

$vgm_menu  = vg7_menu_tree( 'principal' );
$vgm_phone = vg7_opt( 'phone' );
$vgm_plink = vg7_opt( 'phone_link' );
$vgm_email = vg7_opt( 'email' );
$vgm_cta   = vg7_opt( 'cta_label' );
$vgm_cta   = $vgm_cta ? $vgm_cta : __( 'Llámanos', 'vg7-marketing' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="pg-curtain" aria-hidden="true"></div>
<a class="skip" href="#principal"><?php esc_html_e( 'Saltar al contenido', 'vg7-marketing' ); ?></a>

<header class="site-header" data-tono="bosque">
	<div class="hd-in">
		<?php echo vg7_logo(); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vg7_logo(). ?>

		<nav class="hd-nav" id="menu" aria-label="<?php esc_attr_e( 'Principal', 'vg7-marketing' ); ?>">
			<?php if ( $vgm_menu ) : ?>
				<ul class="hd-links">
					<?php foreach ( $vgm_menu as $vgm_i => $vgm_item ) : ?>
						<?php $vgm_on = vgm_es_actual( $vgm_item['url'] ); ?>
						<li style="--k:<?php echo (int) $vgm_i; ?>"><a<?php echo $vgm_on ? ' class="is-on" aria-current="page"' : ''; ?> href="<?php echo esc_url( $vgm_item['url'] ); ?>"><span class="hd-n" aria-hidden="true"><?php echo esc_html( str_pad( (string) ( $vgm_i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><?php echo esc_html( $vgm_item['title'] ); ?><svg class="ico" aria-hidden="true" focusable="false"><use href="#i-arrow"/></svg></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<div class="hd-extra">
				<?php if ( $vgm_phone && $vgm_plink ) : ?>
					<a class="btn hd-extra-call" style="--k:<?php echo (int) count( $vgm_menu ); ?>" href="<?php echo esc_url( $vgm_plink, array( 'tel', 'http', 'https' ) ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="menu_movil"><span><?php echo esc_html( $vgm_phone ); ?></span><span class="btn-ar"><svg class="ico" aria-hidden="true" focusable="false"><use href="#i-phone"/></svg></span></a>
				<?php endif; ?>
				<?php if ( $vgm_email ) : ?>
					<a class="hd-extra-mail" style="--k:<?php echo (int) count( $vgm_menu ) + 1; ?>" href="<?php echo esc_url( 'mailto:' . $vgm_email, array( 'mailto' ) ); ?>"><?php echo esc_html( $vgm_email ); ?></a>
				<?php endif; ?>
			</div>
		</nav>

		<?php if ( $vgm_phone && $vgm_plink ) : ?>
			<a class="btn hd-call" href="<?php echo esc_url( $vgm_plink, array( 'tel', 'http', 'https' ) ); ?>" aria-label="<?php echo esc_attr( $vgm_cta . ': ' . __( 'llamar al', 'vg7-marketing' ) . ' ' . $vgm_phone ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="header"><span><?php echo esc_html( $vgm_cta ); ?></span><span class="btn-ar"><svg class="ico" aria-hidden="true" focusable="false"><use href="#i-phone"/></svg></span></a>
		<?php endif; ?>
		<button class="hd-burger" type="button" aria-expanded="false" aria-controls="menu" aria-label="<?php esc_attr_e( 'Abrir menú', 'vg7-marketing' ); ?>"><span></span><span></span></button>
	</div>
	<i class="hd-progress" aria-hidden="true"></i>
</header>
