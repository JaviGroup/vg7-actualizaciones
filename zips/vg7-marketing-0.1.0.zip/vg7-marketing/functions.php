<?php
/**
 * VG7 Marketing: tema hijo de Viva Marketing (viva-marketing.net).
 *
 * Aquí solo va lo de la marca: datos y menús por defecto, estilos base, fuentes locales, header y footer.
 * Los bloques (secciones) están en el plugin vg7-marketing-bloques; los formularios usan el motor del tema padre.
 * Diseño aprobado: disenos/viva-marketing/ (Home, Planes y Contacto).
 */

defined( 'ABSPATH' ) || exit;

define( 'VGM_VERSION', '0.1.0' );
define( 'VGM_DIR', get_stylesheet_directory() );
define( 'VGM_URL', get_stylesheet_directory_uri() );

require_once VGM_DIR . '/inc/sprite.php';
require_once VGM_DIR . '/inc/llms.php';

/**
 * Datos del sitio por defecto (se cambian en Apariencia → Personalizar → Datos del sitio).
 */
function vgm_datos_por_defecto( $settings ) {
	$defaults = array(
		'phone'       => '888 436 6339',
		'phone_link'  => 'tel:+18884366339',
		'email'       => 'info@viva-marketing.net',
		'address'     => '',
		'cta_label'   => 'Llámanos',
		'cta_url'     => 'tel:+18884366339',
		'footer_text' => 'Conecta tu mundo. Vive sin límites.',
		'privacy_url' => '',
		'terms_url'   => '',
		'copyright'   => 'Copyright © {año} Viva Marketing. Todos los derechos reservados.',
	);
	foreach ( $defaults as $key => $value ) {
		if ( isset( $settings[ $key ] ) ) {
			$settings[ $key ][1] = $value;
		}
	}
	return $settings;
}
add_filter( 'vg7_settings', 'vgm_datos_por_defecto' );

/**
 * Menús por defecto mientras no se creen en Apariencia → Menús.
 */
function vgm_menu_por_defecto( $menu, $location ) {
	$item = function ( $title, $url ) {
		return array(
			'title'    => $title,
			'url'      => $url,
			'children' => array(),
		);
	};
	if ( in_array( $location, array( 'principal', 'footer-1' ), true ) ) {
		return array(
			$item( __( 'Inicio', 'vg7-marketing' ), home_url( '/' ) ),
			$item( __( 'Planes', 'vg7-marketing' ), home_url( '/planes/' ) ),
			$item( __( 'Contacto', 'vg7-marketing' ), home_url( '/contacto/' ) ),
		);
	}
	return $menu;
}
add_filter( 'vg7_default_menu', 'vgm_menu_por_defecto', 10, 2 );

/**
 * ¿El enlace apunta a la página que se está viendo? (para marcar el menú)
 */
function vgm_es_actual( $url ) {
	if ( '' === $url || '#' === $url[0] || false !== strpos( $url, '#' ) ) {
		return false;
	}
	$request = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	return vgm_ruta( $url ) === vgm_ruta( $request );
}

/**
 * Ruta de una dirección para compararla: sin barra final ni #ancla. Con enlaces simples (?page_id=5)
 * también cuenta el parámetro que identifica la página.
 */
function vgm_ruta( $url ) {
	$parts = wp_parse_url( $url );
	$path  = isset( $parts['path'] ) ? untrailingslashit( $parts['path'] ) : '';
	if ( ! get_option( 'permalink_structure' ) && ! empty( $parts['query'] ) ) {
		parse_str( $parts['query'], $query );
		foreach ( array( 'page_id', 'p', 'cat', 'tag', 's' ) as $key ) {
			if ( isset( $query[ $key ] ) ) {
				$path .= '?' . $key . '=' . $query[ $key ];
				break;
			}
		}
	}
	return $path;
}

/**
 * Logo: el del Personalizador si existe y, si no, el del sitio actual (assets/img/logo.webp, 600 x 220: "Viva" en verde y "marketing" en blanco,
 * solo sirve sobre fondos oscuros). 'lg' = footer (sin la clase del header).
 */
function vgm_logo( $html, $size ) {
	$lg    = 'lg' === $size;
	$class = $lg ? 'logo' : 'hd-logo logo';
	$aria  = esc_attr__( 'Viva Marketing, inicio', 'vg7-marketing' );
	if ( has_custom_logo() ) {
		return sprintf(
			'<a class="%1$s" href="%2$s" aria-label="%3$s">%4$s</a>',
			$class,
			esc_url( home_url( '/' ) ),
			$aria,
			wp_get_attachment_image(
				(int) get_theme_mod( 'custom_logo' ),
				'full',
				false,
				array(
					'alt'           => get_bloginfo( 'name' ),
					'loading'       => $lg ? 'lazy' : 'eager',
					'fetchpriority' => $lg ? 'auto' : 'high',
				)
			)
		);
	}
	return sprintf(
		'<a class="%1$s" href="%2$s" aria-label="%3$s"><img src="%4$s" width="600" height="220" alt="%5$s"%6$s></a>',
		$class,
		esc_url( home_url( '/' ) ),
		$aria,
		esc_url( VGM_URL . '/assets/img/logo.webp' ),
		esc_attr( 'Viva Marketing' ),
		$lg ? ' loading="lazy" decoding="async"' : ''
	);
}
add_filter( 'vg7_logo_html', 'vgm_logo', 10, 2 );

/**
 * Hoja base del sitio. Se REGISTRA temprano (init) para que los bloques la pidan en su block.json ("style": ["vgm-base", "file:./style.css"]) y se
 * encola en todas las páginas. OJO con el orden: WordPress 7 imprime los estilos de los bloques ANTES que esta hoja, así que una regla de un bloque que la
 * pise con el mismo peso pierde (en el CSS de los bloques lleva más especificidad).
 */
function vgm_registrar_base() {
	wp_register_style( 'vgm-base', VGM_URL . '/assets/css/base.css', array( 'vg7', 'vg7-marca' ), VGM_VERSION );
}
add_action( 'init', 'vgm_registrar_base', 5 );

function vgm_assets() {
	wp_enqueue_style( 'vgm-base' );
	// Rendimiento: los tres CSS del tema (padre, marca y base) bloquean el primer pintado y cada uno es una solicitud. Con "path", WordPress
	// los imprime en línea (igual que ya hace con los estilos de los bloques) y la portada pinta sin esperar a ningún archivo de CSS.
	wp_style_add_data( 'vg7', 'path', VG7_DIR . '/assets/css/vg7.css' );
	wp_style_add_data( 'vg7-marca', 'path', VGM_DIR . '/assets/css/marca.css' );
	wp_style_add_data( 'vgm-base', 'path', VGM_DIR . '/assets/css/base.css' );
	wp_enqueue_script(
		'vgm-sitio',
		VGM_URL . '/assets/js/sitio.js',
		array(),
		VGM_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'vgm_assets', 20 );

/**
 * WordPress solo imprime en línea hasta 40 KB de CSS en total (entre todos los estilos con "path"). Entre el CSS del tema y el de los bloques de una
 * página se pasan: sin subir el tope, los más grandes volverían a ser archivos aparte y a bloquear el pintado.
 */
function vgm_tope_css_en_linea( $limit ) {
	return max( (int) $limit, 90000 );
}
add_filter( 'styles_inline_size_limit', 'vgm_tope_css_en_linea' );

/**
 * Antes de pintar: viene de otra página del sitio (cortina que se retira) y escritorio con movimiento (escenas fijas, html.vg-pin).
 * Si el motor de animación del padre no arranca en 4 s, se quitan las escenas fijas y la página queda en su diseño normal.
 */
function vgm_banderas() {
	$pin = vg7_page_has_blocks() ? "if(matchMedia('(min-width:900px) and (prefers-reduced-motion:no-preference)').matches){r.classList.add('vg-pin');setTimeout(function(){if(!(window.VG7&&window.VG7.motion))r.classList.remove('vg-pin')},4000)}" : '';
	echo "<script>(function(d){var r=d.documentElement;try{if(sessionStorage.getItem('vgNav')){r.classList.add('pg-in');sessionStorage.removeItem('vgNav')}}catch(e){}" . $pin . "})(document)</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput -- script fijo.
}
add_action( 'wp_head', 'vgm_banderas', 2 );

/**
 * Las tipografías del primer pintado se precargan (títulos y texto).
 */
function vgm_precargar_fuentes() {
	foreach ( array( 'ibm-plex-sans-latin-600-normal.woff2', 'libre-franklin-latin-400-normal.woff2' ) as $file ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( VGM_URL . '/assets/fonts/' . $file ) );
	}
}
add_action( 'wp_head', 'vgm_precargar_fuentes', 2 );

/**
 * Color del navegador en móvil (barra de direcciones) e ícono del sitio si no se puso uno en Personalizar.
 */
function vgm_cabeza() {
	echo '<meta name="theme-color" content="#0A1D19">' . "\n";
	if ( ! has_site_icon() ) {
		printf( '<link rel="icon" href="%s" type="image/svg+xml">' . "\n", esc_url( VGM_URL . '/assets/img/favicon.svg' ) );
	}
}
add_action( 'wp_head', 'vgm_cabeza', 1 );

/**
 * Estilos también dentro del editor de bloques (vista previa fiel al sitio).
 */
function vgm_estilos_editor() {
	add_editor_style( 'assets/css/marca.css' );
	add_editor_style( 'assets/css/base.css' );
}
add_action( 'after_setup_theme', 'vgm_estilos_editor', 20 );
