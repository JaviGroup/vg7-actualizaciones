/*
 * VG7 Marketing: scripts del sitio (en todas las páginas, sin librerías). Portado de comun.js del diseño aprobado (disenos/viva-marketing/):
 * alto del header (--hdr), menú móvil, entrada de cada sección (.is-in) y cortina de transición entre páginas.
 * La medición (data-vg7-track) y los enlaces internos (#) los atiende el script del tema padre (tema.js); el scroll suave (Lenis), el motor del
 * tema padre: window.VG7.lenis (solo en páginas con bloques animados). Las escenas de cada sección van en el view.js de su bloque.
 */
(function () {
	'use strict';
	var d = document, root = d.documentElement;
	var $ = function (s, c) { return (c || d).querySelector(s); };
	var $$ = function (s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); };
	var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
	var lenis = function () { return (window.VG7 && window.VG7.lenis) || null; };

	/* ---------- Alto del header: las escenas fijas miden 100svh menos esto ---------- */
	var bar = $('.site-header'), lastH = -1;
	function measure() {
		if (!bar) return;
		var h = Math.round(bar.getBoundingClientRect().height);
		if (h === lastH) return;
		lastH = h;
		root.style.setProperty('--hdr', h + 'px');
		if (window.ScrollTrigger) window.ScrollTrigger.refresh();
	}
	measure();
	if (bar && window.ResizeObserver) new ResizeObserver(measure).observe(bar);

	/* ---------- Menú móvil: hoja que baja bajo el header ---------- */
	var burger = $('.hd-burger'), nav = $('.hd-nav');
	// Con el menú abierto la página de atrás no se mueve: Lenis se detiene (y data-lenis-prevent deja que la hoja haga su propio scroll si no cabe)
	function setNav(open) {
		if (open === root.classList.contains('nav-open')) return;
		root.classList.toggle('nav-open', open);
		if (nav) nav.toggleAttribute('data-lenis-prevent', open);
		var l = lenis();
		if (l) { if (open) l.stop(); else l.start(); }
		if (burger) { burger.setAttribute('aria-expanded', String(open)); burger.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú'); }
	}
	if (burger && nav) {
		burger.addEventListener('click', function () { setNav(!root.classList.contains('nav-open')); });
		d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && root.classList.contains('nav-open')) { setNav(false); burger.focus(); } });
		matchMedia('(min-width: 900px)').addEventListener('change', function (e) { if (e.matches) setNav(false); });
		nav.addEventListener('click', function (e) { if (e.target.closest('a[href^="#"]')) setNav(false); });
	}

	/* ---------- Entrada de cada sección: arranca al verse (las animaciones de entrada son CSS) ---------- */
	var secs = $$('.vg7-sec');
	if (window.IntersectionObserver && secs.length) {
		var seen = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) {
				if (en.isIntersecting) { en.target.classList.add('is-in'); seen.unobserve(en.target); }
			});
		}, { threshold: 0.12 });
		secs.forEach(function (s) { seen.observe(s); });
	} else {
		secs.forEach(function (s) { s.classList.add('is-in'); });
	}

	/* ---------- Transición entre páginas: una cortina degradada sube al salir y se va al llegar ----------
	   Al salir se marca sessionStorage.vgNav; el <head> de la página siguiente pone html.pg-in (functions.php) y la cortina se retira. Sin movimiento no hay cortina. */
	if (!reduce) {
		d.addEventListener('click', function (e) {
			var a = e.target.closest('a[href]');
			if (!a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || (a.target && a.target !== '_self') || a.hasAttribute('download')) return;
			var u;
			try { u = new URL(a.href, location.href); } catch (x) { return; }
			if (u.origin !== location.origin || !/^https?:$/.test(u.protocol)) return;
			if (u.pathname.replace(/\/$/, '') === location.pathname.replace(/\/$/, '')) return;   // misma página: lo resuelven las anclas
			if (/\/wp-(admin|login)/.test(u.pathname)) return;
			e.preventDefault();
			setNav(false);
			root.classList.add('pg-leave');
			try { sessionStorage.setItem('vgNav', '1'); } catch (x) { /* sin almacenamiento: la página nueva simplemente no hace la entrada */ }
			setTimeout(function () { location.href = a.href; }, 520);
		});
		window.addEventListener('pageshow', function (e) { if (e.persisted) root.classList.remove('pg-leave'); });
	}
})();
