<?php
/**
 * Footer de Viva Marketing: marca con su frase, enlaces, contacto con redes y el nombre gigante que sube al llegar.
 * Teléfono, correo y redes salen de Apariencia → Personalizar → Datos del sitio (una red sin enlace no sale); los enlaces, del menú "Footer: columna 1".
 */

defined( 'ABSPATH' ) || exit;

$vgm_phone = vg7_opt( 'phone' );
$vgm_plink = vg7_opt( 'phone_link' );
$vgm_email = vg7_opt( 'email' );
$vgm_links = vg7_menu_tree( 'footer-1' );
$vgm_nets  = vg7_social_links();
$vgm_legal = str_replace( '{año}', gmdate( 'Y' ), vg7_opt( 'copyright' ) );
?>

<footer class="site-footer" data-tono="bosque">
	<div class="ft-grid">
		<div class="ft-brand">
			<?php echo vg7_logo( 'lg' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vg7_logo(). ?>
			<?php if ( vg7_opt( 'footer_text' ) ) : ?>
				<p><?php echo esc_html( vg7_opt( 'footer_text' ) ); ?></p>
			<?php endif; ?>
		</div>
		<?php if ( $vgm_links ) : ?>
			<nav class="ft-col" aria-label="<?php esc_attr_e( 'Enlaces', 'vg7-marketing' ); ?>">
				<h2><?php esc_html_e( 'Enlaces', 'vg7-marketing' ); ?></h2>
				<ul>
					<?php foreach ( $vgm_links as $vgm_item ) : ?>
						<li><a href="<?php echo esc_url( $vgm_item['url'] ); ?>"<?php echo vgm_es_actual( $vgm_item['url'] ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $vgm_item['title'] ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</nav>
		<?php endif; ?>
		<div class="ft-col">
			<h2><?php esc_html_e( 'Contáctanos', 'vg7-marketing' ); ?></h2>
			<ul>
				<?php if ( $vgm_phone && $vgm_plink ) : ?>
					<li><a href="<?php echo esc_url( $vgm_plink, array( 'tel', 'http', 'https' ) ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="footer"><?php echo esc_html( $vgm_phone ); ?></a></li>
				<?php endif; ?>
				<?php if ( $vgm_email ) : ?>
					<li><a href="<?php echo esc_url( 'mailto:' . $vgm_email, array( 'mailto' ) ); ?>"><?php echo esc_html( $vgm_email ); ?></a></li>
				<?php endif; ?>
			</ul>
			<?php if ( $vgm_nets ) : ?>
				<div class="ft-social">
					<?php foreach ( $vgm_nets as $vgm_net ) : ?>
						<a href="<?php echo esc_url( $vgm_net['url'] ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( $vgm_net['name'] ); ?>"><svg class="ico" aria-hidden="true" focusable="false"><use href="#i-<?php echo esc_attr( $vgm_net['icon'] ); ?>"/></svg></a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<div class="ft-legal"><span><?php echo esc_html( $vgm_legal ); ?></span></div>
	<p class="ft-ghost" aria-hidden="true">Viva Marketing</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
