/*
 * VG7 Marketing: base común de los scripts de los bloques (portado de comun.js del diseño aprobado, disenos/viva-marketing/).
 * Lo piden todos los bloques con escena en su view.asset.php: array( 'vgsb-comunes' ). Depende de vg7-motion (GSAP, ScrollTrigger, Lenis).
 *
 * - Define window.VM para los scripts de los bloques:
 *     VM.motion  true si el motor de animación del tema padre arrancó (GSAP + ScrollTrigger y sin "reducir movimiento").
 *     VM.lenis   el scroll suave del tema padre (window.VG7.lenis), o null. Los bloques NO crean su propio Lenis.
 *     VM.mm      gsap.matchMedia(); VM.DESK / VM.MOB / VM.MOTION son las condiciones (escritorio con movimiento, móvil con movimiento y movimiento).
 *     VM.hdr()   alto del header; VM.top() y VM.span(pantallas) arman el inicio y el largo de una escena fija; VM.clamp(v, a, b).
 *     VM.stackFx(tarjetas, desfase)  tarjetas apiladas (móvil): la que queda tapada por la siguiente se hunde un poco.
 * - html.vg-pin (escenas fijas) se mantiene según la condición de escritorio con movimiento; sin movimiento se quita y cada sección queda en su diseño normal.
 * - Efectos que comparten todas las páginas: la barra de avance del header y el nombre gigante del footer.
 * Lo propio de cada sección va en el view.js de su bloque; allí lo que no depende de GSAP va primero y lo que anima, tras "if (!VM.motion) return;".
 */
(function () {
	'use strict';
	var d = document, root = d.documentElement;
	var $ = function (s, c) { return (c || d).querySelector(s); };
	var $$ = function (s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); };
	var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
	var motion = !reduce && !!(window.gsap && window.ScrollTrigger && window.VG7 && window.VG7.motion);
	var VM = window.VM = window.VM || {};
	VM.$ = $;
	VM.$$ = $$;
	VM.reduce = reduce;
	VM.motion = motion;
	Object.defineProperty(VM, 'lenis', { configurable: true, get: function () { return (window.VG7 && window.VG7.lenis) || null; } });
	VM.hdr = function () { var b = $('.site-header'); return b ? Math.round(b.getBoundingClientRect().height) : 0; };
	VM.clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };

	// Sin motor de animación: se deja el diseño estático (sin escenas fijas).
	if (!motion) { root.classList.remove('vg-pin'); return; }

	var gs = window.gsap, ST = window.ScrollTrigger;
	gs.registerPlugin(ST);
	// Los ScrollTrigger se refrescan en el orden en que se crearon: al cruzar los 900 px las escenas fijas se vuelven a crear después de las
	// que van más abajo y estas calcularían su inicio sin el espacio de la escena de arriba. Se reordenan de arriba a abajo antes de cada refresco.
	ST.addEventListener('refreshInit', function () { ST.sort(); });

	VM.DESK = '(min-width: 900px) and (prefers-reduced-motion: no-preference)';
	VM.MOB = '(max-width: 899px) and (prefers-reduced-motion: no-preference)';
	VM.MOTION = '(prefers-reduced-motion: no-preference)';
	VM.mm = gs.matchMedia();
	VM.top = function () { return 'top top+=' + VM.hdr(); };
	VM.span = function (screens) { return function () { return '+=' + Math.round(window.innerHeight * screens); }; };

	// Marca el layout de escena fija mientras se cumple la condición (el <head> la pone antes del primer pintado).
	VM.mm.add(VM.DESK, function () {
		root.classList.add('vg-pin');
		return function () { root.classList.remove('vg-pin'); };
	});

	/* Tarjetas apiladas (móvil): la que queda tapada por la siguiente se hunde un poco */
	VM.stackFx = function (items, offset) {
		items.forEach(function (it, i) {
			var next = items[i + 1];
			if (!next) return;
			// Sin opacidad: una tarjeta translúcida dejaría ver el texto de la que tiene debajo.
			// fromTo con el filtro de partida explícito: con gs.to, GSAP parte de "none" como si fuera brightness(0) y la tarjeta pasaba por casi negro antes de aclararse.
			gs.fromTo(it, { scale: 1, filter: 'brightness(1)' }, {
				scale: 0.94, filter: 'brightness(0.86)', ease: 'none', transformOrigin: '50% 0%',
				scrollTrigger: { trigger: next, start: 'top 88%', end: function () { return 'top ' + (VM.hdr() + offset + (i + 1) * 14); }, scrub: true }
			});
		});
	};

	/* Efectos que comparten todas las páginas (solo con movimiento) */
	VM.mm.add(VM.MOTION, function () {
		// Barra de avance de la página (en el header)
		if ($('.hd-progress')) gs.to('.hd-progress', { scaleX: 1, ease: 'none', scrollTrigger: { start: 0, end: 'max', scrub: 0.2 } });
		// El nombre del footer sube al llegar
		var ghost = $('.ft-ghost'), foot = $('.site-footer');
		if (ghost && foot) {
			gs.fromTo(ghost, { yPercent: 38, opacity: 0.2 }, { yPercent: 0, opacity: 1, ease: 'none', scrollTrigger: { trigger: foot, start: 'top bottom', end: 'bottom bottom', scrub: true } });
		}
	});

	// Las fuentes y las imágenes cambian las medidas: se recalculan las escenas cuando terminan de cargar
	if (d.fonts && d.fonts.ready) d.fonts.ready.then(function () { ST.refresh(); });
	window.addEventListener('load', function () { ST.refresh(); });
})();
