/**
 * Bloque Pasos para contratar. Línea que se llena, pasos que se encienden y marco que recorre el celular (sección 6 de home.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

	var ps = $('[data-vg7="pasos"]');
	if (ps) {
	  mm.add(MOTION, function () {
	    var steps = $$('.ps-step', ps), list = $('.ps-list', ps), hl = $('.ps-hl', ps), phoneIn = $('.ps-phone-in', ps), cta = $('.ps-cta', ps);
	    // Posicion del marco sobre la imagen del celular (porcentajes del alto): los 4 pasos y el boton amarillo
	    var spots = [[24.1, 14.4], [39.7, 14.0], [55.0, 13.9], [69.4, 14.3], [85.2, 9.2]];
	    var cur = -2;
	    var show = function (k) {
	      if (k === cur) return;
	      cur = k;
	      steps.forEach(function (s, i) { s.classList.toggle('is-on', i <= Math.min(k, steps.length - 1)); });
	      if (k < 0) { gsap.to(hl, { opacity: 0, duration: 0.3, overwrite: true }); return; }
	      gsap.to(hl, { top: spots[k][0] + '%', height: spots[k][1] + '%', opacity: 1, duration: 0.55, ease: 'power3.out', overwrite: true });
	    };
	    ps.classList.add('ps-anim');
	    gsap.set(hl, { opacity: 0 });
	    show(-1);
	    var made = [];
	    steps.forEach(function (s, i) {
	      made.push(ST.create({ trigger: s, start: 'top 64%', onEnter: function () { show(i); }, onLeaveBack: function () { show(i - 1); } }));
	    });
	    if (cta) made.push(ST.create({ trigger: cta, start: 'top 86%', onEnter: function () { show(steps.length); }, onLeaveBack: function () { show(steps.length - 1); } }));
	    made.push(ST.create({
	      trigger: list, start: 'top 64%', end: 'bottom 64%', scrub: 0.3,
	      onUpdate: function (self) { list.style.setProperty('--p', self.progress.toFixed(3)); }
	    }));
	    gsap.fromTo(phoneIn, { rotation: -3, y: 20 }, { rotation: 3, y: -20, ease: 'none', scrollTrigger: { trigger: ps, start: 'top bottom', end: 'bottom top', scrub: true } });
	    return function () {
	      made.forEach(function (st) { st.kill(); });
	      ps.classList.remove('ps-anim'); list.style.removeProperty('--p');
	      steps.forEach(function (s) { s.classList.remove('is-on'); });
	      hl.removeAttribute('style');
	    };
	  });
	}
})();
