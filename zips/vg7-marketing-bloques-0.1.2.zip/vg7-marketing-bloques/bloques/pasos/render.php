<?php
/**
 * Bloque: Pasos para contratar (index.html y planes.html, section#pasos).
 *
 * A la izquierda, el celular del sitio (imagen fija: el marco verde se posiciona sobre sus cuatro tarjetas y el botón amarillo, ver view.js); a la derecha,
 * los cuatro pasos con su línea de progreso y el botón de llamar. Los íconos van por posición (teléfono, documento, palomita, play).
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$sec   = vgm_section( $a, 'pasos', '', 'pasos', 'alterno' );
$tag   = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h2', 'h2' );
$text  = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$plink = vg7_opt( 'phone_link' );
$steps = array_slice( vgm_items( isset( $a['steps'] ) ? $a['steps'] : array() ), 0, 4 );
$icons = array( 'phone', 'doc', 'check', 'play' );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="ps-in sec-wrap">
		<div class="ps-phone">
			<div class="ps-phone-in">
				<?php
				echo vgm_pic( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_pic().
					0,
					'phone-pasos.webp',
					'phone-pasos-sm.webp',
					array(
						'w'     => 560,
						'h'     => 1331,
						'ws'    => 380,
						'class' => 'ps-img',
						'alt'   => $text( 'imageAlt' ),
						'sizes' => '(min-width: 900px) 340px, 260px',
					)
				);
				?>
				<i class="ps-hl" aria-hidden="true"></i>
			</div>
		</div>
		<div class="ps-copy">
			<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
				<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
			<?php endif; ?>
			<<?php echo esc_attr( $tag ); ?> class="sec-title" id="<?php echo esc_attr( $sec['title_id'] ); ?>" style="--t-size:clamp(2.1rem, 4vw, 3.6rem)"><?php echo vgm_title( $text( 'title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title(). ?></<?php echo esc_attr( $tag ); ?>>
			<?php if ( $steps ) : ?>
				<ol class="ps-list">
					<?php foreach ( $steps as $i => $step ) : ?>
						<li class="ps-step"><span class="ps-node" aria-hidden="true"><?php echo vgm_icon( $icons[ $i ] ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></span><div class="ps-txt"><span class="ps-n" aria-hidden="true"><?php echo esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><h3><?php echo esc_html( isset( $step['title'] ) ? $step['title'] : '' ); ?></h3><p><?php echo esc_html( isset( $step['text'] ) ? $step['text'] : '' ); ?></p></div></li>
					<?php endforeach; ?>
				</ol>
			<?php endif; ?>
			<?php
			if ( $plink && '' !== $text( 'btnLabel' ) ) {
				echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
					array(
						'label'     => $text( 'btnLabel' ),
						'url'       => $plink,
						'icon'      => 'phone',
						'class'     => 'ps-cta',
						'track'     => 'clic_llamar',
						'ubicacion' => 'pasos',
						'attrs'     => array(
							'data-r' => '',
							'style'  => '--d:.2s',
						),
					)
				);
			}
			?>
		</div>
	</div>
</section>
