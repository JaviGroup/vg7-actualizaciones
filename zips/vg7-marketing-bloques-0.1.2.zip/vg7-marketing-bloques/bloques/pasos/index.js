/**
 * Bloque Pasos para contratar: campos del editor.
 */
VG7Editor.register('vg7-marketing/pasos', [
	{ title: 'Encabezado', fields: [
		{ key: 'eyebrow', label: 'Etiqueta superior', help: 'Déjala vacía para quitarla.' },
		{ key: 'title', label: 'Título', type: 'textarea', rows: 2, help: 'Lo que escribas entre *asteriscos* sale en verde (por ejemplo: Encuentra el *plan ideal* con estos pasos).' },
		VG7Editor.HEADING
	] },
	{ title: 'Pasos', fields: [
		{ key: 'steps', type: 'repeater', itemLabel: 'Paso', titleKey: 'title', min: 4, max: 4, help: 'Son cuatro pasos: el marco verde del celular recorre sus cuatro tarjetas (la imagen del celular es fija).', add: { title: 'Nuevo paso', text: 'Describe el paso.' }, fields: [
			{ key: 'title', label: 'Título' },
			{ key: 'text', label: 'Texto', type: 'textarea', rows: 3 }
		] },
		{ key: 'btnLabel', label: 'Botón de llamar: texto', help: 'El teléfono sale de Datos del sitio. Vacío o sin teléfono = sin botón.' },
		{ key: 'imageAlt', label: 'Descripción del celular (para lectores de pantalla)' }
	] },
	{ title: 'Avanzado', fields: [
		VG7Editor.SECTION_ID
	] }
]);
