<?php
/**
 * Bloque: Formulario de Contacto (contacto.html, section#formulario).
 *
 * A la izquierda: etiqueta, título, el medidor de señal (cuatro arcos que se encienden con cada dato completo: nombre, teléfono, dirección y servicio) y las
 * tarjetas de teléfono y correo (de Datos del sitio). A la derecha: la tarjeta con el formulario y, al enviar, la confirmación.
 *
 * Campos del motor de formularios del tema padre (inc/formularios.php): nombre, telefono, servicio (opcional), acepto_contacto (obligatorio; su texto exacto va en
 * consentimiento), acepto_promociones (opcional), utm_*, gclid, fbclid y la trampa sitio_web; más direccion, propio de este sitio (includes/extra/formularios.php).
 * El servicio, si se elige, debe ser uno de la lista blanca de ese archivo. La validación y el envío real (VG7Forms.send) están en view.js.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$sec   = vgm_section( $a, 'formulario-contacto', '', 'formulario', 'claro' );
$tag   = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h2', 'h2' );
$text  = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$phone = vg7_opt( 'phone' );
$plink = vg7_opt( 'phone_link' );
$email = vg7_opt( 'email' );

$services = vgm_lines( $text( 'services' ) );
$consent  = vgm_tel_text( $text( 'consent' ) );
$promos   = trim( $text( 'promos' ) );

// Texto de la confirmación: lo que va entre *asteriscos* sale en negritas; la primera parte resaltada (#ok-tel) la cambia view.js por el teléfono que se escribió.
$ok_html = '';
foreach ( explode( '*', $text( 'okText' ) ) as $i => $part ) {
	$ok_html .= $i % 2 ? '<strong' . ( 1 === $i ? ' id="ok-tel"' : '' ) . '>' . esc_html( $part ) . '</strong>' : esc_html( $part );
}
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="ct-in sec-wrap">
		<aside class="ct-side">
			<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
				<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
			<?php endif; ?>
			<<?php echo esc_attr( $tag ); ?> class="sec-title" id="<?php echo esc_attr( $sec['title_id'] ); ?>" style="--t-size:clamp(2.2rem, 4vw, 3.6rem)"><?php echo vgm_title( $text( 'title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title(). ?></<?php echo esc_attr( $tag ); ?>>

			<div class="ct-meter" data-tono="oscuro" data-r style="--d:.45s">
				<div class="ct-sig" aria-hidden="true"><i style="--k:1"></i><i style="--k:2"></i><i style="--k:3"></i><i style="--k:4"></i><b></b></div>
				<div class="ct-meter-body">
					<p class="ct-meter-txt" id="meter-txt" aria-live="polite"><b>0</b> <?php echo esc_html( $text( 'meterLabel' ) ); ?></p>
					<p class="ct-ready" aria-hidden="true"><?php echo esc_html( $text( 'readyText' ) ); ?></p>
				</div>
			</div>

			<?php if ( ( $phone && $plink ) || $email ) : ?>
				<ul class="ct-info" data-r style="--d:.6s">
					<?php if ( $phone && $plink ) : ?>
						<li>
							<span class="ct-ico" aria-hidden="true"><?php echo vgm_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></span>
							<div><h3><?php echo esc_html( $text( 'phoneTitle' ) ); ?></h3><a href="<?php echo esc_url( $plink, array( 'tel', 'http', 'https' ) ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="contacto_info"><?php echo esc_html( $phone ); ?></a></div>
						</li>
					<?php endif; ?>
					<?php if ( $email ) : ?>
						<li>
							<span class="ct-ico" aria-hidden="true"><?php echo vgm_icon( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></span>
							<div><h3><?php echo esc_html( $text( 'mailTitle' ) ); ?></h3><a href="<?php echo esc_url( 'mailto:' . $email, array( 'mailto' ) ); ?>"><?php echo esc_html( $email ); ?></a></div>
						</li>
					<?php endif; ?>
				</ul>
			<?php endif; ?>
		</aside>

		<div class="ct-card">
			<form class="ct-form" id="contacto-form" novalidate data-vg7-form data-endpoint="<?php echo esc_url( vg7_form_endpoint() ); ?>" data-ubicacion="formulario_contacto" data-sending="<?php echo esc_attr( $text( 'sendingLabel' ) ); ?>" data-error="<?php echo esc_attr( vgm_tel_text( $text( 'errorText' ) ) ); ?>">
				<div class="fld" data-f="nombre">
					<label for="f-nombre"><?php echo esc_html( $text( 'nameLabel' ) ); ?> <span aria-hidden="true">*</span></label>
					<input id="f-nombre" name="nombre" type="text" autocomplete="name" placeholder="<?php echo esc_attr( $text( 'namePlaceholder' ) ); ?>" required aria-required="true" aria-describedby="e-nombre">
					<p class="fld-err" id="e-nombre" hidden><?php esc_html_e( 'Escribe tu nombre completo.', 'vg7-marketing-bloques' ); ?></p>
				</div>
				<div class="fld" data-f="telefono">
					<label for="f-telefono"><?php echo esc_html( $text( 'telLabel' ) ); ?> <span aria-hidden="true">*</span></label>
					<input id="f-telefono" name="telefono" type="tel" inputmode="tel" autocomplete="tel-national" placeholder="<?php echo esc_attr( $text( 'telPlaceholder' ) ); ?>" required aria-required="true" aria-describedby="e-telefono">
					<p class="fld-err" id="e-telefono" hidden><?php esc_html_e( 'Escribe un teléfono de EE. UU. de 10 dígitos.', 'vg7-marketing-bloques' ); ?></p>
				</div>
				<div class="fld" data-f="direccion">
					<label for="f-direccion"><?php echo esc_html( $text( 'addressLabel' ) ); ?> <span aria-hidden="true">*</span></label>
					<input id="f-direccion" name="direccion" type="text" autocomplete="street-address" placeholder="<?php echo esc_attr( $text( 'addressPlaceholder' ) ); ?>" required aria-required="true" aria-describedby="e-direccion">
					<p class="fld-err" id="e-direccion" hidden><?php esc_html_e( 'Escribe tu dirección completa.', 'vg7-marketing-bloques' ); ?></p>
				</div>

				<?php if ( $services ) : ?>
					<fieldset class="fld ct-services" data-f="servicio">
						<legend><?php echo esc_html( $text( 'serviceLabel' ) ); ?></legend>
						<div class="ct-chips">
							<?php foreach ( $services as $service ) : ?>
								<label class="chip"><input type="radio" name="servicio" value="<?php echo esc_attr( $service ); ?>"><span><?php echo esc_html( $service ); ?></span></label>
							<?php endforeach; ?>
						</div>
					</fieldset>
				<?php endif; ?>

				<div class="trap" aria-hidden="true"><label for="f-web"><?php esc_html_e( 'No llenes este campo', 'vg7-marketing-bloques' ); ?></label><input id="f-web" name="sitio_web" type="text" tabindex="-1" autocomplete="off"></div>
				<input type="hidden" id="f-utm_source" name="utm_source"><input type="hidden" id="f-utm_medium" name="utm_medium"><input type="hidden" id="f-utm_campaign" name="utm_campaign"><input type="hidden" id="f-gclid" name="gclid"><input type="hidden" id="f-fbclid" name="fbclid">

				<ul class="ct-consent">
					<li data-f="consent">
						<label class="ck"><input type="checkbox" id="f-acepto" name="acepto_contacto" value="1" required aria-required="true" aria-describedby="e-consent"><i class="ck-box" aria-hidden="true"></i><span><?php echo esc_html( $consent ); ?></span></label>
						<p class="fld-err" id="e-consent" hidden><?php esc_html_e( 'Debes aceptar que te contactemos para poder enviar.', 'vg7-marketing-bloques' ); ?></p>
					</li>
					<?php if ( '' !== $promos ) : ?>
						<li><label class="ck"><input type="checkbox" name="acepto_promociones" value="1"><i class="ck-box" aria-hidden="true"></i><span><?php echo esc_html( $promos ); ?></span></label></li>
					<?php endif; ?>
				</ul>
				<input type="hidden" name="consentimiento" value="<?php echo esc_attr( $consent ); ?>">

				<p class="fld-err ct-srv-err" role="alert" tabindex="-1" hidden></p>
				<button class="btn btn--lg ct-submit" type="submit"><span><?php echo esc_html( $text( 'btnLabel' ) ); ?></span><span class="btn-ar"><?php echo vgm_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></span></button>
				<noscript><p class="ct-noscript"><?php echo esc_html( vgm_tel_text( $text( 'noscriptText' ) ) ); ?></p></noscript>
			</form>

			<div class="ct-ok" id="ct-ok" hidden tabindex="-1" role="status">
				<div class="ct-ok-ring" aria-hidden="true"><i></i><i></i><svg viewBox="0 0 64 64" fill="none" focusable="false"><circle cx="32" cy="32" r="29"/><path d="m19 33 9 9 18-20"/></svg></div>
				<h3><?php echo esc_html( $text( 'okTitle' ) ); ?></h3>
				<p><?php echo $ok_html; // phpcs:ignore WordPress.Security.EscapeOutput -- cada parte se escapa arriba. ?></p>
				<div class="ct-ok-actions">
					<?php
					if ( $phone && $plink ) {
						echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
							array(
								'label'     => $text( 'okCallLabel' ),
								'url'       => $plink,
								'icon'      => 'phone',
								'large'     => false,
								'track'     => 'clic_llamar',
								'ubicacion' => 'contacto_ok',
							)
						);
					}
					?>
					<?php if ( '' !== $text( 'okAgainLabel' ) ) : ?>
						<button class="btn btn--ghost" type="button" id="ok-otra"><?php echo esc_html( $text( 'okAgainLabel' ) ); ?></button>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section>
