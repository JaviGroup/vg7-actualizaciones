/**
 * Bloque Formulario de Contacto. Portado de contacto.js ("Formulario" y "Escenas") del diseño aprobado, más el envío REAL.
 *
 * Funciona sin GSAP y con "reducir movimiento": valida nombre, teléfono (EE. UU., 10 dígitos) y dirección (obligatorios) y cuenta también el servicio (opcional, como
 * en el sitio actual), marca cada campo completo y enciende un arco del medidor de señal por dato (0 a 4); con los tres obligatorios el medidor queda "listo" (el punto se
 * enciende y los arcos laten). La autorización de contacto es obligatoria (la exige el motor del tema padre) pero no cuenta en el medidor.
 * Envía con VG7Forms.send( form ) (motor de formularios del tema padre; el servidor vuelve a validar y guarda la solicitud en "Solicitudes").
 * Éxito: oculta el formulario, muestra #ct-ok y envía generate_lead (VG7Track). Error de validación: evento error_formulario. Error del servidor: mensaje accesible.
 * Con movimiento: la tarjeta entra inclinada y los campos suben escalonados.
 */
(function () {
	'use strict';
	var d = document, VM = window.VM || {};
	var $ = function (s, c) { return (c || d).querySelector(s); };
	var $$ = function (s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); };
	var gsap = window.gsap, ST = window.ScrollTrigger;
	var animate = !!VM.motion && !!gsap;
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';

	var sec = $('[data-vg7="formulario-contacto"]');
	var form = sec && $('#contacto-form', sec);
	if (!form) return;
	var ok = $('#ct-ok', sec), meter = $('.ct-meter', sec), arcs = $$('.ct-sig i', sec), meterNum = $('#meter-txt b', sec);
	var serverErr = $('.ct-srv-err', form), btn = $('.ct-submit', form), fWeb = $('#f-web', form), fTel = $('#f-telefono', form);
	var consent = $('#f-acepto', form), consentBox = $('[data-f="consent"]', form);

	function track(name, params) {
		if (window.VG7Track && typeof window.VG7Track.event === 'function') window.VG7Track.event(name, params || {});
	}

	/* ---------- Validación ---------- */
	// Los códigos de área de EE. UU. nunca empiezan por 1: un 1 inicial es el +1 del país
	var digits = function (v) { return String(v || '').replace(/\D/g, '').replace(/^1/, ''); };
	var formatUS = function (v) {
		var n = digits(v).slice(0, 10);
		if (n.length < 4) return n;
		if (n.length < 7) return '(' + n.slice(0, 3) + ') ' + n.slice(3);
		return '(' + n.slice(0, 3) + ') ' + n.slice(3, 6) + '-' + n.slice(6);
	};
	var wrap = function (k) { return form.querySelector('[data-f="' + k + '"]'); };
	var rules = {
		nombre: function () { return $('#f-nombre', form).value.trim().length >= 2; },
		telefono: function () { return /^[2-9]\d{2}[2-9]\d{6}$/.test(digits(fTel.value)); },
		direccion: function () { return $('#f-direccion', form).value.trim().length >= 5; },
		servicio: function () { return !!form.querySelector('input[name="servicio"]:checked'); }
	};
	var required = ['nombre', 'telefono', 'direccion'];     // el servicio cuenta para el medidor pero no bloquea el envío
	var keys = Object.keys(rules).filter(function (k) { return !!wrap(k); });

	// Pinta un campo: .is-ok si es válido; con show también el error (y aria-invalid). El servicio nunca marca error (es opcional)
	var paint = function (k, show) {
		var w = wrap(k), valid = rules[k](), err = $('.fld-err', w), inputs = $$('input', w);
		w.classList.toggle('is-ok', valid && k !== 'servicio');
		if (k === 'servicio' || !err) return;
		if (show || valid) {
			w.classList.toggle('has-err', !valid);
			err.hidden = valid;
			inputs.forEach(function (i) { i.setAttribute('aria-invalid', String(!valid)); });
		}
	};
	var paintConsent = function (show) {
		var valid = consent.checked;
		consentBox.classList.toggle('has-err', show && !valid);
		$('.fld-err', consentBox).hidden = valid || !show;
		consent.setAttribute('aria-invalid', String(show && !valid));
		return valid;
	};
	var progress = function () {
		var n = keys.filter(function (k) { return rules[k](); }).length;
		arcs.forEach(function (a, i) { a.classList.toggle('is-on', i < n); });
		meterNum.textContent = n;
		meter.classList.toggle('is-ready', required.every(function (k) { return !wrap(k) || rules[k](); }));
		return n;
	};

	fTel.addEventListener('input', function () { fTel.value = formatUS(fTel.value); });
	keys.forEach(function (k) {
		$$('input', wrap(k)).forEach(function (inp) {
			inp.addEventListener(inp.type === 'radio' ? 'change' : 'input', function () {
				paint(k, wrap(k).classList.contains('has-err'));
				progress();
			});
			if (inp.type !== 'radio') inp.addEventListener('blur', function () { if (inp.value.trim()) paint(k, true); });
		});
	});
	consent.addEventListener('change', function () { paintConsent(consentBox.classList.contains('has-err')); });

	// Campaña desde la dirección (utm_*, gclid, fbclid) y servicio preseleccionado (?servicio=Soporte)
	var fillCampaign = function () {
		try {
			var q = new URLSearchParams(window.location.search);
			['utm_source', 'utm_medium', 'utm_campaign', 'gclid', 'fbclid'].forEach(function (k) {
				var v = q.get(k), input = $('#f-' + k, form);
				if (v && input) input.value = v.slice(0, 200);
			});
			var s = q.get('servicio');
			if (s) {
				var radio = $$('input[name="servicio"]', form).filter(function (i) { return i.value === s; })[0];
				if (radio) radio.checked = true;
			}
		} catch (e) { /* sin URLSearchParams: el formulario se envía sin campaña */ }
	};
	fillCampaign();
	progress();

	/* ---------- Envío ---------- */
	var btnText = $('span', btn), label = btnText ? btnText.textContent : '', sendingText = form.getAttribute('data-sending') || '';
	var sending = false;
	var setSending = function (on) {
		sending = on;
		btn.disabled = on;
		btn.setAttribute('aria-busy', on ? 'true' : 'false');
		if (btnText && sendingText) btnText.textContent = on ? sendingText : label;
	};
	var showServerError = function (message) {
		serverErr.textContent = message || form.getAttribute('data-error') || '';
		serverErr.hidden = false;
		serverErr.focus({ preventScroll: true });
	};
	var hideServerError = function () { serverErr.hidden = true; serverErr.textContent = ''; };
	var success = function () {
		var radio = form.querySelector('input[name="servicio"]:checked');
		// Con la trampa llena el servidor responde bien sin guardar: tampoco se cuenta como lead
		if (!fWeb || !fWeb.value) track('generate_lead', { servicio: radio ? radio.value : '', ubicacion: form.getAttribute('data-ubicacion') || 'formulario_contacto' });
		var tel = $('#ok-tel', ok);
		if (tel) tel.textContent = fTel.value.trim();
		form.hidden = true;
		ok.hidden = false;
		ok.focus({ preventScroll: true });
		try { form.dispatchEvent(new CustomEvent('vgm:lead', { bubbles: true })); } catch (e) { /* sin CustomEvent: no pasa nada */ }
		if (ST) ST.refresh();
	};

	form.addEventListener('submit', function (e) {
		e.preventDefault();
		if (sending) return;
		hideServerError();
		var bad = null;
		required.forEach(function (k) { if (!wrap(k)) return; paint(k, true); if (!bad && !rules[k]()) bad = k; });
		var okConsent = paintConsent(true);
		progress();
		if (bad || !okConsent) {
			var target = !bad ? consent : $('input', wrap(bad));
			if (target) target.focus();
			track('error_formulario', { campo: bad || 'acepto_contacto' });
			return;
		}
		if (!window.VG7Forms || typeof window.VG7Forms.send !== 'function') { showServerError(); return; }
		setSending(true);
		window.VG7Forms.send(form).then(function (res) {
			setSending(false);
			if (res && res.ok) success(); else showServerError(res && res.message);
		}, function () {
			setSending(false);
			showServerError();
		});
	});

	var again = $('#ok-otra', ok);
	if (again) again.addEventListener('click', function () {
		form.reset();
		fillCampaign();
		keys.forEach(function (k) {
			var w = wrap(k), err = $('.fld-err', w);
			w.classList.remove('is-ok', 'has-err');
			if (err) err.hidden = true;
			$$('input', w).forEach(function (i) { i.removeAttribute('aria-invalid'); });
		});
		paintConsent(false);
		progress();
		ok.hidden = true;
		form.hidden = false;
		$('#f-nombre', form).focus();
		if (ST) ST.refresh();
	});

	/* ---------- Escenas (solo con movimiento) ---------- */
	if (!animate) return;
	var MOTION = VM.MOTION, mm = VM.mm;
	/* Formulario: la tarjeta entra inclinada y los campos suben escalonados */
	mm.add(MOTION, function () {
		var card = $('.ct-card', sec), items = $$('.ct-form .fld, .ct-consent li, .ct-submit', sec);
		if (!card) return;
		gsap.fromTo(card, { rotationX: 10, y: 70, scale: 0.95, opacity: 0.35, transformPerspective: 1200, transformOrigin: '50% 0%' },
			{ rotationX: 0, y: 0, scale: 1, opacity: 1, ease: 'none', scrollTrigger: { trigger: card, start: 'top 96%', end: 'top 48%', scrub: true } });
		gsap.set(items, { opacity: 0, y: 26 });
		var batch = ST.batch(items, {
			start: 'top 92%', once: true,
			onEnter: function (els) { gsap.to(els, { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out', stagger: 0.08, clearProps: 'opacity,transform' }); }
		});
		return function () { batch.forEach(function (s) { s.kill(); }); gsap.set([card].concat(items), { clearProps: CLR + ',transformPerspective,transformOrigin' }); };
	});
})();
