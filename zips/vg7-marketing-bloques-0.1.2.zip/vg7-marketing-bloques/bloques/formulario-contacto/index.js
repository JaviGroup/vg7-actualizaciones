/**
 * Bloque Formulario de Contacto: campos del editor.
 */
VG7Editor.register('vg7-marketing/formulario-contacto', [
	{ title: 'Encabezado', fields: [
		{ key: 'eyebrow', label: 'Etiqueta superior', help: 'Déjala vacía para quitarla.' },
		{ key: 'title', label: 'Título', type: 'textarea', rows: 2, help: 'Lo que escribas entre *asteriscos* sale en verde (por ejemplo: Cuéntanos *cómo ayudarte*).' },
		VG7Editor.HEADING
	] },
	{ title: 'Medidor de señal', fields: [
		{ key: 'meterLabel', label: 'Texto junto al número', help: 'Sale después del número de datos completos (0 a 4). Por ejemplo: de 4 datos completos.' },
		{ key: 'readyText', label: 'Mensaje al completar los datos obligatorios' }
	] },
	{ title: 'Tarjetas de contacto', fields: [
		{ key: 'phoneTitle', label: 'Título de la tarjeta de teléfono', help: 'El teléfono y el correo salen de Datos del sitio (Apariencia, Personalizar). Lo que no esté escrito allí no se muestra.' },
		{ key: 'mailTitle', label: 'Título de la tarjeta de correo' }
	] },
	{ title: 'Formulario', fields: [
		{ key: 'nameLabel', label: 'Nombre: etiqueta' },
		{ key: 'namePlaceholder', label: 'Nombre: ejemplo' },
		{ key: 'telLabel', label: 'Teléfono: etiqueta' },
		{ key: 'telPlaceholder', label: 'Teléfono: ejemplo' },
		{ key: 'addressLabel', label: 'Dirección: etiqueta' },
		{ key: 'addressPlaceholder', label: 'Dirección: ejemplo' },
		{ key: 'serviceLabel', label: 'Servicio: etiqueta' },
		{ key: 'services', label: 'Servicios', type: 'textarea', rows: 5, help: 'Uno por línea. El servicio es opcional. Solo se aceptan los que están en la lista del servidor (Planes móviles, Paquetes, Soporte y Otro); otros se rechazan al enviar.' },
		{ key: 'consent', label: 'Autorización obligatoria', type: 'textarea', rows: 3, help: '{telefono} se cambia por el teléfono de Datos del sitio. Este texto exacto se guarda con cada solicitud.' },
		{ key: 'promos', label: 'Autorización opcional (promociones)', type: 'textarea', rows: 4, help: 'Déjala vacía para quitar la casilla.' },
		{ key: 'btnLabel', label: 'Botón de enviar: texto' },
		{ key: 'sendingLabel', label: 'Texto mientras envía' },
		{ key: 'errorText', label: 'Mensaje si falla el envío', type: 'textarea', rows: 3, help: '{telefono} se cambia por el teléfono de Datos del sitio.' },
		{ key: 'noscriptText', label: 'Aviso sin JavaScript', type: 'textarea', rows: 2, help: '{telefono} se cambia por el teléfono de Datos del sitio.' }
	] },
	{ title: 'Confirmación', fields: [
		{ key: 'okTitle', label: 'Título' },
		{ key: 'okText', label: 'Texto', type: 'textarea', rows: 3, help: 'Lo que escribas entre *asteriscos* sale en negritas.' },
		{ key: 'okCallLabel', label: 'Botón de llamar: texto' },
		{ key: 'okAgainLabel', label: 'Botón de enviar otra: texto', help: 'Déjalo vacío para quitarlo.' }
	] },
	{ title: 'Avanzado', fields: [
		VG7Editor.SECTION_ID
	] }
]);
