<?php
return array(
	'dependencies' => array( 'vgmb-comunes', 'vg7-forms' ),
	'version'      => '0.1.1',
);
