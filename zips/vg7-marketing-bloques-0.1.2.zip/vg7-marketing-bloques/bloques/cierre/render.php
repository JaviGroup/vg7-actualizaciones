<?php
/**
 * Bloque: Cierre de contacto (Home y Planes, section.cta #contacto).
 *
 * Foto de fondo con parallax (en escritorio y en móvil, recortes distintos), anillos HTML que crecen con el scroll, etiqueta, título, texto, el teléfono
 * gigante y los botones de solicitar plan (llama) y de correo. El teléfono y el correo salen de Datos del sitio. La entrada de los textos es CSS; el crecimiento del
 * teléfono, los anillos y el parallax están en view.js.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$sec   = vgm_section( $a, 'cierre', 'cta', 'contacto', 'oscuro' );
$tag   = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h2', 'h2' );
$text  = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$phone = vg7_opt( 'phone' );
$plink = vg7_opt( 'phone_link' );
$email = vg7_opt( 'email' );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="cta-bg" aria-hidden="true"><picture><source media="(max-width: 700px)" srcset="<?php echo esc_url( vgm_asset( 'img/hogar-m.webp' ) ); ?>"><img src="<?php echo esc_url( vgm_asset( 'img/hogar.webp' ) ); ?>" width="1600" height="1067" alt="" loading="lazy" decoding="async"></picture></div>
	<div class="cta-rings" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
	<div class="cta-in sec-wrap">
		<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
			<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
		<?php endif; ?>
		<<?php echo esc_attr( $tag ); ?> class="sec-title" id="<?php echo esc_attr( $sec['title_id'] ); ?>" style="--t-size:clamp(2.1rem, 4.8vw, 4.2rem)"><?php echo vgm_title( $text( 'title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title(). ?></<?php echo esc_attr( $tag ); ?>>
		<?php if ( '' !== $text( 'lead' ) ) : ?>
			<p class="sec-lead" data-r style="--d:.7s"><?php echo esc_html( $text( 'lead' ) ); ?></p>
		<?php endif; ?>
		<?php if ( $phone && $plink ) : ?>
			<a class="cta-phone" href="<?php echo esc_url( $plink, array( 'tel', 'http', 'https' ) ); ?>" aria-label="<?php echo esc_attr( __( 'Llamar al', 'vg7-marketing-bloques' ) . ' ' . $phone ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="contacto"><?php echo esc_html( $phone ); ?></a>
		<?php endif; ?>
		<div class="cta-actions" data-r style="--d:.95s">
			<?php
			if ( $phone && $plink ) {
				echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
					array(
						'label'     => $text( 'callLabel' ),
						'url'       => $plink,
						'icon'      => 'phone',
						'track'     => 'clic_llamar',
						'ubicacion' => 'contacto_boton',
					)
				);
			}
			if ( $email ) {
				echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
					array(
						'label'    => $email,
						'url'      => 'mailto:' . $email,
						'variant'  => 'ghost',
						'icon'     => 'mail',
						'icon_pos' => 'before',
					)
				);
			}
			?>
		</div>
	</div>
</section>
