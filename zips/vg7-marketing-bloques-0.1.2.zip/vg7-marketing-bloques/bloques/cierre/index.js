/**
 * Bloque Cierre de contacto: campos del editor.
 */
VG7Editor.register('vg7-marketing/cierre', [
	{ title: 'Encabezado', fields: [
		{ key: 'eyebrow', label: 'Etiqueta superior', help: 'Déjala vacía para quitarla.' },
		{ key: 'title', label: 'Título', type: 'textarea', rows: 3, help: 'Lo que escribas entre *asteriscos* sale en verde (por ejemplo: ¿Tu internet actual te falla? *Es hora de mejorar tu conexión*).' },
		VG7Editor.HEADING,
		{ key: 'lead', label: 'Texto de apoyo', type: 'textarea', rows: 4 }
	] },
	{ title: 'Botones', fields: [
		{ key: 'callLabel', label: 'Botón de llamar: texto', help: 'El teléfono gigante y este botón salen de Datos del sitio (Apariencia, Personalizar). Sin teléfono, no se muestran. El botón de correo usa el correo de Datos del sitio.' }
	] },
	{ title: 'Avanzado', fields: [
		VG7Editor.SECTION_ID
	] }
]);
