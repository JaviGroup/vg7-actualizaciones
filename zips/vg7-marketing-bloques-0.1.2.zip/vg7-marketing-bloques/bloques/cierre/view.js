/**
 * Bloque Cierre de contacto. El teléfono se agranda, los anillos crecen y el fondo se mueve (comun.js del diseño aprobado).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;


var cta = $('[data-vg7="cierre"]');
if (cta) {
	var phone = $('.cta-phone', cta), rings = $('.cta-rings', cta), bgImg = $('.cta-bg img', cta);
	mm.add(MOTION, function () {
	  // El teléfono se agranda y los anillos crecen; el fondo se mueve a otro ritmo
	  if (phone) gsap.fromTo(phone, { scale: 0.8, opacity: 0.15 }, { scale: 1, opacity: 1, ease: 'none', scrollTrigger: { trigger: cta, start: 'top 65%', end: 'center 55%', scrub: true } });
	  if (rings) gsap.fromTo(rings, { scale: 0.7 }, { scale: 1.1, ease: 'none', scrollTrigger: { trigger: cta, start: 'top bottom', end: 'bottom top', scrub: true } });
	  if (bgImg) gsap.fromTo(bgImg, { yPercent: -4, scale: 1.06 }, { yPercent: 4, scale: 1.06, ease: 'none', scrollTrigger: { trigger: cta, start: 'top bottom', end: 'bottom top', scrub: true } });
	  return function () { gsap.set([phone, rings, bgImg].filter(Boolean), { clearProps: CLR }); };
	});
}
})();
