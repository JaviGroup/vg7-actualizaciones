<?php
/**
 * Bloque: Opiniones (index.html, section#opiniones).
 *
 * La calificación (el número cuenta de 0 al valor y las estrellas se llenan en proporción a la nota sobre 5) y una cita que se enciende palabra por palabra.
 * Es una sola opinión propia: no se marca con datos estructurados de reseñas (no cumple las reglas de Google). Las escenas están en view.js.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$sec   = vgm_section( $a, 'opiniones', '', 'opiniones', 'oscuro' );
$tag   = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h2', 'h2' );
$text  = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$score = str_replace( ',', '.', preg_replace( '/[^0-9.,]/', '', $text( 'score' ) ) );
$score = '' === $score ? '0' : $score;
$dec   = false !== strpos( $score, '.' ) ? strlen( substr( $score, strpos( $score, '.' ) + 1 ) ) : 0;
$fill  = max( 0, min( 100, round( (float) $score / 5 * 100 ) ) );
$star  = vgm_icon( 'star' );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="tm-glow" aria-hidden="true"></div>
	<div class="tm-in sec-wrap">
		<header class="tm-head">
			<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
				<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
			<?php endif; ?>
			<<?php echo esc_attr( $tag ); ?> class="sec-title" id="<?php echo esc_attr( $sec['title_id'] ); ?>" style="--t-size:clamp(2.1rem, 4.4vw, 4rem)"><?php echo vgm_title( $text( 'title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title(). ?></<?php echo esc_attr( $tag ); ?>>
		</header>
		<figure class="tm-fig">
			<div class="tm-score">
				<p class="tm-rate"><span class="num" data-count="<?php echo esc_attr( $score ); ?>" data-dec="<?php echo (int) $dec; ?>"><?php echo esc_html( $score ); ?></span><span class="tm-of"><?php echo esc_html( $text( 'outOf' ) ); ?></span></p>
				<div class="tm-stars" role="img" aria-label="<?php echo esc_attr( $text( 'starsLabel' ) ); ?>" data-fill="<?php echo (int) $fill; ?>%" style="--fill:<?php echo (int) $fill; ?>%">
					<div class="tm-row tm-row--bg" aria-hidden="true"><?php echo str_repeat( $star, 5 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></div>
					<div class="tm-row tm-row--fg" aria-hidden="true"><?php echo str_repeat( $star, 5 ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></div>
				</div>
			</div>
			<div class="tm-body">
				<blockquote class="tm-q"><p><?php echo vgm_frase( $text( 'quote' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_frase(). ?></p></blockquote>
				<figcaption class="tm-by"><span class="tm-av" aria-hidden="true"><?php echo esc_html( $text( 'initials' ) ); ?></span><strong><?php echo esc_html( $text( 'author' ) ); ?></strong></figcaption>
			</div>
		</figure>
	</div>
</section>
