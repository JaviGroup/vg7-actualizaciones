/**
 * Bloque Opiniones: campos del editor.
 */
VG7Editor.register('vg7-marketing/opiniones', [
	{ title: 'Encabezado', fields: [
		{ key: 'eyebrow', label: 'Etiqueta superior', help: 'Déjala vacía para quitarla.' },
		{ key: 'title', label: 'Título', type: 'textarea', rows: 2, help: 'Lo que escribas entre *asteriscos* sale en verde.' },
		VG7Editor.HEADING
	] },
	{ title: 'Calificación', fields: [
		{ key: 'score', label: 'Nota (por ejemplo 4.7)', help: 'El número cuenta hasta este valor y las estrellas se llenan en proporción a la nota sobre 5.' },
		{ key: 'outOf', label: 'Texto junto a la nota (por ejemplo: de 5)' },
		{ key: 'starsLabel', label: 'Descripción de las estrellas (para lectores de pantalla)' }
	] },
	{ title: 'Cita', fields: [
		{ key: 'quote', label: 'Opinión', type: 'textarea', rows: 5, help: 'Se enciende palabra por palabra al bajar.' },
		{ key: 'author', label: 'Nombre de quien opina' },
		{ key: 'initials', label: 'Iniciales (en el círculo)' }
	] },
	{ title: 'Avanzado', fields: [
		VG7Editor.SECTION_ID
	] }
]);
