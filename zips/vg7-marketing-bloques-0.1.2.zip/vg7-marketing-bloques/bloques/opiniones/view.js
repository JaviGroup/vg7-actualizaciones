/**
 * Bloque Opiniones. Nota que cuenta, estrellas que se llenan y cita que se enciende (sección 5 de home.js y contadores de comun.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

	var tm = $('[data-vg7="opiniones"]');
	if (tm) {
	  mm.add(MOTION, function () {
	    var stars = $('.tm-stars', tm), words = $$('.ms-w', tm);
	    gsap.fromTo(stars, { '--fill': '0%' }, { '--fill': stars.dataset.fill || '94%', duration: 1.8, ease: 'power2.out', scrollTrigger: { trigger: stars, start: 'top 88%', once: true } });
	    gsap.fromTo(words, { opacity: 0.18 }, {
	      opacity: 1, ease: 'none', stagger: 0.2,
	      scrollTrigger: { trigger: $('.tm-q', tm), start: 'top 82%', end: 'bottom 46%', scrub: true }
	    });
	    gsap.fromTo($('.tm-glow', tm), { yPercent: -6 }, { yPercent: 6, ease: 'none', scrollTrigger: { trigger: tm, start: 'top bottom', end: 'bottom top', scrub: true } });
	  });
	}


	/* Contadores (cifras con data-count): cuentan de 0 al valor al verse (data-dec = decimales, data-suf = sufijo) */
	var nums = $$('.num[data-count]', document);
	if (nums.length) {
	  mm.add(MOTION, function () {
	    nums.forEach(function (el) {
	      var to = +el.dataset.count, suf = el.dataset.suf || '', dec = +(el.dataset.dec || 0), o = { v: 0 };
	      el.textContent = (0).toFixed(dec) + suf;
	      ST.create({
	        trigger: el, start: 'top 92%', once: true,
	        onEnter: function () { gsap.to(o, { v: to, duration: 1.8, ease: 'power2.out', onUpdate: function () { el.textContent = o.v.toFixed(dec) + suf; } }); }
	      });
	    });
	    return function () { nums.forEach(function (el) { el.textContent = (+el.dataset.count).toFixed(+(el.dataset.dec || 0)) + (el.dataset.suf || ''); }); };
	  });
	}
})();
