<?php
/**
 * Bloque: Planes con velocímetro (index.html, section#planes).
 *
 * A la izquierda (escritorio con escena fija): título, el velocímetro (arco SVG quieto y aguja HTML) y la lista numerada de planes; a la derecha, las tarjetas.
 * Hasta cuatro planes; el cuarto va en azul noche. La velocidad (Mbps) de cada plan mueve la aguja (el dial llega a 1000). Los botones llaman al teléfono de
 * Datos del sitio. La escena y los contadores están en view.js; sin movimiento todas las tarjetas se ven en 2 x 2.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$sec   = vgm_section( $a, 'velocimetro', '', 'planes', 'claro' );
$tag   = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h2', 'h2' );
$text  = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$plink = vg7_opt( 'phone_link' );
$plans = array_slice( vgm_items( isset( $a['plans'] ) ? $a['plans'] : array() ), 0, 4 );
$first = $plans && isset( $plans[0]['mbps'] ) ? (int) $plans[0]['mbps'] : 0;
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="pl-stage">
		<div class="pl-in sec-wrap">
			<div class="pl-side">
				<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
					<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
				<?php endif; ?>
				<<?php echo esc_attr( $tag ); ?> class="sec-title" id="<?php echo esc_attr( $sec['title_id'] ); ?>" style="--t-size:clamp(2.1rem, 4vw, 3.6rem)"><?php echo vgm_title( $text( 'title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title(). ?></<?php echo esc_attr( $tag ); ?>>
				<div class="pl-dial" aria-hidden="true">
					<div class="pl-gauge">
						<svg class="pl-arc" viewBox="0 0 320 172" focusable="false">
							<path class="pl-arc-bg" d="M20 160A140 140 0 0 1 300 160" pathLength="100"/>
							<path class="pl-arc-fill" d="M20 160A140 140 0 0 1 300 160" pathLength="100"/>
							<path class="pl-ticks" d="M36 160h8M87.1 59.7l4.7 6.5M160 36v8M284 160h-8"/>
						</svg>
						<i class="pl-needle"></i>
						<span class="pl-lab" style="left:18.75%;top:93%">0</span>
						<span class="pl-lab" style="left:31.6%;top:46%">300</span>
						<span class="pl-lab" style="left:50%;top:35%">500</span>
						<span class="pl-lab" style="left:81.25%;top:93%">1000</span>
					</div>
					<p class="pl-read"><span class="pl-from"><?php esc_html_e( 'Desde', 'vg7-marketing-bloques' ); ?></span><strong class="pl-num"><?php echo (int) $first; ?></strong><span class="pl-unit">Mbps</span></p>
				</div>
				<ol class="pl-nav" aria-hidden="true">
					<?php foreach ( $plans as $i => $plan ) : ?>
						<li<?php echo 0 === $i ? ' class="is-on"' : ''; ?>><span><?php echo esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><?php echo esc_html( isset( $plan['name'] ) ? $plan['name'] : '' ); ?></li>
					<?php endforeach; ?>
				</ol>
			</div>

			<div class="pl-cards">
				<?php foreach ( $plans as $i => $plan ) : ?>
					<?php $feats = vgm_lines( isset( $plan['feats'] ) ? $plan['feats'] : '' ); ?>
					<article class="pl-card pl-card--<?php echo (int) ( $i + 1 ); ?>" style="--k:<?php echo (int) $i; ?>">
						<header class="pl-top"><span class="spark pl-spark" aria-hidden="true"></span><h3><?php echo esc_html( isset( $plan['name'] ) ? $plan['name'] : '' ); ?></h3></header>
						<?php if ( ! empty( $plan['desc'] ) ) : ?>
							<p class="pl-desc"><?php echo esc_html( $plan['desc'] ); ?></p>
						<?php endif; ?>
						<div class="pl-mid">
							<?php echo vgm_price( isset( $plan['price'] ) ? $plan['price'] : '', 'pl-price' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_price(). ?>
							<p class="pl-speed"><span class="pl-from"><?php esc_html_e( 'Desde', 'vg7-marketing-bloques' ); ?></span><strong class="pl-mbps" data-to="<?php echo (int) ( isset( $plan['mbps'] ) ? $plan['mbps'] : 0 ); ?>"><?php echo (int) ( isset( $plan['mbps'] ) ? $plan['mbps'] : 0 ); ?></strong><span class="pl-unit">Mbps</span></p>
						</div>
						<?php if ( $feats ) : ?>
							<ul class="pl-feats">
								<?php foreach ( $feats as $feat ) : ?>
									<li><?php echo vgm_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?><?php echo esc_html( $feat ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
						<?php
						if ( $plink ) {
							echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
								array(
									'label'     => $text( 'btnLabel' ),
									'url'       => $plink,
									'icon'      => 'arrow',
									'large'     => false,
									'track'     => 'clic_llamar',
									'ubicacion' => 'plan_' . sanitize_title( isset( $plan['name'] ) ? $plan['name'] : (string) $i ),
								)
							);
						}
						?>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
