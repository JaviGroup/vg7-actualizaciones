/**
 * Bloque Planes con velocímetro. Escena fija con la aguja (sección 4 de home.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

	var pl = $('[data-vg7="velocimetro"]');
	if (pl) {
	  var cards = $$('.pl-card', pl);
	  var speeds = $$('.pl-mbps', pl).map(function (el) { return +el.dataset.to; });   // Mbps de cada plan (data-to), en el orden de las tarjetas (el dial llega hasta 1000)
	  var counters = $$('.pl-mbps', pl).map(function (el) { return { el: el, to: +el.dataset.to, o: { v: 0 } }; });
	  var paintC = function (c) { c.el.textContent = Math.round(c.o.v); };
	  var finalC = function () { counters.forEach(function (c) { c.o.v = c.to; paintC(c); }); };

	  mm.add(DESK, function () {
	    var navs = $$('.pl-nav li', pl), n = cards.length, STEP = 1.3, HOLD = 0.9, active = -1;
	    var needle = $('.pl-needle', pl), fill = $('.pl-arc-fill', pl), num = $('.pl-num', pl);
	    var dial = { v: speeds[0], j: 0 };                      // v = Mbps en pantalla; j = rebote de la aguja al cambiar de plan
	    var paintDial = function () {
	      gsap.set(needle, { rotation: (dial.v / 1000 - 0.5) * 180 + dial.j });
	      fill.style.strokeDashoffset = String(100 - dial.v / 10);
	      num.textContent = Math.round(dial.v);
	    };
	    var at = function (i) { return i ? (i - 1) * STEP + HOLD + 0.35 : 0; };     // instante en que el plan i pasa a ser el activo
	    var setActive = function (i) {
	      if (i === active) return;
	      active = i;
	      navs.forEach(function (li, k) { li.classList.toggle('is-on', k === i); });
	    };
	    // Los planes 2 a 4 esperan abajo; el primero ya esta en su sitio al llegar
	    gsap.set(cards.slice(1), { autoAlpha: 0, y: 70, scale: 0.97 });
	    counters.forEach(finalC);
	    paintDial();
	    var tl = gsap.timeline({
	      defaults: { ease: 'none' },
	      onUpdate: function () {
	        var t = tl.time(), k = 0;
	        for (var i = 0; i < n; i++) if (t >= at(i)) k = i;
	        setActive(k);
	      },
	      scrollTrigger: { trigger: $('.pl-stage', pl), start: top, end: span(4), pin: true, scrub: 0.4, anticipatePin: 1, invalidateOnRefresh: true }
	    });
	    for (var i = 1; i < n; i++) {
	      var t = (i - 1) * STEP + HOLD, feats = $$('.pl-feats li', cards[i]);
	      // La tarjeta que sale se apaga del todo antes de que entre la siguiente (si no, se veian las dos encimadas a media transicion)
	      tl.to(cards[i - 1], { autoAlpha: 0, y: -50, scale: 0.97, duration: 0.4, ease: 'power2.in' }, t)
	        .fromTo(cards[i], { autoAlpha: 0, y: 70, scale: 0.97 }, { autoAlpha: 1, y: 0, scale: 1, duration: 0.7, ease: 'power3.out', immediateRender: false }, t + 0.4)
	        .to(dial, { v: speeds[i], duration: 0.9, ease: 'power2.inOut', onUpdate: paintDial }, t)
	        .to(dial, { j: 7, duration: 0.3, ease: 'power2.out', onUpdate: paintDial }, t + 0.55)
	        .to(dial, { j: 0, duration: 0.5, ease: 'power2.inOut', onUpdate: paintDial }, t + 0.85)
	        .fromTo(feats, { opacity: 0.2, x: -12 }, { opacity: 1, x: 0, duration: 0.35, stagger: 0.12, ease: 'power2.out', immediateRender: false }, t + 0.6);
	    }
	    tl.to({}, { duration: 0.9 }, tl.duration());
	    setActive(0);
	    return function () {
	      navs.forEach(function (li, k) { li.classList.toggle('is-on', k === 0); });
	      gsap.set(cards.concat($$('.pl-feats li', pl), [needle]), { clearProps: CLR });
	      fill.style.strokeDashoffset = ''; num.textContent = speeds[0];
	    };
	  });

	  mm.add(MOB, function () {
	    stackFx(cards, 14);
	    counters.forEach(function (c, i) {
	      c.o.v = 0; paintC(c);
	      ST.create({
	        trigger: cards[i], start: 'top 86%', once: true,
	        onEnter: function () { gsap.to(c.o, { v: c.to, duration: 1.4, ease: 'power2.out', onUpdate: function () { paintC(c); } }); }
	      });
	    });
	    return function () { finalC(); gsap.set(cards, { clearProps: CLR }); };
	  });
	}
})();
