/**
 * Bloque Nosotros: campos del editor.
 */
VG7Editor.register('vg7-marketing/nosotros', [
	{ title: 'Razones', fields: [
		{ key: 'reasons', type: 'repeater', itemLabel: 'Razón', titleKey: 'title', min: 1, max: 3, help: 'Cada razón lleva su ficha flotante junto al asesor. En escritorio se llenan una por una al bajar.', add: { icon: 'tag', title: 'Nueva razón', text: 'Texto de apoyo', chipTitle: 'Ficha', chipText: 'Texto corto' }, fields: [
			{ key: 'icon', label: 'Ícono', type: 'select', options: [ { label: 'Rayo (velocidad)', value: 'bolt' }, { label: 'Etiqueta (precio)', value: 'tag' }, { label: 'Estrella', value: 'star' }, { label: 'Mensaje (soporte)', value: 'chat' }, { label: 'Casa', value: 'home' }, { label: 'Teléfono', value: 'phone' }, { label: 'Palomita', value: 'check' } ] },
			{ key: 'title', label: 'Título' },
			{ key: 'text', label: 'Texto de apoyo' },
			{ key: 'chipTitle', label: 'Ficha flotante: texto grande' },
			{ key: 'chipText', label: 'Ficha flotante: texto chico' }
		] },
		{ key: 'listLabel', label: 'Nombre de la lista (para lectores de pantalla)' }
	] },
	{ title: 'Asesor', fields: [
		{ key: 'image', label: 'Imagen del asesor', type: 'image', help: 'Por defecto, la foto del sitio (560 x 1059 px, fondo transparente, recortada a la altura de la cintura).' },
		{ key: 'imageAlt', label: 'Descripción de la imagen (para lectores de pantalla)' }
	] },
	{ title: 'Barra de contacto', fields: [
		{ key: 'advTitle', label: 'Título' },
		{ key: 'advLabel', label: 'Botón de llamar: texto', help: 'El teléfono sale de Datos del sitio. Sin teléfono, el botón no se muestra.' }
	] },
	{ title: 'Avanzado', fields: [
		{ key: 'ariaLabel', label: 'Nombre de la sección (para lectores de pantalla)' },
		VG7Editor.SECTION_ID
	] }
]);
