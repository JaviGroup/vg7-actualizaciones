/**
 * Bloque Nosotros. Escena fija con las tres razones (sección 2 de home.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

	var ns = $('[data-vg7="nosotros"]');
	if (ns) {
	  var nsItems = $$('.ns-item', ns), nsChips = $$('.ns-chip', ns), nsAdv = $('.ns-adv', ns), nsList = $('.ns-list', ns);
	  var nsVisual = $('.ns-visual', ns), nsDisc = $('.ns-disc', ns), nsMan = $('.ns-man', ns), nsRings = $$('.ns-disc i', ns);
	  var nsOn = function (i) { nsItems.forEach(function (it, k) { it.classList.toggle('is-on', k === i); }); };

	  mm.add(DESK, function () {
	    var n = nsItems.length, STEP = 1, active = -1, stg = $('.ns-stage', ns);
	    var setActive = function (i) { if (i !== active) { active = i; nsOn(i); } };
	    gsap.set(nsChips, { autoAlpha: 0, scale: 0.6, y: 20 });
	    gsap.set(nsChips[0], { autoAlpha: 1, scale: 1, y: 0 });
	    gsap.set(nsAdv, { autoAlpha: 0, y: 50 });
	    setActive(0);
	    // Antes de fijarse: el arco crece y el asesor sube (termina justo cuando empieza la escena fija)
	    var enter = { trigger: stg, start: 'top 96%', end: top, scrub: true };
	    gsap.fromTo(nsDisc, { scale: 0.78, yPercent: 8, transformOrigin: '50% 100%' }, { scale: 1, yPercent: 0, ease: 'none', scrollTrigger: enter });
	    gsap.fromTo(nsMan, { y: 120, scale: 0.92, transformOrigin: '50% 100%' }, { y: 0, scale: 1, ease: 'none', scrollTrigger: enter });
	    var tl = gsap.timeline({
	      defaults: { ease: 'none' },
	      onUpdate: function () {
	        var t = tl.time();
	        setActive(clamp(Math.floor(t / STEP), 0, n - 1));
	        nsList.style.setProperty('--p', clamp(t / ((n - 1) * STEP + 0.5), 0, 1).toFixed(3));
	      },
	      scrollTrigger: { trigger: stg, start: top, end: span(3), pin: true, scrub: 0.4, anticipatePin: 1, invalidateOnRefresh: true }
	    });
	    // Los arcos interiores se agrandan despacio (el arco y el asesor ya tienen su propia animacion de entrada: se animan solo los hijos)
	    tl.fromTo(nsRings, { scale: 1 }, { scale: 1.07, transformOrigin: '50% 100%', duration: 3.6, stagger: 0.2 }, 0);
	    for (var i = 1; i < n; i++) {
	      tl.to(nsChips[i - 1], { autoAlpha: 0, scale: 0.7, y: -20, duration: 0.25, ease: 'power2.in' }, i * STEP - 0.05)
	        .fromTo(nsChips[i], { autoAlpha: 0, scale: 0.6, y: 20 }, { autoAlpha: 1, scale: 1, y: 0, duration: 0.5, ease: 'back.out(1.6)', immediateRender: false }, i * STEP + 0.1);
	    }
	    tl.to(nsAdv, { autoAlpha: 1, y: 0, duration: 0.6, ease: 'power3.out' }, (n - 1) * STEP + 0.45)
	      .to({}, { duration: 0.6 }, tl.duration());
	    return function () {
	      nsOn(-1); nsList.style.removeProperty('--p');
	      gsap.set(nsChips.concat([nsAdv, nsDisc, nsMan], nsRings), { clearProps: CLR });
	    };
	  });

	  mm.add(MOB, function () {
	    gsap.fromTo(nsDisc, { scale: 0.82, transformOrigin: '50% 100%' }, { scale: 1, ease: 'none', scrollTrigger: { trigger: nsVisual, start: 'top 92%', end: 'top 40%', scrub: true } });
	    gsap.fromTo(nsMan, { y: 70 }, { y: 0, ease: 'none', scrollTrigger: { trigger: nsVisual, start: 'top 90%', end: 'top 35%', scrub: true } });
	    var made = nsItems.map(function (it, i) {
	      gsap.fromTo(it, { x: -26, opacity: 0.4 }, { x: 0, opacity: 1, ease: 'none', scrollTrigger: { trigger: it, start: 'top 95%', end: 'top 72%', scrub: true } });
	      return ST.create({ trigger: it, start: 'top 62%', onEnter: function () { nsOn(i); }, onLeaveBack: function () { nsOn(i - 1); } });
	    });
	    return function () { made.forEach(function (s) { s.kill(); }); nsOn(-1); gsap.set(nsItems.concat([nsDisc, nsMan]), { clearProps: CLR }); };
	  });
	}
})();
