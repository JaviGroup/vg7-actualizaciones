<?php
/**
 * Bloque: Nosotros (index.html, section#nosotros).
 *
 * El asesor (imagen con fondo transparente) sobre un arco verde y la lista de razones; cada razón lleva su ficha flotante junto al asesor (solo en la
 * escena fija de escritorio). Al final, la barra azul "Contacta a un asesor" con el botón de llamar (el teléfono sale de Datos del sitio). Las escenas están en view.js.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a       = $attributes;
$sec     = vgm_section( $a, 'nosotros', '', 'nosotros', 'claro', isset( $a['ariaLabel'] ) ? (string) $a['ariaLabel'] : '' );
$text    = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$plink   = vg7_opt( 'phone_link' );
$reasons = array_slice( vgm_items( isset( $a['reasons'] ) ? $a['reasons'] : array() ), 0, 3 );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="ns-stage">
		<div class="ns-in sec-wrap">
			<div class="ns-visual">
				<div class="ns-disc" aria-hidden="true"><i></i><i></i></div>
				<?php
				echo vgm_pic( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_pic().
					isset( $a['image'] ) ? (int) $a['image'] : 0,
					'asesor.webp',
					'asesor-sm.webp',
					array(
						'w'     => 560,
						'h'     => 1059,
						'ws'    => 400,
						'class' => 'ns-man',
						'alt'   => $text( 'imageAlt' ),
						'sizes' => '(min-width: 900px) 350px, 72vw',
					)
				);
				?>
				<?php foreach ( $reasons as $i => $r ) : ?>
					<?php
					echo vgm_chip( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_chip().
						array(
							'icon'  => isset( $r['icon'] ) ? $r['icon'] : 'tag',
							'title' => isset( $r['chipTitle'] ) ? $r['chipTitle'] : '',
							'text'  => isset( $r['chipText'] ) ? $r['chipText'] : '',
							'amber' => 2 === $i,
						),
						'he-chip ns-chip ns-chip--' . ( $i + 1 )
					);
					?>
				<?php endforeach; ?>
				<span class="spark ns-spk ns-spk--1" aria-hidden="true"></span>
				<span class="spark ns-spk ns-spk--2" aria-hidden="true"></span>
			</div>
			<div class="ns-copy">
				<?php if ( $reasons ) : ?>
					<ul class="ns-list" aria-label="<?php echo esc_attr( $text( 'listLabel' ) ); ?>">
						<?php foreach ( $reasons as $i => $r ) : ?>
							<li class="ns-item<?php echo 0 === $i ? ' is-on' : ''; ?>" style="--k:<?php echo (int) $i; ?>"><span class="ns-ico" aria-hidden="true"><?php echo vgm_icon( isset( $r['icon'] ) ? $r['icon'] : 'tag' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></span><div class="ns-tx"><strong><?php echo esc_html( isset( $r['title'] ) ? $r['title'] : '' ); ?></strong><span><?php echo esc_html( isset( $r['text'] ) ? $r['text'] : '' ); ?></span></div><span class="ns-n" aria-hidden="true"><?php echo esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<div class="ns-adv" data-tono="oscuro">
					<span class="ns-adv-ico" aria-hidden="true"><?php echo vgm_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></span>
					<h3><?php echo esc_html( $text( 'advTitle' ) ); ?></h3>
					<?php
					if ( $plink ) {
						echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
							array(
								'label'     => $text( 'advLabel' ),
								'url'       => $plink,
								'icon'      => 'phone',
								'large'     => false,
								'track'     => 'clic_llamar',
								'ubicacion' => 'asesor',
							)
						);
					}
					?>
				</div>
			</div>
		</div>
	</div>
</section>
