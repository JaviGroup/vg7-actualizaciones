/**
 * Bloque Hero con celular y onda: campos del editor.
 */
VG7Editor.register('vg7-marketing/hero', [
	{ title: 'Encabezado', fields: [
		{ key: 'eyebrow', label: 'Etiqueta superior', help: 'Déjala vacía para quitarla.' },
		{ key: 'title', label: 'Título', type: 'textarea', rows: 3, help: 'Una línea del campo = una línea del título. Lo que escribas entre *asteriscos* sale con el degradado verde (por ejemplo: Vive *sin límites.*).' },
		VG7Editor.HEADING,
		{ key: 'lead', label: 'Texto de apoyo', type: 'textarea', rows: 4 }
	] },
	{ title: 'Botones', fields: [
		{ key: 'callLabel', label: 'Botón de llamar: texto', help: 'El teléfono sale de Datos del sitio (Apariencia, Personalizar). Sin teléfono, el botón no se muestra.' },
		{ key: 'plansLabel', label: 'Botón secundario: texto', help: 'Déjalo vacío para quitarlo.' },
		{ key: 'plansUrl', label: 'Botón secundario: dirección', type: 'url', help: 'Por defecto baja a la sección de planes de la página (#planes).' }
	] },
	{ title: 'Celular y fichas', fields: [
		{ key: 'image', label: 'Imagen del celular', type: 'image', help: 'Por defecto, el celular del sitio (555 x 1319 px, fondo transparente).' },
		{ key: 'imageAlt', label: 'Descripción de la imagen (para lectores de pantalla)' },
		{ key: 'chips', type: 'repeater', itemLabel: 'Ficha', titleKey: 'title', min: 0, max: 4, help: 'Flotan alrededor del celular (en móvil solo se ven dos).', add: { icon: 'bolt', title: 'Nueva ficha', text: 'Texto corto', amber: false }, fields: [
			{ key: 'icon', label: 'Ícono', type: 'select', options: [ { label: 'Rayo (velocidad)', value: 'bolt' }, { label: 'Etiqueta (precio)', value: 'tag' }, { label: 'Estrella', value: 'star' }, { label: 'Mensaje (soporte)', value: 'chat' }, { label: 'Casa', value: 'home' }, { label: 'Teléfono', value: 'phone' }, { label: 'Palomita', value: 'check' } ] },
			{ key: 'title', label: 'Texto grande' },
			{ key: 'text', label: 'Texto chico' },
			{ key: 'amber', label: 'Ícono ámbar', type: 'toggle' }
		] }
	] },
	{ title: 'Frase de la onda', fields: [
		{ key: 'stateEyebrow', label: 'Etiqueta de la frase', help: 'Déjala vacía para quitarla.' },
		{ key: 'state', label: 'Frase', type: 'textarea', rows: 3, help: 'Se enciende palabra por palabra. Lo que va entre *asteriscos* sale en verde.' },
		{ key: 'stateSub', label: 'Texto bajo la frase', type: 'textarea', rows: 4 }
	] },
	{ title: 'Avanzado', fields: [
		{ key: 'cueUrl', label: 'Indicador de scroll: enlace', type: 'url', help: 'Por defecto baja a la sección siguiente (#nosotros). Vacío = sin indicador.' },
		VG7Editor.SECTION_ID
	] }
]);
