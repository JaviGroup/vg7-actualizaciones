/**
 * Bloque Hero con celular y onda. Escena fija de la Home (sección 1 de home.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

	var stage = $('.he-stage');
	if (stage) {
	  var hero = $('.hero'), scene = $('.he-scene', stage), content = $('.he-content', stage), vis = $('.he-vis', stage), ph = $('.he-ph', stage), phone = $('.he-phone', stage);
	  var rings = $('.he-rings', stage), chips = $$('.he-chip', stage), bg = $('.he-bg', stage), lines = $('.he-lines', stage), cue = $('.he-scroll', stage);
	  var flood = $('.he-flood', stage), state = $('.he-statement', stage), msw = $$('.ms-w', state), sg = $$('.sg', state);
	  var eyebrow = $('.he-eyebrow', state), sub = $('.he-sub', state);
	  // Hacia donde sale cada ficha (fraccion del ancho y del alto de la pantalla)
	  var fly = [[-0.3, -0.24], [0.34, -0.14], [-0.34, 0.22], [0.3, 0.28]];

	  // Las animaciones infinitas se pausan cuando el hero ya no se ve
	  if (window.IntersectionObserver) {
	    new IntersectionObserver(function (en) { hero.classList.toggle('is-off', !en[0].isIntersecting); }, { rootMargin: '80px 0px' }).observe(stage);
	  }

	  mm.add(DESK, function () {
	    // La frase empieza apagada; el celular y las ondas viajan al centro de la escena
	    gsap.set(msw, { opacity: 0.14 });
	    gsap.set([eyebrow, sub], { opacity: 0, y: 24 });
	    gsap.set(sg, { autoAlpha: 0, scale: 0.6 });
	    var toCenter = function () {
	      var s = scene.getBoundingClientRect(), v = vis.getBoundingClientRect();
	      return (s.left + s.width / 2) - (v.left + v.width / 2);
	    };
	    var tl = gsap.timeline({
	      defaults: { ease: 'none' },
	      scrollTrigger: { trigger: stage, start: top, end: span(3.6), pin: true, scrub: 0.3, anticipatePin: 1, invalidateOnRefresh: true }
	    });
	    // Rendimiento: las ondas se apagan mientras crecen y, cuando el circulo ya cubre toda la pantalla (t = 0,55 + 1,5 x 0,69),
	    // la escena de abajo se oculta (visibility) para que deje de pintarse mientras se lee la frase.
	    tl.to(content, { y: -80, opacity: 0, ease: 'power2.in', duration: 0.8 }, 0)
	      .to(cue, { opacity: 0, duration: 0.3 }, 0)
	      .to(bg, { scale: 1.25, duration: 2.2 }, 0)
	      .to([ph, rings], { x: toCenter, ease: 'power2.inOut', duration: 1.2 }, 0)
	      .to(ph, { scale: 1.12, ease: 'power2.inOut', duration: 1.2 }, 0)
	      .to(rings, { scale: 2.1, opacity: 0, ease: 'power2.in', duration: 1.7 }, 0.2);
	    chips.forEach(function (c, i) {
	      tl.to(c, {
	        x: function () { return window.innerWidth * fly[i][0]; }, y: function () { return window.innerHeight * fly[i][1]; },
	        scale: 0.8, opacity: 0, ease: 'power2.in', duration: 1.1
	      }, 0);
	    });
	    tl.to(ph, { scale: 1.7, y: -50, ease: 'power2.in', duration: 1, immediateRender: false }, 1.3)
	      .fromTo(flood, { clipPath: 'circle(0% at 50% 50%)' }, { clipPath: 'circle(150% at 50% 50%)', ease: 'power2.in', duration: 1.5 }, 0.55)
	      .set(scene, { visibility: 'hidden' }, 1.7)
	      .to(state, { opacity: 1, duration: 0.2 }, 1.8)
	      .to(eyebrow, { opacity: 1, y: 0, ease: 'power2.out', duration: 0.4 }, 1.85)
	      .to(sg, { autoAlpha: 1, scale: 1, ease: 'back.out(1.5)', duration: 0.9, stagger: 0.3 }, 2)
	      .to(sg, { y: function (i) { return i ? 40 : -40; }, rotation: function (i) { return i ? -40 : 40; }, duration: 2.6 }, 2.6)
	      .to(msw, { opacity: 1, duration: 0.35, stagger: 0.26 }, 2)
	      .to(sub, { opacity: 1, y: 0, ease: 'power2.out', duration: 0.6 }, 4.5)
	      .to({}, { duration: 0.7 }, 5.1);
	    // Al pasar de escritorio a movil (o girar el equipo) la reversion de GSAP no borra los estilos en linea (la frase se quedaba con opacity: 0): se limpian a mano
	    return function () { gsap.set([content, cue, bg, ph, rings, flood, scene, state, eyebrow, sub].concat(chips, sg, msw), { clearProps: CLR }); };
	  });

	  // Con raton: el celular se inclina hacia el puntero y las lineas del fondo se mueven al reves
	  mm.add('(min-width: 900px) and (prefers-reduced-motion: no-preference) and (hover: hover) and (pointer: fine)', function () {
	    gsap.set(phone, { transformPerspective: 900 });
	    var ry = gsap.quickTo(phone, 'rotationY', { duration: 0.9, ease: 'power3' }), rx = gsap.quickTo(phone, 'rotationX', { duration: 0.9, ease: 'power3' });
	    var lx = gsap.quickTo(lines, 'x', { duration: 1.2, ease: 'power3' }), ly = gsap.quickTo(lines, 'y', { duration: 1.2, ease: 'power3' });
	    var move = function (e) {
	      var r = scene.getBoundingClientRect(), nx = clamp((e.clientX - r.left) / r.width * 2 - 1, -1, 1), ny = clamp((e.clientY - r.top) / r.height * 2 - 1, -1, 1);
	      ry(nx * 9); rx(-ny * 6); lx(-nx * 24); ly(-ny * 16);
	    };
	    var leave = function () { ry(0); rx(0); lx(0); ly(0); };
	    scene.addEventListener('pointermove', move);
	    scene.addEventListener('pointerleave', leave);
	    return function () { scene.removeEventListener('pointermove', move); scene.removeEventListener('pointerleave', leave); };
	  });

	  mm.add(MOB, function () {
	    var run = { trigger: scene, start: 'top top', end: 'bottom top', scrub: true };
	    gsap.to(bg, { yPercent: 4, scale: 1.1, ease: 'none', scrollTrigger: run });
	    gsap.to(ph, { y: 36, ease: 'none', scrollTrigger: run });
	    gsap.to(rings, { scale: 1.3, ease: 'none', scrollTrigger: run });
	    gsap.fromTo(msw, { opacity: 0.14 }, {
	      opacity: 1, ease: 'none', stagger: 0.25,
	      scrollTrigger: { trigger: $('.he-state', stage), start: 'top 82%', end: 'bottom 48%', scrub: true }
	    });
	    gsap.fromTo(sg, { y: 40 }, { y: -40, ease: 'none', scrollTrigger: { trigger: state, start: 'top bottom', end: 'bottom top', scrub: true } });
	    return function () { gsap.set([bg, ph, rings].concat(sg, msw), { clearProps: CLR }); };
	  });
	}
})();
