<?php
/**
 * Bloque: Hero con celular y onda (index.html, section.hero #inicio).
 *
 * Tarjeta azul noche con el titular (una línea del campo = una línea del título), el texto, el botón de llamar y "Ver planes"; a la derecha, el celular
 * flotando en el centro de las ondas de señal, con hasta cuatro fichas y destellos. Después, la frase sobre la onda menta (en escritorio se ve al crecer
 * el círculo; en móvil es una franja). El teléfono sale de Datos del sitio (sin teléfono no sale el botón). La entrada de los textos es solo CSS ([data-r] y .wi);
 * las escenas están en view.js.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a       = $attributes;
$sec     = vgm_section( $a, 'hero', 'hero is-in', 'inicio', 'oscuro' ); // is-in: la portada ya está en pantalla al cargar, su entrada no espera al JavaScript.
$tag     = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h1', 'h1' );
$text    = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$plink   = vg7_opt( 'phone_link' );
$chips   = array_slice( vgm_items( isset( $a['chips'] ) ? $a['chips'] : array() ), 0, 4 );
$letters = array( 'a', 'b', 'c', 'd' );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="he-stage">
		<div class="he-scene">
			<div class="he-bg" aria-hidden="true"><img class="he-lines" src="<?php echo esc_url( vgm_asset( 'img/circulos.webp' ) ); ?>" width="640" height="647" alt="" decoding="async" fetchpriority="low"></div>

			<div class="he-content">
				<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
					<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
				<?php endif; ?>
				<<?php echo esc_attr( $tag ); ?> class="he-h1" id="<?php echo esc_attr( $sec['title_id'] ); ?>"><?php echo vgm_title_lines( $text( 'title' ), 'he-l' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title_lines(). ?></<?php echo esc_attr( $tag ); ?>>
				<?php if ( '' !== $text( 'lead' ) ) : ?>
					<p class="he-lead" data-r style="--d:.7s"><?php echo esc_html( $text( 'lead' ) ); ?></p>
				<?php endif; ?>
				<div class="he-actions" data-r style="--d:.85s">
					<?php
					if ( $plink ) {
						echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
							array(
								'label'     => $text( 'callLabel' ),
								'url'       => $plink,
								'icon'      => 'phone',
								'track'     => 'clic_llamar',
								'ubicacion' => 'hero',
							)
						);
					}
					echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
						array(
							'label'   => $text( 'plansLabel' ),
							'url'     => $text( 'plansUrl' ),
							'variant' => 'ghost',
							'icon'    => 'arrow',
						)
					);
					?>
				</div>
			</div>

			<div class="he-vis">
				<div class="he-rings" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
				<div class="he-ph">
					<div class="he-float">
						<?php
						echo vgm_pic( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_pic().
							isset( $a['image'] ) ? (int) $a['image'] : 0,
							'phone-planes.webp',
							'phone-planes-sm.webp',
							array(
								'w'             => 555,
								'h'             => 1319,
								'ws'            => 360,
								'class'         => 'he-phone',
								'alt'           => $text( 'imageAlt' ),
								'sizes'         => '(min-width: 900px) 300px, 240px',
								'loading'       => 'eager',
								'fetchpriority' => 'high',
							)
						);
						?>
					</div>
				</div>
				<?php foreach ( $chips as $i => $chip ) : ?>
					<?php echo vgm_chip( $chip, 'he-chip he-chip--' . $letters[ $i ] ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_chip(). ?>
				<?php endforeach; ?>
				<span class="spark he-spk he-spk--1" aria-hidden="true"></span>
				<span class="spark he-spk he-spk--2" aria-hidden="true"></span>
				<span class="spark he-spk he-spk--3" aria-hidden="true"></span>
			</div>

			<?php if ( '' !== $text( 'cueUrl' ) ) : ?>
				<a class="he-scroll" href="<?php echo esc_url( vgm_url( $text( 'cueUrl' ) ), array( 'http', 'https' ) ); ?>" aria-label="<?php esc_attr_e( 'Seguir bajando', 'vg7-marketing-bloques' ); ?>"><span></span></a>
			<?php endif; ?>
		</div>

		<div class="he-flood" aria-hidden="true"></div>

		<div class="he-statement">
			<span class="spark sg sg--1" aria-hidden="true"></span>
			<span class="spark sg sg--2" aria-hidden="true"></span>
			<?php if ( '' !== $text( 'stateEyebrow' ) ) : ?>
				<p class="sec-eyebrow he-eyebrow"><?php echo esc_html( $text( 'stateEyebrow' ) ); ?></p>
			<?php endif; ?>
			<h2 class="he-state" id="<?php echo esc_attr( $sec['title_id'] ); ?>-frase"><?php echo vgm_frase( $text( 'state' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_frase(). ?></h2>
			<?php if ( '' !== $text( 'stateSub' ) ) : ?>
				<p class="he-sub"><?php echo esc_html( $text( 'stateSub' ) ); ?></p>
			<?php endif; ?>
		</div>
	</div>
</section>
