<?php
/**
 * Bloque: Hero de Planes (planes.html, section.ph #inicio).
 *
 * Titular de una o dos líneas (una línea del campo = una línea), texto, "Elegir mi plan" y llamar; a la derecha la mujer (imagen con fondo transparente,
 * cortada a la cintura, pegada al borde de abajo) sobre un arco verde, la velocidad en contorno que cuenta al cargar y hasta tres fichas. Con escena fija, el hero
 * queda pegado bajo el header y la siguiente sección (bloque Baraja de planes) sube a taparlo. La entrada de los textos es CSS; las escenas están en view.js.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a       = $attributes;
$sec     = vgm_section( $a, 'hero-planes', 'ph is-in', 'inicio', 'oscuro' ); // is-in: la portada ya está en pantalla al cargar.
$tag     = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h1', 'h1' );
$text    = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$plink   = vg7_opt( 'phone_link' );
$chips   = array_slice( vgm_items( isset( $a['chips'] ) ? $a['chips'] : array() ), 0, 3 );
$letters = array( 'a', 'b', 'c' );
$speed   = (int) preg_replace( '/\D/', '', $text( 'speed' ) );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="ph-scene">
		<div class="ph-bg" aria-hidden="true"><img class="ph-lines" src="<?php echo esc_url( vgm_asset( 'img/circulos.webp' ) ); ?>" width="640" height="647" alt="" decoding="async" fetchpriority="low"></div>

		<div class="ph-content">
			<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
				<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
			<?php endif; ?>
			<<?php echo esc_attr( $tag ); ?> class="ph-h1" id="<?php echo esc_attr( $sec['title_id'] ); ?>"><?php echo vgm_title_lines( $text( 'title' ), 'ph-l' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title_lines(). ?></<?php echo esc_attr( $tag ); ?>>
			<?php if ( '' !== $text( 'lead' ) ) : ?>
				<p class="ph-lead" data-r style="--d:.7s"><?php echo esc_html( $text( 'lead' ) ); ?></p>
			<?php endif; ?>
			<div class="ph-actions" data-r style="--d:.85s">
				<?php
				echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
					array(
						'label' => $text( 'plansLabel' ),
						'url'   => $text( 'plansUrl' ),
						'icon'  => 'down',
					)
				);
				if ( $plink ) {
					echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
						array(
							'label'     => $text( 'callLabel' ),
							'url'       => $plink,
							'variant'   => 'ghost',
							'icon'      => 'phone',
							'icon_pos'  => 'before',
							'track'     => 'clic_llamar',
							'ubicacion' => 'hero',
						)
					);
				}
				?>
			</div>
		</div>

		<div class="ph-vis">
			<div class="ph-arch" aria-hidden="true"></div>
			<div class="ph-speed" aria-hidden="true"><span class="ph-num" data-to="<?php echo (int) $speed; ?>"><?php echo (int) $speed; ?></span><span class="ph-unit"><?php echo esc_html( $text( 'unit' ) ); ?></span></div>
			<?php
			echo vgm_pic( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_pic().
				isset( $a['image'] ) ? (int) $a['image'] : 0,
				'mujer.webp',
				'mujer-sm.webp',
				array(
					'w'             => 640,
					'h'             => 937,
					'ws'            => 420,
					'class'         => 'ph-woman',
					'alt'           => $text( 'imageAlt' ),
					'sizes'         => '(min-width: 900px) 440px, 300px',
					'loading'       => 'eager',
					'fetchpriority' => 'high',
				)
			);
			?>
			<?php foreach ( $chips as $i => $chip ) : ?>
				<?php echo vgm_chip( $chip, 'ph-chip ph-chip--' . $letters[ $i ], 'ph-chip-in' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_chip(). ?>
			<?php endforeach; ?>
			<span class="spark ph-spk ph-spk--1" aria-hidden="true"></span>
			<span class="spark ph-spk ph-spk--2" aria-hidden="true"></span>
		</div>
	</div>
</section>
