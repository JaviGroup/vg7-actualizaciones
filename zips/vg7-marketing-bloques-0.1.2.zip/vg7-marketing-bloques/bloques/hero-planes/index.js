/**
 * Bloque Hero de Planes: campos del editor.
 */
VG7Editor.register('vg7-marketing/hero-planes', [
	{ title: 'Encabezado', fields: [
		{ key: 'eyebrow', label: 'Etiqueta superior', help: 'Déjala vacía para quitarla.' },
		{ key: 'title', label: 'Título', type: 'textarea', rows: 3, help: 'Una línea del campo = una línea del título. Lo que escribas entre *asteriscos* sale con el degradado verde (por ejemplo: para *tu día a día*).' },
		VG7Editor.HEADING,
		{ key: 'lead', label: 'Texto de apoyo', type: 'textarea', rows: 4 }
	] },
	{ title: 'Botones', fields: [
		{ key: 'plansLabel', label: 'Botón principal: texto' },
		{ key: 'plansUrl', label: 'Botón principal: dirección', type: 'url', help: 'Por defecto baja a las tarjetas de planes de la página (#planes) y las deja abiertas.' },
		{ key: 'callLabel', label: 'Botón de llamar: texto', help: 'El teléfono sale de Datos del sitio. Sin teléfono, el botón no se muestra.' }
	] },
	{ title: 'Mujer, velocidad y fichas', fields: [
		{ key: 'image', label: 'Imagen de la mujer', type: 'image', help: 'Por defecto, la foto del sitio (769 x 1126 px, fondo transparente, cortada a la cintura: queda pegada al borde de abajo).' },
		{ key: 'imageAlt', label: 'Descripción de la imagen (para lectores de pantalla)' },
		{ key: 'speed', label: 'Velocidad en contorno (solo el número)', help: 'Cuenta de 0 a este valor al cargar la página.' },
		{ key: 'unit', label: 'Unidad (por ejemplo Mbps)' },
		{ key: 'chips', type: 'repeater', itemLabel: 'Ficha', titleKey: 'title', min: 0, max: 3, help: 'Flotan junto a la mujer (en móvil solo se ven dos).', add: { icon: 'bolt', title: 'Nueva ficha', text: 'Texto corto', amber: false }, fields: [
			{ key: 'icon', label: 'Ícono', type: 'select', options: [ { label: 'Rayo (velocidad)', value: 'bolt' }, { label: 'Etiqueta (precio)', value: 'tag' }, { label: 'Estrella', value: 'star' }, { label: 'Mensaje (soporte)', value: 'chat' }, { label: 'Casa', value: 'home' }, { label: 'Teléfono', value: 'phone' }, { label: 'Palomita', value: 'check' } ] },
			{ key: 'title', label: 'Texto grande' },
			{ key: 'text', label: 'Texto chico' },
			{ key: 'amber', label: 'Ícono ámbar', type: 'toggle' }
		] }
	] },
	{ title: 'Avanzado', fields: [
		VG7Editor.SECTION_ID
	] }
]);
