/**
 * Bloque Hero de Planes. Velocidad que cuenta y hero que se achica mientras la sección de planes lo tapa (sección 2 de planes.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

var planes = $('[data-vg7="baraja"]');   // la sección de planes que sube a tapar al hero
	var hero = $('.ph');
	if (hero) {
	  var scene = $('.ph-scene', hero), content = $('.ph-content', hero), num = $('.ph-num', hero);
	  mm.add(MOTION, function () {
	    var fin = num ? +num.dataset.to : 0, o = { v: 0 }, count = null;
	    if (num) {
	      num.textContent = '0';
	      count = gsap.to(o, { v: fin, duration: 2.6, delay: 0.6, ease: 'power2.out', onUpdate: function () { num.textContent = Math.round(o.v); } });
	    }
	    // Las animaciones infinitas se pausan cuando el hero ya quedo tapado
	    var off = planes ? ST.create({ trigger: planes, start: top, onEnter: function () { hero.classList.add('is-off'); }, onLeaveBack: function () { hero.classList.remove('is-off'); } }) : null;
	    return function () {
	      if (count) count.kill();
	      if (off) off.kill();
	      hero.classList.remove('is-off');
	      if (num) num.textContent = fin;
	    };
	  });
	  mm.add(DESK, function () {
	    if (!planes) return;
	    var cover = { trigger: planes, start: 'top bottom', end: top, scrub: true };
	    gsap.fromTo(scene, { scale: 1 }, { scale: 0.93, ease: 'none', scrollTrigger: cover });
	    gsap.fromTo(content, { y: 0, opacity: 1 }, { y: -50, opacity: 0.2, ease: 'none', scrollTrigger: cover });
	    return function () { gsap.set([scene, content], { clearProps: CLR }); };
	  });
	}
})();
