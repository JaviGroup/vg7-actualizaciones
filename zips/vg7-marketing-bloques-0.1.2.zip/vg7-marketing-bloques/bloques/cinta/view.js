/**
 * Bloque Cinta. Corre más rápido al bajar y se inclina con la velocidad (sección 3 de home.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

	var ticker = $('.ticker'), track = $('.tk-track');
	if (ticker && track) {
	  mm.add(MOTION, function () {
	    ticker.classList.add('tk-js');
	    var half = 0, x = 0, boost = 0, vel = 0;
	    var measure = function () { half = track.scrollWidth / 2; };
	    measure();
	    var sk = gsap.quickSetter(track, 'skewX', 'deg');
	    var st = ST.create({ start: 0, end: 'max', onUpdate: function (self) { vel = self.getVelocity(); } });
	    var tick = function (t, dt) {
	      boost += (clamp(vel / 7, -900, 900) - boost) * 0.12;
	      x += (-70 - boost) * dt / 1000;
	      if (half) { if (x <= -half) x += half; if (x > 0) x -= half; }
	      gsap.set(track, { x: x });
	      sk(clamp(-boost / 90, -7, 7));
	      vel *= 0.9;
	    };
	    gsap.ticker.add(tick);
	    ST.addEventListener('refresh', measure);
	    return function () {
	      gsap.ticker.remove(tick); st.kill(); ST.removeEventListener('refresh', measure);
	      ticker.classList.remove('tk-js'); gsap.set(track, { clearProps: CLR });
	    };
	  });
	}
})();
