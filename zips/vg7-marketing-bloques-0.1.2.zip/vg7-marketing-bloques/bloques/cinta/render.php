<?php
/**
 * Bloque: Cinta (index.html, div.ticker).
 *
 * Dos copias de la lista (la segunda oculta para lectores de pantalla) para que el recorrido no tenga cortes. El movimiento está en view.js y en el CSS.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$items = vgm_lines( isset( $a['items'] ) ? $a['items'] : '' );
$attrs = get_block_wrapper_attributes(
	array(
		'class'      => 'ticker',
		'data-vg7'   => 'cinta',
		'data-tono'  => 'oscuro',
		'aria-label' => isset( $a['ariaLabel'] ) ? (string) $a['ariaLabel'] : '',
	)
);
if ( ! $items ) {
	return;
}
?>
<div <?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<div class="tk-track">
		<ul class="tk-set">
			<?php foreach ( $items as $item ) : ?>
				<li><?php echo esc_html( $item ); ?></li>
			<?php endforeach; ?>
		</ul>
		<ul class="tk-set" aria-hidden="true">
			<?php foreach ( $items as $item ) : ?>
				<li><?php echo esc_html( $item ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>
