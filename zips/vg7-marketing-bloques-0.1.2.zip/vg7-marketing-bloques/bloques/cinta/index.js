/**
 * Bloque Cinta: campos del editor.
 */
VG7Editor.register('vg7-marketing/cinta', [
	{ title: 'Frases', fields: [
		{ key: 'items', label: 'Frases', type: 'textarea', rows: 8, help: 'Una por línea. Se repiten en bucle.' },
		{ key: 'ariaLabel', label: 'Nombre de la cinta (para lectores de pantalla)' }
	] }
]);
