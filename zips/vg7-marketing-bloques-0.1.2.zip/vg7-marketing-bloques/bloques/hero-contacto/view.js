/**
 * Bloque Hero de Contacto. Escena fija de dos tiempos: titular y datos de contacto, con el radar que se enciende (contacto.js del diseño aprobado).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

var hero = $('.ch');
	// Escena fija del hero: escritorio con movimiento y al menos 620 px de alto (el CSS usa la misma condicion)
	var PIN = '(min-width: 900px) and (min-height: 620px) and (prefers-reduced-motion: no-preference)';

	/* Hero (todos los tamanos): las animaciones infinitas se pausan cuando el hero ya salio de la pantalla */
	if (hero) {
	  mm.add(MOTION, function () {
	    var off = ST.create({ trigger: hero, start: 'bottom top', onEnter: function () { hero.classList.add('is-off'); }, onLeaveBack: function () { hero.classList.remove('is-off'); } });
	    return function () { off.kill(); hero.classList.remove('is-off'); };
	  });
	  /* Escena fija (escritorio con 620 px de alto): primero el titular; despues los arcos se encienden de adentro hacia afuera y crecen mientras
	     el titular se va y los datos de contacto toman su lugar. */
	  mm.add(PIN, function () {
	    var stg = $('.ch-stage', hero), a = $('.ch-a', hero), b = $('.ch-b', hero), box = $('.ch-arcs', hero), arcs = $$('.ch-arcs i', hero), orb = $('.ch-orb', hero), cue = $('.ch-cue', hero);
	    gsap.set(b, { autoAlpha: 0, y: 54, scale: 0.92 });
	    gsap.set(arcs, { opacity: 0.2 });
	    var tl = gsap.timeline({
	      defaults: { ease: 'none' },
	      scrollTrigger: { trigger: stg, start: top, end: span(1.8), pin: true, scrub: 0.4, anticipatePin: 1, invalidateOnRefresh: true }
	    });
	    tl.to(cue, { autoAlpha: 0, duration: 0.2 }, 0)
	      .to(box, { scale: 1.4, duration: 2.6 }, 0)
	      .to(a, { y: -80, autoAlpha: 0, duration: 0.8, ease: 'power1.in' }, 0.25)
	      .to(orb, { scale: 1.25, duration: 1, ease: 'power2.out' }, 0.9);
	    arcs.forEach(function (el, i) { tl.to(el, { opacity: 0.9, duration: 0.3 }, 0.4 + i * 0.3); });
	    tl.to(b, { autoAlpha: 1, y: 0, scale: 1, duration: 0.9, ease: 'power3.out' }, 1.35)
	      .to({}, { duration: 0.6 }, tl.duration());
	    return function () { gsap.set([a, b, box, orb, cue].concat(arcs), { clearProps: CLR }); };
	  });
	}
})();
