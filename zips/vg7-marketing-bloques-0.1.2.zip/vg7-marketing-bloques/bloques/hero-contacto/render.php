<?php
/**
 * Bloque: Hero de Contacto (contacto.html, section.ch #inicio).
 *
 * Radar de señal (cuatro arcos y un teléfono que suena en el origen) y dos capas de contenido: el titular con el botón de llamar y, después, los datos de contacto en
 * grande (teléfono y correo de Datos del sitio) con "Ir al formulario". Con escena fija (escritorio con movimiento) las capas se relevan al bajar mientras los arcos se
 * encienden; sin ella (móvil, poca altura o sin movimiento) se apilan. La entrada de los textos es CSS; las escenas están en view.js.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$sec   = vgm_section( $a, 'hero-contacto', 'ch is-in', 'inicio', 'bosque' ); // is-in: la portada ya está en pantalla al cargar.
$tag   = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h1', 'h1' );
$text  = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$phone = vg7_opt( 'phone' );
$plink = vg7_opt( 'phone_link' );
$email = vg7_opt( 'email' );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="ch-stage">
		<div class="ch-arcs" aria-hidden="true">
			<i style="--k:1"></i><i style="--k:2"></i><i style="--k:3"></i><i style="--k:4"></i>
			<b class="ch-orb"><?php echo vgm_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?></b>
		</div>

		<div class="ch-body sec-wrap">
			<div class="ch-a">
				<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
					<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
				<?php endif; ?>
				<<?php echo esc_attr( $tag ); ?> class="ch-h1" id="<?php echo esc_attr( $sec['title_id'] ); ?>"><?php echo vgm_title( $text( 'title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title(). ?></<?php echo esc_attr( $tag ); ?>>
				<?php if ( '' !== $text( 'lead' ) ) : ?>
					<p class="ch-lead" data-r style="--d:.6s"><?php echo esc_html( $text( 'lead' ) ); ?></p>
				<?php endif; ?>
				<?php if ( $plink && '' !== $text( 'callLabel' ) ) : ?>
					<div class="ch-actions" data-r style="--d:.75s">
						<?php
						echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
							array(
								'label'     => $text( 'callLabel' ),
								'url'       => $plink,
								'icon'      => 'phone',
								'track'     => 'clic_llamar',
								'ubicacion' => 'hero',
							)
						);
						?>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( ( $phone && $plink ) || $email || '' !== $text( 'formLabel' ) ) : ?>
				<div class="ch-b">
					<?php if ( $phone && $plink ) : ?>
						<p class="ch-k" data-r style="--d:.9s"><?php echo esc_html( $text( 'phoneLabel' ) ); ?></p>
						<a class="ch-num" href="<?php echo esc_url( $plink, array( 'tel', 'http', 'https' ) ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="hero_numero" data-r style="--d:1s"><?php echo esc_html( $phone ); ?></a>
					<?php endif; ?>
					<?php if ( $email ) : ?>
						<p class="ch-k" data-r style="--d:1.1s"><?php echo esc_html( $text( 'mailLabel' ) ); ?></p>
						<a class="ch-mail" href="<?php echo esc_url( 'mailto:' . $email, array( 'mailto' ) ); ?>" data-r style="--d:1.2s"><?php echo esc_html( $email ); ?></a>
					<?php endif; ?>
					<?php
					echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
						array(
							'label'   => $text( 'formLabel' ),
							'url'     => $text( 'formUrl' ),
							'variant' => 'ghost',
							'icon'    => 'down',
							'class'   => 'ch-go',
							'attrs'   => array(
								'data-r' => '',
								'style'  => '--d:1.3s',
							),
						)
					);
					?>
				</div>
			<?php endif; ?>
		</div>

		<div class="ch-cue" aria-hidden="true"><span></span></div>
	</div>
</section>
