/**
 * Bloque Hero de Contacto: campos del editor.
 */
VG7Editor.register('vg7-marketing/hero-contacto', [
	{ title: 'Encabezado', fields: [
		{ key: 'eyebrow', label: 'Etiqueta superior', help: 'Déjala vacía para quitarla.' },
		{ key: 'title', label: 'Título', type: 'textarea', rows: 2, help: 'Lo que escribas entre *asteriscos* sale con el degradado verde (por ejemplo: Estamos aquí *para ayudarte*).' },
		VG7Editor.HEADING,
		{ key: 'lead', label: 'Texto de apoyo', type: 'textarea', rows: 3 },
		{ key: 'callLabel', label: 'Botón de llamar: texto', help: 'El teléfono sale de Datos del sitio (Apariencia, Personalizar). Sin teléfono, el botón no se muestra.' }
	] },
	{ title: 'Datos de contacto (segunda capa)', fields: [
		{ key: 'phoneLabel', label: 'Rótulo del teléfono', help: 'El teléfono gigante y el correo salen de Datos del sitio; lo que no esté escrito allí no se muestra.' },
		{ key: 'mailLabel', label: 'Rótulo del correo' },
		{ key: 'formLabel', label: 'Botón del formulario: texto', help: 'Déjalo vacío para quitarlo.' },
		{ key: 'formUrl', label: 'Botón del formulario: dirección', type: 'url', help: 'Por defecto baja al formulario de la página (#formulario).' }
	] },
	{ title: 'Avanzado', fields: [
		VG7Editor.SECTION_ID
	] }
]);
