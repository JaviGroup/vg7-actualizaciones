/**
 * Bloque Preguntas frecuentes. Acordeón (funciona sin GSAP) y destello que gira con el scroll (secciones 1 y 5 de planes.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';

	var fq = $('[data-vg7="preguntas"]');
	if (fq) {
	  var items = $$('.fq-item', fq);
	  var setOpen = function (it, open) {
	    it.classList.toggle('is-open', open);
	    $('button', it).setAttribute('aria-expanded', String(open));
	  };
	  items.forEach(function (it) {
	    $('button', it).addEventListener('click', function () {
	      var open = !it.classList.contains('is-open');
	      items.forEach(function (o) { setOpen(o, o === it ? open : false); });
	      // La altura de la pagina cambia mientras se despliega: se recalculan las escenas cuando termina
	      if (ST) setTimeout(function () { ST.refresh(); }, 650);
	    });
	  });
	}
	if (!VM.motion) return;

	if (fq) {
	  mm.add(MOTION, function () {
	    var spk = $('.fq-spark', fq);
	    if (!spk) return;
	    gsap.fromTo(spk, { rotation: -50 }, { rotation: 130, ease: 'none', scrollTrigger: { trigger: fq, start: 'top bottom', end: 'bottom top', scrub: true } });
	    return function () { gsap.set(spk, { clearProps: CLR }); };
	  });
	}
})();
