/**
 * Bloque Preguntas frecuentes: campos del editor.
 */
VG7Editor.register('vg7-marketing/preguntas', [
	{ title: 'Encabezado', fields: [
		{ key: 'title', label: 'Título', type: 'textarea', rows: 2, help: 'Lo que escribas entre *asteriscos* sale en verde (por ejemplo: Preguntas *frecuentes*).' },
		VG7Editor.HEADING
	] },
	{ title: 'Botón', fields: [
		{ key: 'btnLabel', label: 'Texto', help: 'Llama al teléfono de Datos del sitio. Vacío o sin teléfono = sin botón.' }
	] },
	{ title: 'Preguntas', fields: [
		{ key: 'items', type: 'repeater', itemLabel: 'Pregunta', titleKey: 'q', min: 1, max: 12, help: 'La primera sale abierta. Se abre una a la vez.', add: { q: 'Nueva pregunta', a: 'Escribe la respuesta.' }, fields: [
			{ key: 'q', label: 'Pregunta' },
			{ key: 'a', label: 'Respuesta', type: 'textarea', rows: 5 }
		] }
	] },
	{ title: 'Avanzado', fields: [
		VG7Editor.SECTION_ID
	] }
]);
