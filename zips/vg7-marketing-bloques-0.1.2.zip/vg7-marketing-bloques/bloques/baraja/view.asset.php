<?php
return array(
	'dependencies' => array( 'vgmb-comunes' ),
	'version'      => '0.1.1',
);
