<?php
/**
 * Bloque: Baraja de planes (planes.html, section#planes).
 *
 * Título y hasta cuatro tarjetas (nombre, descripción, velocidad con su barra —la proporción es Mbps sobre 1000—, precio, ventajas y botón de llamar). El cuarto plan va
 * en azul noche. En pantallas de 1180 x 740 px o más, con movimiento, la escena es fija: las tarjetas salen de una baraja y se abren en abanico (view.js).
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$sec   = vgm_section( $a, 'baraja', '', 'planes', 'claro' );
$tag   = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h2', 'h2' );
$text  = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$plink = vg7_opt( 'phone_link' );
$plans = array_slice( vgm_items( isset( $a['plans'] ) ? $a['plans'] : array() ), 0, 4 );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="bj-stage">
		<div class="bj-in sec-wrap">
			<header class="bj-head">
				<?php if ( '' !== $text( 'eyebrow' ) ) : ?>
					<p class="sec-eyebrow" data-r style="--d:.05s"><?php echo esc_html( $text( 'eyebrow' ) ); ?></p>
				<?php endif; ?>
				<<?php echo esc_attr( $tag ); ?> class="sec-title" id="<?php echo esc_attr( $sec['title_id'] ); ?>" style="--t-size:clamp(2.1rem, 3.6vw, 3.4rem)"><?php echo vgm_title( $text( 'title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title(). ?></<?php echo esc_attr( $tag ); ?>>
			</header>

			<div class="bj-grid">
				<?php foreach ( $plans as $i => $plan ) : ?>
					<?php
					$feats = vgm_lines( isset( $plan['feats'] ) ? $plan['feats'] : '' );
					$mbps  = (int) preg_replace( '/\D/', '', isset( $plan['mbps'] ) ? (string) $plan['mbps'] : '0' );
					$v     = max( 0, min( 1, round( $mbps / 1000, 2 ) ) );
					?>
					<article class="pc pc--<?php echo (int) ( $i + 1 ); ?>" style="--k:<?php echo (int) $i; ?>">
						<header class="pc-top"><span class="spark pc-spark" aria-hidden="true"></span><h3><?php echo esc_html( isset( $plan['name'] ) ? $plan['name'] : '' ); ?></h3></header>
						<?php if ( ! empty( $plan['desc'] ) ) : ?>
							<p class="pc-desc"><?php echo esc_html( $plan['desc'] ); ?></p>
						<?php endif; ?>
						<div class="pc-speed">
							<p class="pc-mbps"><span class="pc-from"><?php esc_html_e( 'Desde', 'vg7-marketing-bloques' ); ?></span><strong data-to="<?php echo (int) $mbps; ?>"><?php echo (int) $mbps; ?></strong><span class="pc-unit">Mbps</span></p>
							<i class="pc-bar" style="--v:<?php echo esc_attr( (string) $v ); ?>" aria-hidden="true"><b></b></i>
						</div>
						<?php echo vgm_price( isset( $plan['price'] ) ? $plan['price'] : '', 'pc-price' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_price(). ?>
						<?php if ( $feats ) : ?>
							<ul class="pc-feats">
								<?php foreach ( $feats as $feat ) : ?>
									<li><?php echo vgm_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo. ?><?php echo esc_html( $feat ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
						<?php
						if ( $plink ) {
							echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
								array(
									'label'     => $text( 'btnLabel' ),
									'url'       => $plink,
									'icon'      => 'arrow',
									'large'     => false,
									'track'     => 'clic_llamar',
									'ubicacion' => 'plan_' . sanitize_title( isset( $plan['name'] ) ? $plan['name'] : (string) $i ),
								)
							);
						}
						?>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
