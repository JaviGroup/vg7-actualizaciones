/**
 * Bloque Baraja de planes. Baraja que se abre en abanico y barras de velocidad (sección 3 de planes.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';
	if (!VM.motion) return;

var PIN = '(min-width: 1180px) and (min-height: 740px) and (prefers-reduced-motion: no-preference)';
	var FLOW = '(min-width: 900px) and (prefers-reduced-motion: no-preference) and (max-width: 1179px), (min-width: 900px) and (prefers-reduced-motion: no-preference) and (max-height: 739px)';
var planes = $('[data-vg7="baraja"]');
	var pinST = null;
	if (planes) {
	  var cards = $$('.pc', planes);
	  // Barra y numero de velocidad de una tarjeta: valores finales (el HTML ya los trae) y utilidades para animarlos
	  var meters = cards.map(function (c) {
	    var s = $('.pc-mbps strong', c), b = $('.pc-bar b', c);
	    return { card: c, num: s, bar: b, to: +s.dataset.to, v: +getComputedStyle($('.pc-bar', c)).getPropertyValue('--v') || (+s.dataset.to / 1000), o: { v: 0 } };
	  });
	  var finish = function () { meters.forEach(function (m) { m.num.textContent = m.to; }); gsap.set(meters.map(function (m) { return m.bar; }), { clearProps: 'transform' }); };
	  var zero = function () { meters.forEach(function (m) { m.num.textContent = '0'; m.o.v = 0; }); gsap.set(meters.map(function (m) { return m.bar; }), { scaleX: 0 }); };
	  var playOne = function (m) {
	    gsap.to(m.bar, { scaleX: m.v, duration: 1.3, ease: 'power2.out' });
	    gsap.to(m.o, { v: m.to, duration: 1.3, ease: 'power2.out', onUpdate: function () { m.num.textContent = Math.round(m.o.v); } });
	  };

	  // --- Escena fija: baraja -> abanico -> barras
	  mm.add(PIN, function () {
	    var stg = $('.bj-stage', planes), n = cards.length, mid = (n - 1) / 2, gap = 18;
	    zero();
	    gsap.set(cards, { transformOrigin: '50% 100%', zIndex: function (i) { return n - i; } });
	    var tl = gsap.timeline({
	      defaults: { ease: 'none' },
	      scrollTrigger: { trigger: stg, start: top, end: span(2.6), pin: true, scrub: 0.5, anticipatePin: 1, invalidateOnRefresh: true }
	    });
	    pinST = tl.scrollTrigger;
	    // Baraja: todas en el centro, abiertas como cartas en la mano (las de los extremos mas caidas y giradas)
	    tl.fromTo(cards, {
	      x: function (i, el) { return -(i - mid) * (el.offsetWidth + gap); },
	      y: function (i) { return 6 + Math.abs(i - mid) * 12; },
	      rotation: function (i) { return (i - mid) * 8; },
	      scale: 0.9
	    }, { x: 0, y: 0, rotation: 0, scale: 1, duration: 1.2, ease: 'power3.inOut', stagger: 0.06, immediateRender: true }, 0);
	    // Barras y numeros: cada plan llena su velocidad, uno tras otro
	    meters.forEach(function (m, i) {
	      tl.to(m.bar, { scaleX: m.v, duration: 1.1, ease: 'power2.out' }, 1.25 + i * 0.12)
	        .to(m.o, { v: m.to, duration: 1.1, ease: 'power2.out', onUpdate: function () { m.num.textContent = Math.round(m.o.v); } }, 1.25 + i * 0.12);
	    });
	    tl.to({}, { duration: 0.6 }, tl.duration());
	    return function () {
	      pinST = null;
	      gsap.set(cards, { clearProps: CLR + ',zIndex,transformOrigin' });
	      finish();
	    };
	  });

	  // --- Sin escena fija en escritorio (menos de 1180 px de ancho o 740 de alto): cada tarjeta sube al llegar y su velocidad cuenta una vez
	  mm.add(FLOW, function () {
	    var made = [];
	    zero();
	    meters.forEach(function (m, i) {
	      gsap.fromTo(m.card, { y: 56, opacity: 0.2 }, { y: 0, opacity: 1, ease: 'none', scrollTrigger: { trigger: m.card, start: 'top 98%', end: 'top 72%', scrub: true } });
	      made.push(ST.create({ trigger: m.card, start: 'top 82%', once: true, onEnter: function () { playOne(m); } }));
	    });
	    return function () { made.forEach(function (s) { s.kill(); }); gsap.set(cards, { clearProps: CLR }); finish(); };
	  });

	  // --- Movil: tarjetas apiladas con sticky y la velocidad cuenta al llegar
	  mm.add(MOB, function () {
	    var made = [];
	    zero();
	    stackFx(cards, 12);
	    meters.forEach(function (m) { made.push(ST.create({ trigger: m.card, start: 'top 82%', once: true, onEnter: function () { playOne(m); } })); });
	    return function () { made.forEach(function (s) { s.kill(); }); gsap.set(cards, { clearProps: CLR }); finish(); };
	  });

	  // "Elegir mi plan" lleva a donde las tarjetas ya estan abiertas y con sus velocidades completas (no al principio de la escena, donde siguen apiladas)
	  d.addEventListener('click', function (e) {
	    var a = e.target.closest('a[href="#planes"]');
	    if (!a || !pinST || !VG.lenis) return;
	    e.preventDefault();
	    e.stopImmediatePropagation();
	    VG.lenis.scrollTo(pinST.start + window.innerHeight * 2.2, { duration: 1.6 });
	  }, true);
	}
})();
