<?php
return array(
	'dependencies' => array( 'vg7-editor-kit' ),
	'version'      => '0.1.1',
);
