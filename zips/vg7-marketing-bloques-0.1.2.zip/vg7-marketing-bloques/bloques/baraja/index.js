/**
 * Bloque Baraja de planes: campos del editor.
 */
VG7Editor.register('vg7-marketing/baraja', [
	{ title: 'Encabezado', fields: [
		{ key: 'eyebrow', label: 'Etiqueta superior', help: 'Déjala vacía para quitarla.' },
		{ key: 'title', label: 'Título', type: 'textarea', rows: 2, help: 'Lo que escribas entre *asteriscos* sale en verde (por ejemplo: Elige tu plan *ideal*).' },
		VG7Editor.HEADING
	] },
	{ title: 'Planes', fields: [
		{ key: 'plans', type: 'repeater', itemLabel: 'Plan', titleKey: 'name', min: 1, max: 4, help: 'La barra de velocidad de cada tarjeta se llena en proporción a sus Mbps sobre 1000. El cuarto plan se muestra en azul noche.', add: { name: 'Nuevo plan', desc: 'Describe el plan.', price: '39.99', mbps: '300', feats: 'Ventaja uno\nVentaja dos' }, fields: [
			{ key: 'name', label: 'Nombre' },
			{ key: 'desc', label: 'Descripción', type: 'textarea', rows: 3 },
			{ key: 'price', label: 'Precio mensual (por ejemplo 39.99)' },
			{ key: 'mbps', label: 'Velocidad en Mbps (solo el número, hasta 1000)' },
			{ key: 'feats', label: 'Ventajas', type: 'textarea', rows: 5, help: 'Una por línea.' }
		] },
		{ key: 'btnLabel', label: 'Botón: texto', help: 'Llama al teléfono de Datos del sitio. Sin teléfono, el botón no se muestra.' }
	] },
	{ title: 'Avanzado', fields: [
		VG7Editor.SECTION_ID
	] }
]);
