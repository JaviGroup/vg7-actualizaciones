<?php
/**
 * Páginas del sitio como patrones de bloques y herramienta para crearlas.
 *
 * - Patrones: aparecen en el insertador ("Viva Marketing") para armar o rehacer una página.
 * - Herramientas → Viva Marketing: botón que crea las páginas que falten (Inicio, Planes y Contacto). No toca las que ya existen. Deja Inicio como
 *   página de inicio solo si se acaba de crear o si el sitio no tiene una, y activa los enlaces "Nombre de la entrada" solo si el sitio no usa ninguna estructura.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Páginas del sitio (clave = dirección). El contenido de cada una son los fragmentos de paginas/<clave>/ en orden de
 * nombre (01-hero.html, 02-...): cada fragmento es el marcado de un bloque con los textos de esa página.
 */
function vgmb_paginas() {
	return array(
		'inicio'   => 'Inicio',
		'planes'   => 'Planes',
		'contacto' => 'Contacto',
	);
}

function vgmb_contenido_pagina( $key ) {
	$dir = VGMB_DIR . 'paginas/' . sanitize_key( $key );
	$out = array();
	foreach ( (array) glob( $dir . '/*.html' ) as $file ) {
		$out[] = trim( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- archivo local del plugin.
	}
	return implode( "\n\n", $out );
}

function vgmb_registrar_patrones() {
	if ( ! function_exists( 'register_block_pattern' ) ) {
		return;
	}
	register_block_pattern_category( 'vg7-marketing', array( 'label' => __( 'Viva Marketing', 'vg7-marketing-bloques' ) ) );
	foreach ( vgmb_paginas() as $key => $pagina ) {
		register_block_pattern(
			'vg7-marketing/pagina-' . $key,
			array(
				'title'       => sprintf( /* translators: %s: nombre de la página */ __( 'Página: %s', 'vg7-marketing-bloques' ), $pagina ),
				'description' => __( 'Página completa con todas sus secciones.', 'vg7-marketing-bloques' ),
				'categories'  => array( 'vg7-marketing' ),
				'content'     => vgmb_contenido_pagina( $key ),
			)
		);
	}
}
add_action( 'init', 'vgmb_registrar_patrones', 20 );

/* ---------- Herramienta: crear las páginas ---------- */

function vgmb_menu_herramienta() {
	add_management_page(
		__( 'Viva Marketing', 'vg7-marketing-bloques' ),
		__( 'Viva Marketing', 'vg7-marketing-bloques' ),
		'manage_options',
		'vgsb-paginas',
		'vgmb_pantalla_herramienta'
	);
}
add_action( 'admin_menu', 'vgmb_menu_herramienta' );

function vgmb_pantalla_herramienta() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$hecho = isset( $_GET['creadas'] ) ? (int) $_GET['creadas'] : -1; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Viva Marketing: crear las páginas', 'vg7-marketing-bloques' ); ?></h1>
		<?php if ( $hecho >= 0 ) : ?>
			<div class="notice notice-success"><p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: %d: número de páginas */
						_n( 'Listo: se creó %d página.', 'Listo: se crearon %d páginas.', $hecho, 'vg7-marketing-bloques' ),
						$hecho
					)
				);
				?>
			</p></div>
		<?php endif; ?>
		<p><?php esc_html_e( 'Crea las páginas que falten (Inicio, Planes y Contacto) con todas sus secciones. Si una página ya existe, no se toca. Inicio se deja como página de inicio solo si se crea ahora o si el sitio no tiene una, y los enlaces con el nombre de la página (/planes/, /contacto/) solo se activan si el sitio no usa ninguno.', 'vg7-marketing-bloques' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="vgmb_crear_paginas">
			<?php wp_nonce_field( 'vgmb_crear_paginas' ); ?>
			<?php submit_button( __( 'Crear páginas', 'vg7-marketing-bloques' ) ); ?>
		</form>
	</div>
	<?php
}

function vgmb_crear_paginas() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'No tienes permiso.', 'vg7-marketing-bloques' ), 403 );
	}
	check_admin_referer( 'vgmb_crear_paginas' );

	$creadas = 0;
	$ids     = array();
	$nuevas  = array();
	foreach ( vgmb_paginas() as $key => $pagina ) {
		$existente = get_page_by_path( $key, OBJECT, 'page' );
		if ( $existente ) {
			$ids[ $key ] = $existente->ID;
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => $pagina,
				'post_name'    => $key,
				'post_content' => wp_slash( vgmb_contenido_pagina( $key ) ), // wp_insert_post quita una barra: sin wp_slash se pierden los saltos de línea de las listas.
			)
		);
		if ( $id && ! is_wp_error( $id ) ) {
			$ids[ $key ]    = $id;
			$nuevas[ $key ] = true;
			++$creadas;
		}
	}
	// La página de inicio solo se toca si Inicio se acaba de crear o si el sitio no tiene una puesta (volver a pulsar el botón no cambia nada).
	$tiene_inicio = 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_on_front' );
	if ( ! empty( $ids['inicio'] ) && ( ! empty( $nuevas['inicio'] ) || ! $tiene_inicio ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $ids['inicio'] );
	}
	if ( '' === get_option( 'permalink_structure' ) ) {
		global $wp_rewrite;
		$wp_rewrite->set_permalink_structure( '/%postname%/' );
		$wp_rewrite->flush_rules();
	}
	wp_safe_redirect( add_query_arg( 'creadas', $creadas, admin_url( 'tools.php?page=vgsb-paginas' ) ) );
	exit;
}
add_action( 'admin_post_vgmb_crear_paginas', 'vgmb_crear_paginas' );
