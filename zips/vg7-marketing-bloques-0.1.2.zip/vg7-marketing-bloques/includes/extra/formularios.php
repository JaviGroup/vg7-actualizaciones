<?php
/**
 * Formulario de Viva Marketing (Contacto) sobre el motor del tema padre (vg7-theme/inc/formularios.php).
 *
 * El formulario envía: nombre, telefono, direccion (campo propio de este sitio), servicio (opcional, como en el sitio actual), acepto_contacto (obligatorio:
 * el motor lo exige), acepto_promociones (opcional), consentimiento (texto exacto de la casilla de contacto) y utm/gclid/fbclid.
 * El servicio, si se elige, solo puede ser uno de los de la lista de abajo (los mismos que el sitio actual).
 */

defined( 'ABSPATH' ) || exit;

/**
 * Servicios que se pueden elegir en el formulario.
 */
function vgmb_servicios() {
	return array(
		'Planes móviles',
		'Paquetes',
		'Soporte',
		'Otro',
	);
}

function vgmb_form_servicios( $permitidos ) {
	return vgmb_servicios();
}
add_filter( 'vg7_form_servicios', 'vgmb_form_servicios' );

/**
 * Campo propio: la dirección completa (ciudad, calle y número de casa).
 */
function vgmb_form_fields( $fields ) {
	$fields['direccion'] = __( 'Dirección', 'vg7-marketing-bloques' );
	return $fields;
}
add_filter( 'vg7_form_fields', 'vgmb_form_fields' );

/**
 * La dirección es obligatoria (5 caracteres o más) si el formulario la trae.
 */
function vgmb_form_validar( $error, $data, $params ) {
	if ( $error ) {
		return $error;
	}
	if ( array_key_exists( 'direccion', $params ) && mb_strlen( trim( (string) $data['direccion'] ) ) < 5 ) {
		return __( 'Escribe tu dirección completa.', 'vg7-marketing-bloques' );
	}
	return '';
}
add_filter( 'vg7_form_validate', 'vgmb_form_validar', 10, 3 );

/**
 * La dirección sale en el correo de aviso y en el CSV (después del teléfono).
 */
function vgmb_form_notificar( $campos ) {
	$i = array_search( 'telefono', $campos, true );
	array_splice( $campos, false === $i ? 2 : $i + 1, 0, array( 'direccion' ) );
	return $campos;
}
add_filter( 'vg7_form_notify_fields', 'vgmb_form_notificar' );
add_filter( 'vg7_form_export_fields', 'vgmb_form_notificar' );
