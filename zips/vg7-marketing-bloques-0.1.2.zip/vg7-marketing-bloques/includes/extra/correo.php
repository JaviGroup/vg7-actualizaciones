<?php
/**
 * Correo de aviso de cada solicitud (formulario de Contacto).
 *
 * - Remitente: "Viva Marketing" en vez de "WordPress". Solo cambia el nombre; la dirección sigue siendo la del sitio.
 *   Si un plugin de correo (SMTP) fija su propio nombre, se respeta ese.
 * - Asunto: "Nueva cotización: Nombre" (sin el nombre del sitio entre corchetes). Necesita el tema padre 0.6.1 o más (trae el filtro
 *   vg7_form_notify_subject); con uno anterior solo cambia el remitente.
 */

defined( 'ABSPATH' ) || exit;

function vgmb_correo_nombre_remitente( $name ) {
	return 'WordPress' === $name ? 'Viva Marketing' : $name;
}
add_filter( 'wp_mail_from_name', 'vgmb_correo_nombre_remitente', 20 );

function vgmb_correo_asunto( $subject, $id, $data ) {
	$nombre = trim( isset( $data['nombre'] ) ? (string) $data['nombre'] : '' );
	return __( 'Nueva cotización', 'vg7-marketing-bloques' ) . ( '' !== $nombre ? ': ' . $nombre : '' );
}
add_filter( 'vg7_form_notify_subject', 'vgmb_correo_asunto', 10, 3 );
