<?php
/**
 * Piezas compartidas por los bloques de Viva Marketing.
 * Los iconos salen del sprite que imprime el tema hijo (vg7-marketing/inc/sprite.php, ids "i-...").
 */

defined( 'ABSPATH' ) || exit;

/**
 * URL de un archivo del plugin (por ejemplo, una imagen de prueba).
 */
function vgm_asset( $path ) {
	return VGMB_URL . 'assets/' . ltrim( $path, '/' );
}

/**
 * Enlace: "/planes/" o "/#movil" pasan por home_url() (funciona en cualquier carpeta del sitio); "#ancla", "tel:" y
 * "https://" se dejan como están.
 */
function vgm_url( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return '#';
	}
	if ( '/' === $url[0] ) {
		return home_url( $url );
	}
	return $url;
}

/**
 * Sprite de iconos para la vista previa del editor (es otro documento, sin el sprite del sitio). En el sitio no hace nada.
 */
function vgm_editor_sprite() {
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST && function_exists( 'vgm_sprite_html' ) ) {
		return vgm_sprite_html();
	}
	return '';
}

/**
 * Icono del sprite (decorativo), con la clase .ico del diseño.
 *
 * @param string $name  Id sin prefijo: 'arrow', 'phone', 'check'...
 * @param string $class Clases extra del <svg> (opcional).
 */
function vgm_icon( $name, $class = '' ) {
	return '<svg class="ico' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" aria-hidden="true" focusable="false"><use href="#i-' . esc_attr( $name ) . '"/></svg>';
}

/**
 * Botón del diseño (ámbar con texto azul noche, pastilla con anillo translúcido y círculo de flecha).
 *
 * @param array $args {
 *     @type string $label     Texto.
 *     @type string $url       Enlace.
 *     @type string $variant   'primary' (ámbar, por defecto) o 'ghost' (transparente con borde).
 *     @type string $icon      Icono del sprite: en el primario va en el círculo blanco (btn-ar); en el ghost, suelto antes o después del texto. Vacío = sin icono.
 *     @type string $icon_pos  Solo 'ghost': 'after' (por defecto) o 'before'.
 *     @type bool   $large     Tamaño grande (btn--lg).
 *     @type string $class     Clases extra.
 *     @type string $track     Valor de data-vg7-track ('clic_llamar'...).
 *     @type string $ubicacion Valor de data-vg7-ubicacion.
 *     @type array  $attrs     Atributos extra.
 * }
 * @return string
 */
function vgm_btn( $args ) {
	$a = wp_parse_args(
		$args,
		array(
			'label'     => '',
			'url'       => '#',
			'variant'   => 'primary',
			'icon'      => '',
			'icon_pos'  => 'after',
			'large'     => true,
			'class'     => '',
			'track'     => '',
			'ubicacion' => '',
			'attrs'     => array(),
		)
	);
	if ( '' === trim( (string) $a['label'] ) ) {
		return '';
	}
	$ghost   = 'ghost' === $a['variant'];
	$classes = trim( 'btn' . ( $ghost ? ' btn--ghost' : '' ) . ( $a['large'] ? ' btn--lg' : '' ) . ' ' . $a['class'] );
	$extra   = '';
	if ( $a['track'] ) {
		$extra .= ' data-vg7-track="' . esc_attr( $a['track'] ) . '"';
		if ( $a['ubicacion'] ) {
			$extra .= ' data-vg7-ubicacion="' . esc_attr( $a['ubicacion'] ) . '"';
		}
	}
	foreach ( (array) $a['attrs'] as $name => $value ) {
		$extra .= ' ' . esc_attr( $name ) . '="' . esc_attr( $value ) . '"';
	}
	$text = esc_html( $a['label'] );
	if ( $ghost ) {
		// Con el icono antes, el texto va suelto (como el diseño); con el icono después, el texto va en su <span>.
		$icon  = $a['icon'] ? vgm_icon( $a['icon'] ) : '';
		$inner = 'before' === $a['icon_pos'] ? $icon . $text : '<span>' . $text . '</span>' . $icon;
	} else {
		$inner = '<span>' . $text . '</span>' . ( $a['icon'] ? '<span class="btn-ar">' . vgm_icon( $a['icon'] ) . '</span>' : '' );
	}
	return sprintf(
		'<a class="%s" href="%s"%s>%s</a>',
		esc_attr( $classes ),
		esc_url( vgm_url( $a['url'] ), array( 'http', 'https', 'tel', 'mailto' ) ),
		$extra,
		$inner
	);
}

/**
 * Imagen de la Biblioteca de medios (con srcset) o, si no hay, la de prueba del plugin (assets/img/).
 *
 * @param int    $id      ID del adjunto (0 = imagen de prueba).
 * @param string $default Archivo en assets/img/.
 * @param array  $args    class, alt, width, height (de la imagen de prueba), loading, fetchpriority, size.
 */
function vgm_img( $id, $default, $args = array() ) {
	$a = wp_parse_args(
		$args,
		array(
			'class'         => '',
			'alt'           => '',
			'width'         => 0,
			'height'        => 0,
			'loading'       => 'lazy',
			'fetchpriority' => '',
			'size'          => 'large',
		)
	);
	if ( $id ) {
		$attrs = array(
			'class'    => $a['class'],
			'loading'  => $a['loading'],
			'decoding' => 'async',
			'alt'      => $a['alt'],
		);
		if ( $a['fetchpriority'] ) {
			$attrs['fetchpriority'] = $a['fetchpriority'];
		}
		$html = wp_get_attachment_image( (int) $id, $a['size'], false, $attrs );
		if ( $html ) {
			return $html;
		}
	}
	if ( '' === (string) $default ) {
		return '';
	}
	return sprintf(
		'<img%s src="%s" alt="%s"%s%s loading="%s" decoding="async"%s>',
		$a['class'] ? ' class="' . esc_attr( $a['class'] ) . '"' : '',
		esc_url( vgm_asset( 'img/' . $default ) ),
		esc_attr( $a['alt'] ),
		$a['width'] ? ' width="' . (int) $a['width'] . '"' : '',
		$a['height'] ? ' height="' . (int) $a['height'] . '"' : '',
		esc_attr( $a['loading'] ),
		$a['fetchpriority'] ? ' fetchpriority="' . esc_attr( $a['fetchpriority'] ) . '"' : ''
	);
}

/**
 * Imagen del plugin con dos tamaños (srcset de ancho 'w'): la grande y la chica para móvil. Si se eligió una imagen en la Biblioteca de medios
 * se usa esa (con su srcset); si no, los archivos de prueba del diseño aprobado (WebP en assets/img/).
 *
 * @param int    $id    ID del adjunto (0 = archivos del plugin).
 * @param string $file  Archivo grande en assets/img/ (por ejemplo 'asesor.webp').
 * @param string $small Archivo chico (por ejemplo 'asesor-sm.webp'); vacío = sin srcset.
 * @param array  $args  w, h (tamaño del archivo grande), ws (ancho del chico), class, alt, sizes, loading ('lazy'|'eager'), fetchpriority.
 */
function vgm_pic( $id, $file, $small, $args = array() ) {
	$a = wp_parse_args(
		$args,
		array(
			'w'             => 0,
			'h'             => 0,
			'ws'            => 0,
			'class'         => '',
			'alt'           => '',
			'sizes'         => '',
			'loading'       => 'lazy',
			'fetchpriority' => '',
		)
	);
	if ( $id ) {
		$attrs = array(
			'class'    => $a['class'],
			'loading'  => $a['loading'],
			'decoding' => 'async',
			'alt'      => $a['alt'],
		);
		if ( $a['fetchpriority'] ) {
			$attrs['fetchpriority'] = $a['fetchpriority'];
		}
		if ( $a['sizes'] ) {
			$attrs['sizes'] = $a['sizes'];
		}
		$html = wp_get_attachment_image( (int) $id, 'large', false, $attrs );
		if ( $html ) {
			return $html;
		}
	}
	$srcset = ( $small && $a['ws'] ) ? ' srcset="' . esc_url( vgm_asset( 'img/' . $small ) ) . ' ' . (int) $a['ws'] . 'w, ' . esc_url( vgm_asset( 'img/' . $file ) ) . ' ' . (int) $a['w'] . 'w"' : '';
	return sprintf(
		'<img%1$s src="%2$s"%3$s%4$s width="%5$d" height="%6$d" alt="%7$s" loading="%8$s" decoding="async"%9$s>',
		$a['class'] ? ' class="' . esc_attr( $a['class'] ) . '"' : '',
		esc_url( vgm_asset( 'img/' . $file ) ),
		$srcset,
		( $srcset && $a['sizes'] ) ? ' sizes="' . esc_attr( $a['sizes'] ) . '"' : '',
		(int) $a['w'],
		(int) $a['h'],
		esc_attr( $a['alt'] ),
		esc_attr( $a['loading'] ),
		$a['fetchpriority'] ? ' fetchpriority="' . esc_attr( $a['fetchpriority'] ) . '"' : ''
	);
}

/**
 * Lista de un campo repetible, siempre como arreglo de arreglos.
 */
function vgm_items( $items ) {
	return is_array( $items ) ? array_values( array_filter( $items, 'is_array' ) ) : array();
}

/**
 * Líneas de un campo de texto (una por línea), sin vacías.
 */
function vgm_lines( $text ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $text ) ), 'strlen' ) );
}

/**
 * Texto con *palabras resaltadas*: lo que va entre asteriscos sale en <em>. Todo se escapa.
 */
function vgm_em( $text ) {
	$parts = explode( '*', (string) $text );
	$out   = '';
	foreach ( $parts as $i => $part ) {
		$out .= $i % 2 ? '<em>' . esc_html( $part ) . '</em>' : esc_html( $part );
	}
	return $out;
}

/**
 * Palabras de un texto con *resaltadas*: arreglo de array( palabra, resaltada ).
 */
function vgm_tokens( $text ) {
	$tokens = array();
	foreach ( explode( '*', (string) $text ) as $i => $part ) {
		foreach ( preg_split( '/\s+/u', trim( $part ), -1, PREG_SPLIT_NO_EMPTY ) as $word ) {
			$tokens[] = array( $word, (bool) ( $i % 2 ) );
		}
	}
	return $tokens;
}

/**
 * Título del diseño: cada palabra en su máscara (.w > .wi, la entrada es CSS) y lo resaltado dentro de <em>.
 * Marcado: <span class="w"><span class="wi" style="--i:0">Palabra</span></span> <em>...</em>
 */
function vgm_title( $text, $start = 0 ) {
	$out = '';
	$em  = false;
	foreach ( vgm_tokens( $text ) as $i => $t ) {
		if ( $t[1] && ! $em ) {
			$out .= ( $i ? ' ' : '' ) . '<em>';
			$em   = true;
		} elseif ( ! $t[1] && $em ) {
			$out .= '</em> ';
			$em   = false;
		} elseif ( $i ) {
			$out .= ' ';
		}
		$out .= '<span class="w"><span class="wi" style="--i:' . (int) ( $i + $start ) . '">' . esc_html( $t[0] ) . '</span></span>';
	}
	return $out . ( $em ? '</em>' : '' );
}

/**
 * Título en varias líneas (una por línea del campo): cada línea va en un <span class="$line_class"> y el índice de las palabras sigue de una a otra,
 * para que la entrada escalonada (.wi) corra por todo el título.
 */
function vgm_title_lines( $text, $line_class ) {
	$out   = '';
	$start = 0;
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		if ( '' === trim( $line ) ) {
			continue;
		}
		$out  .= ( '' === $out ? '' : ' ' ) . '<span class="' . esc_attr( $line_class ) . '">' . vgm_title( $line, $start ) . '</span>';
		$start += count( vgm_tokens( $line ) );
	}
	return $out;
}

/**
 * Ficha flotante (icono, texto y subtexto) de los héroes: <div class="$outer" aria-hidden="true"><div class="$inner">...</div></div>.
 *
 * @param array  $chip  icon, title, text y amber (true = icono ámbar).
 * @param string $outer Clases del contenedor (posición).
 * @param string $inner Clase del interior (la que flota).
 */
function vgm_chip( $chip, $outer, $inner = 'he-chip-in' ) {
	return sprintf(
		'<div class="%1$s" aria-hidden="true"><div class="%2$s"><span class="hc-ico%3$s">%4$s</span><span class="hc-t"><b>%5$s</b><small>%6$s</small></span></div></div>',
		esc_attr( $outer ),
		esc_attr( $inner ),
		! empty( $chip['amber'] ) ? ' hc-ico--amber' : '',
		vgm_icon( isset( $chip['icon'] ) && '' !== $chip['icon'] ? $chip['icon'] : 'bolt' ),
		esc_html( isset( $chip['title'] ) ? $chip['title'] : '' ),
		esc_html( isset( $chip['text'] ) ? $chip['text'] : '' )
	);
}

/**
 * Frase que se enciende palabra por palabra: <span class="ms-w">palabra</span>; lo resaltado va dentro de <em>.
 */
function vgm_frase( $text ) {
	$out = '';
	$em  = false;
	foreach ( vgm_tokens( $text ) as $i => $t ) {
		if ( $t[1] && ! $em ) {
			$out .= ( $i ? ' ' : '' ) . '<em>';
			$em   = true;
		} elseif ( ! $t[1] && $em ) {
			$out .= '</em> ';
			$em   = false;
		} elseif ( $i ) {
			$out .= ' ';
		}
		$out .= '<span class="ms-w">' . esc_html( $t[0] ) . '</span>';
	}
	return $out . ( $em ? '</em>' : '' );
}

/**
 * Precio del diseño: "$" arriba, enteros grandes y una columna con los centavos y "/mes". Acepta "39.99" o "39,99".
 *
 * @param string $price Precio.
 * @param string $class Clases del <p> o <span>.
 * @param string $tag   'p' o 'span'.
 */
function vgm_price( $price, $class = '', $tag = 'p' ) {
	$clean = str_replace( ',', '.', preg_replace( '/[^0-9.,]/', '', (string) $price ) );
	$parts = explode( '.', $clean . '.' );
	$int   = (int) $parts[0];
	$cents = str_pad( substr( preg_replace( '/\D/', '', $parts[1] ), 0, 2 ), 2, '0' );
	$label = sprintf(
		/* translators: 1: dólares, 2: centavos */
		__( '%1$d dólares con %2$s centavos al mes', 'vg7-marketing-bloques' ),
		$int,
		$cents
	);
	return sprintf(
		'<%1$s class="%2$s" role="text" aria-label="%3$s"><sup>$</sup>%4$d<span class="pr-side"><span class="pr-cents">%5$s</span><span class="pr-per">/mes</span></span></%1$s>',
		'span' === $tag ? 'span' : 'p',
		esc_attr( trim( $class . ' pr-price' ) ),
		esc_attr( $label ),
		$int,
		esc_html( $cents )
	);
}

/**
 * Atributos del contenedor de una sección: id (de sectionId), aria-labelledby, data-vg7 y data-tono, más las clases que se pasen.
 *
 * @param array  $a       Campos del bloque.
 * @param string $name    Valor de data-vg7 (el del bloque: 'hero', 'pasos'...).
 * @param string $class   Clases de la sección ('vg7-sec hero'...).
 * @param string $default Id por defecto si el campo sectionId está vacío.
 * @param string $tono    Tono de fondo del diseño: 'oscuro', 'claro' o 'alterno'.
 * @return array array( 'attrs' => atributos ya escapados para imprimir, 'title_id' => id para el título )
 */
function vgm_section( $a, $name, $class, $default = '', $tono = 'oscuro', $label = '' ) {
	$id       = ! empty( $a['sectionId'] ) ? sanitize_title( $a['sectionId'] ) : sanitize_title( $default );
	$title_id = $id ? $id . '-title' : wp_unique_id( 'vgsb-' . $name . '-' );
	$attrs    = get_block_wrapper_attributes(
		array_filter(
			array(
				'class'           => trim( 'vg7-sec ' . $class ),
				'data-vg7'        => $name,
				'data-tono'       => $tono,
				'id'              => $id,
				'aria-labelledby' => '' === $label ? $title_id : '',
				'aria-label'      => $label,
			)
		)
	);
	return array(
		'attrs'    => $attrs,
		'title_id' => $title_id,
	);
}

/**
 * Teléfono de Datos del sitio para textos: {telefono} se cambia por el número.
 */
function vgm_tel_text( $text ) {
	return str_replace( '{telefono}', vg7_opt( 'phone' ), (string) $text );
}
