/**
 * Bloque Preguntas frecuentes. Acordeón o lista con tarjeta (funciona sin GSAP) y, en escritorio, escena fija que enciende una pregunta con cada tramo del scroll y destello que gira (secciones 1 y 5 de planes.js).
 * Portado del diseño aprobado (disenos/viva-marketing/).
 * Los títulos y textos entran con CSS; aquí solo va lo que depende del scroll o del tiempo. Con "reducir movimiento" no se crea nada: queda el diseño estático.
 * VM (comunes.js) trae las condiciones (DESK, MOB, MOTION), gsap.matchMedia (mm), las medidas del header y las tarjetas apiladas (stackFx).
 */
(function () {
	'use strict';
	var root = document.documentElement, d = document, VM = window.VM, VG = VM;   // VG: el prototipo llamaba así a este objeto
	if (!VM) return;
	var $ = VM.$, $$ = VM.$$, gsap = window.gsap, ST = window.ScrollTrigger;
	var DESK = VM.DESK, MOB = VM.MOB, MOTION = VM.MOTION, mm = VM.mm;
	var top = VM.top, span = VM.span, clamp = VM.clamp, stackFx = VM.stackFx;
	// Estilos en línea que GSAP deja al revertir (clearProps: 'all' borraría también variables propias como --k)
	var CLR = 'transform,translate,rotate,scale,opacity,visibility,filter,clipPath';

	var fq = $('[data-vg7="preguntas"]');
	var fqScene = null, fqJump = null, fqCur = 0, fqGo = function () {}, fqPick = function () {};
	if (fq) {
	  var items = $$('.fq-item', fq);
	  var setOpen = function (it, open) {
	    it.classList.toggle('is-open', open);
	    $('button', it).setAttribute('aria-expanded', String(open));
	  };
	  var listMode = function () { return root.classList.contains('vg-pin'); };
	  // Lista: siempre hay una respuesta abierta (la de la pregunta elegida); sin escena fija la linea de progreso la mueve esta funcion
	  fqPick = function (k) {
	    fqCur = k;
	    items.forEach(function (o, i) { setOpen(o, i === k); });
	    if (!fqScene) fq.style.setProperty('--p', ((k + 0.5) / items.length).toFixed(3));
	  };
	  // Con la escena fija: baja o sube hasta la mitad del tramo de esa pregunta y, mientras llega, el scroll no cambia la tarjeta
	  fqGo = function (k) {
	    var st = fqScene;
	    fqPick(k);
	    if (!st) return;
	    fqJump = k;
	    var done = function () { fqJump = null; };
	    var y = Math.round(st.start + (k + 0.5) / items.length * (st.end - st.start));
	    if (VG && VG.lenis) VG.lenis.scrollTo(y, { duration: 1, onComplete: done }); else window.scrollTo({ top: y, behavior: 'smooth' });
	    setTimeout(done, 1500);
	  };
	  items.forEach(function (it, k) {
	    var btn = $('button', it);
	    btn.addEventListener('click', function () {
	      if (listMode()) { fqGo(k); return; }
	      var open = !it.classList.contains('is-open');
	      items.forEach(function (o) { setOpen(o, o === it ? open : false); });
	      // La altura de la pagina cambia mientras se despliega: se recalculan las escenas cuando termina
	      if (ST) setTimeout(function () { ST.refresh(); }, 650);
	    });
	    // Con el teclado (Tab) la tarjeta sigue a la pregunta enfocada
	    btn.addEventListener('focus', function () {
	      if (listMode() && fqCur !== k && btn.matches(':focus-visible')) fqGo(k);
	    });
	  });
	}
	if (!VM.motion) return;

	if (fq) {
	  // Al pasar a la lista (escritorio) debe haber una respuesta abierta: la que ya estaba o la primera
	  mm.add(DESK, function () {
	    var abierta = items.filter(function (it) { return it.classList.contains('is-open'); })[0];
	    fqPick(abierta ? items.indexOf(abierta) : 0);
	  });
	  mm.add('(min-width: 900px) and (min-height: 640px) and (prefers-reduced-motion: no-preference)', function () {
	    var stg = $('.fq-stage', fq), n = items.length;
	    // Si el contenido no cabe en la pantalla (muchas preguntas) no se fija: queda la lista con la tarjeta y el cambio con un clic
	    if ($('.fq-in', fq).offsetHeight > window.innerHeight - VG.hdr() - 8) return;
	    var sc = ST.create({
	      // 0,45 pantallas por pregunta (1,9 con 4)
	      trigger: stg, start: top, end: span(clamp(0.1 + 0.45 * n, 1.2, 6)), pin: true, anticipatePin: 1, invalidateOnRefresh: true,
	      onUpdate: function (self) {
	        fq.style.setProperty('--p', self.progress.toFixed(3));
	        if (fqJump !== null) return;
	        var k = clamp(Math.floor(self.progress * n), 0, n - 1);
	        if (k !== fqCur) fqPick(k);
	      }
	    });
	    fqScene = sc;
	    return function () { sc.kill(); fqScene = null; fqJump = null; fq.style.removeProperty('--p'); };
	  });
	  mm.add(MOTION, function () {
	    var spk = $('.fq-spark', fq);
	    if (!spk) return;
	    gsap.fromTo(spk, { rotation: -50 }, { rotation: 130, ease: 'none', scrollTrigger: { trigger: fq, start: 'top bottom', end: 'bottom top', scrub: true } });
	    return function () { gsap.set(spk, { clearProps: CLR }); };
	  });
	}
})();
