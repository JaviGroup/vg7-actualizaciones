<?php
/**
 * Bloque: Preguntas frecuentes (planes.html, section#preguntas).
 *
 * Título con *resaltado*, un destello y un botón de llamar a la izquierda; las preguntas numeradas. La primera sale abierta.
 * Móvil y "reducir movimiento": acordeón (el panel se despliega con CSS, grid-template-rows; una a la vez, en view.js). Escritorio con movimiento (html.vg-pin):
 * la lista queda a la izquierda y la respuesta abierta se ve en una tarjeta a la derecha, con el medidor de señal (.fq-sig: de 1 arco en la primera a 4 en la última) y el contador (.fq-count); view.js fija la escena y enciende una pregunta con cada tramo del scroll. Sin JavaScript todo queda abierto.
 *
 * @var array $attributes Campos del bloque.
 */

defined( 'ABSPATH' ) || exit;

$a     = $attributes;
$sec   = vgm_section( $a, 'preguntas', '', 'preguntas', 'claro' );
$tag   = vg7_heading_tag( isset( $a['headingTag'] ) ? $a['headingTag'] : 'h2', 'h2' );
$text  = function ( $key ) use ( $a ) {
	return isset( $a[ $key ] ) ? (string) $a[ $key ] : '';
};
$plink = vg7_opt( 'phone_link' );
$items = vgm_items( isset( $a['items'] ) ? $a['items'] : array() );
$uid   = wp_unique_id( 'fq' );
$total = count( $items );
?>
<section <?php echo $sec['attrs']; // phpcs:ignore WordPress.Security.EscapeOutput -- lo arma WordPress. ?>>
	<?php echo vgm_editor_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fijo del tema. ?>
	<div class="fq-stage">
	<div class="fq-in sec-wrap">
		<div class="fq-intro">
			<span class="spark fq-spark" aria-hidden="true"></span>
			<<?php echo esc_attr( $tag ); ?> class="sec-title" id="<?php echo esc_attr( $sec['title_id'] ); ?>" style="--t-size:clamp(2.2rem, 4.2vw, 3.8rem)"><?php echo vgm_title( $text( 'title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_title(). ?></<?php echo esc_attr( $tag ); ?>>
			<?php
			if ( $plink && '' !== $text( 'btnLabel' ) ) {
				echo vgm_btn( // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vgm_btn().
					array(
						'label'     => $text( 'btnLabel' ),
						'url'       => $plink,
						'icon'      => 'phone',
						'track'     => 'clic_llamar',
						'ubicacion' => 'preguntas',
						'attrs'     => array(
							'data-r' => '',
							'style'  => '--d:.45s',
						),
					)
				);
			}
			?>
		</div>
		<?php if ( $items ) : ?>
			<ul class="fq-list">
				<?php foreach ( $items as $i => $item ) : ?>
					<?php
					$n    = $i + 1;
					$open = 0 === $i;
					$lit  = $total > 1 ? 1 + (int) round( ( $n - 1 ) * 3 / ( $total - 1 ) ) : 4; // arcos del medidor encendidos: de 1 (primera) a 4 (ultima), repartidos entre las preguntas
					?>
					<li class="fq-item<?php echo $open ? ' is-open' : ''; ?>"><button type="button" id="<?php echo esc_attr( $uid . '-q' . $n ); ?>" aria-expanded="<?php echo $open ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $uid . '-a' . $n ); ?>"><span class="fq-n" aria-hidden="true"><?php echo esc_html( str_pad( (string) $n, 2, '0', STR_PAD_LEFT ) ); ?></span><span class="fq-q"><?php echo esc_html( isset( $item['q'] ) ? $item['q'] : '' ); ?></span><i class="fq-plus" aria-hidden="true"></i></button><div class="fq-a" id="<?php echo esc_attr( $uid . '-a' . $n ); ?>" role="region" aria-labelledby="<?php echo esc_attr( $uid . '-q' . $n ); ?>"><div><div class="fq-sig" aria-hidden="true"><?php for ( $k = 1; $k <= 4; $k++ ) : ?><i<?php echo $k <= $lit ? ' class="is-on"' : ''; ?> style="--k:<?php echo (int) $k; ?>"></i><?php endfor; ?><b></b></div><p><?php echo esc_html( isset( $item['a'] ) ? $item['a'] : '' ); ?></p><span class="fq-count" aria-hidden="true"><?php echo esc_html( sprintf( '%02d / %02d', $n, $total ) ); ?></span></div></div></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	</div>
</section>
