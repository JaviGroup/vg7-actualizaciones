<?php
return array(
	'dependencies' => array( 'vgmb-comunes', 'vg7-forms' ),
	'version'      => '0.2.0',
);
