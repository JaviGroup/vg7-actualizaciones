<?php
return array(
	'dependencies' => array( 'vgmb-comunes' ),
	'version'      => '0.2.0',
);
