<?php
/**
 * Plugin Name:       VG7 Marketing Bloques
 * Description:       Secciones de Viva Marketing (hero con celular y onda, nosotros con fichas, cinta, velocímetro de planes, opiniones, pasos con celular, baraja de planes, preguntas, hero y formulario de contacto con medidor de señal, y cierre) como bloques del editor, con sus textos, imágenes y datos editables. Requiere el tema VG7 Theme y su tema hijo VG7 Marketing.
 * Version:           0.1.1
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Author:            Javier Martínez
 * License:           GPL-2.0-or-later
 * Text Domain:       vg7-marketing-bloques
 */

defined( 'ABSPATH' ) || exit;

define( 'VGMB_VERSION', '0.1.1' );
define( 'VGMB_DIR', plugin_dir_path( __FILE__ ) );
define( 'VGMB_URL', plugin_dir_url( __FILE__ ) );

require_once VGMB_DIR . 'includes/helpers.php';
require_once VGMB_DIR . 'includes/paginas.php';

// Funciones propias de algunos bloques (formularios, correo de aviso, etc.).
foreach ( (array) glob( VGMB_DIR . 'includes/extra/*.php' ) as $vgmb_file ) {
	require_once $vgmb_file;
}

/**
 * Estilos y scripts compartidos entre bloques. Cada bloque los pide en su block.json ("style" / "viewScript"),
 * así solo se cargan en las páginas que los usan.
 * - assets/css/<nombre>.css  → estilo "vgmb-<nombre>"
 * - assets/js/comunes.js     → "vgmb-comunes" (variable VM: escenas, medidas y tarjetas apiladas; barra de avance y nombre del footer)
 * - assets/js/<nombre>.js    → "vgmb-<nombre>"
 */
function vgmb_registrar_compartidos() {
	foreach ( (array) glob( VGMB_DIR . 'assets/css/*.css' ) as $file ) {
		$name = basename( $file, '.css' );
		wp_register_style( 'vgmb-' . $name, VGMB_URL . 'assets/css/' . $name . '.css', array(), VGMB_VERSION );
	}
	$defer = array(
		'in_footer' => true,
		'strategy'  => 'defer',
	);
	foreach ( (array) glob( VGMB_DIR . 'assets/js/*.js' ) as $file ) {
		$name = basename( $file, '.js' );
		$deps = 'comunes' === $name ? array( 'vg7-motion' ) : array( 'vgmb-comunes' );
		wp_register_script( 'vgmb-' . $name, VGMB_URL . 'assets/js/' . $name . '.js', $deps, VGMB_VERSION, $defer );
	}
}
add_action( 'init', 'vgmb_registrar_compartidos', 6 );

/**
 * Registra todos los bloques de /bloques con la API del tema padre (VG7 Theme).
 */
function vgmb_registrar_bloques() {
	if ( ! function_exists( 'vg7_register_blocks' ) ) {
		return;
	}
	vg7_register_blocks(
		VGMB_DIR . 'bloques',
		array(
			'slug'  => 'vg7-marketing',
			'title' => __( 'Viva Marketing', 'vg7-marketing-bloques' ),
		)
	);
}
add_action( 'init', 'vgmb_registrar_bloques' );

/**
 * Precarga de la imagen principal de la portada (el elemento que mide el LCP): el celular de la Home y la mujer de Planes. Solo cuando el bloque
 * usa la imagen de prueba del plugin (si se eligió otra en la Biblioteca de medios, WordPress ya trae su propio srcset). Los tamaños coinciden con los de las etiquetas <img>.
 */
function vgmb_precargar_imagen() {
	$post = is_singular() ? get_queried_object() : null;
	if ( ! $post instanceof WP_Post ) {
		return;
	}
	$mapa = array(
		'vg7-marketing/hero'        => array( 'phone-planes-sm.webp', 360, 'phone-planes.webp', 555, '(min-width: 900px) 300px, 240px' ),
		'vg7-marketing/hero-planes' => array( 'mujer-sm.webp', 420, 'mujer.webp', 640, '(min-width: 900px) 440px, 300px' ),
	);
	foreach ( parse_blocks( $post->post_content ) as $block ) {
		if ( empty( $block['blockName'] ) || ! isset( $mapa[ $block['blockName'] ] ) || ! empty( $block['attrs']['image'] ) ) {
			continue;
		}
		list( $small, $ws, $big, $wb, $sizes ) = $mapa[ $block['blockName'] ];
		printf(
			'<link rel="preload" as="image" href="%1$s" imagesrcset="%2$s %3$dw, %1$s %4$dw" imagesizes="%5$s" fetchpriority="high">' . "\n",
			esc_url( vgm_asset( 'img/' . $big ) ),
			esc_url( vgm_asset( 'img/' . $small ) ),
			(int) $ws,
			(int) $wb,
			esc_attr( $sizes )
		);
		return;
	}
}
add_action( 'wp_head', 'vgmb_precargar_imagen', 2 );

/**
 * Aviso si el tema padre no está activo (sin él los bloques no se registran).
 */
function vgmb_aviso_tema() {
	if ( function_exists( 'vg7_register_blocks' ) || ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p><strong>VG7 Marketing Bloques:</strong> activa el tema <em>VG7 Marketing</em> (hijo de VG7 Theme) para ver los bloques.</p></div>';
}
add_action( 'admin_notices', 'vgmb_aviso_tema' );
