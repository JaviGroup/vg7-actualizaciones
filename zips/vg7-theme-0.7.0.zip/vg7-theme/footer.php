<?php
/**
 * Footer del sitio. El tema hijo puede reemplazarlo con su propio footer.php.
 * Las columnas de enlaces son los menús "Footer: columna 1" y "Footer: columna 2"
 * (el título de cada columna es el nombre del menú).
 */

defined( 'ABSPATH' ) || exit;

$vg7_locations = get_nav_menu_locations();
$vg7_columns   = array();
foreach ( array( 'footer-1', 'footer-2' ) as $vg7_loc ) {
	$vg7_items = vg7_menu_tree( $vg7_loc );
	if ( $vg7_items ) {
		$vg7_menu_obj  = empty( $vg7_locations[ $vg7_loc ] ) ? null : wp_get_nav_menu_object( $vg7_locations[ $vg7_loc ] );
		$vg7_columns[] = array(
			'title' => $vg7_menu_obj ? $vg7_menu_obj->name : '',
			'items' => $vg7_items,
		);
	}
}
$vg7_legal = vg7_menu_tree( 'legal' );
?>
<footer class="vg7-footer">
	<div class="vg7-wrap">
		<div class="vg7-footer-grid">
			<div class="vg7-footer-brand">
				<?php echo vg7_logo( 'lg' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<?php if ( vg7_opt( 'footer_text' ) ) : ?>
					<p class="vg7-footer-text"><?php echo esc_html( vg7_opt( 'footer_text' ) ); ?></p>
				<?php endif; ?>
				<?php $vg7_social = vg7_social_links(); ?>
				<?php if ( $vg7_social ) : ?>
					<ul class="vg7-social">
						<?php foreach ( $vg7_social as $vg7_net ) : ?>
							<li><a href="<?php echo esc_url( $vg7_net['url'] ); ?>" aria-label="<?php echo esc_attr( $vg7_net['name'] ); ?>" rel="noopener" target="_blank"><?php echo vg7_icon( $vg7_net['icon'], 'vg7-icon-md' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>

			<div class="vg7-footer-cols">
				<?php foreach ( $vg7_columns as $vg7_col ) : ?>
					<div>
						<?php if ( $vg7_col['title'] ) : ?>
							<h2 class="vg7-eyebrow vg7-footer-title"><?php echo esc_html( $vg7_col['title'] ); ?></h2>
						<?php endif; ?>
						<ul class="vg7-footer-links">
							<?php foreach ( $vg7_col['items'] as $vg7_item ) : ?>
								<li><a href="<?php echo esc_url( $vg7_item['url'] ); ?>"><span class="vg7-froll" data-vg7-froll><?php echo esc_html( $vg7_item['title'] ); ?></span></a></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endforeach; ?>

				<?php if ( vg7_opt( 'phone' ) || vg7_opt( 'email' ) || vg7_opt( 'address' ) ) : ?>
					<div>
						<h2 class="vg7-eyebrow vg7-footer-title"><?php esc_html_e( 'Contáctanos', 'vg7' ); ?></h2>
						<ul class="vg7-footer-links">
							<?php if ( vg7_opt( 'phone' ) ) : ?>
								<li><a href="<?php echo esc_url( vg7_opt( 'phone_link' ), array( 'tel', 'http', 'https' ) ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="footer"><span class="vg7-froll" data-vg7-froll><?php echo esc_html( vg7_opt( 'phone' ) ); ?></span></a></li>
							<?php endif; ?>
							<?php if ( vg7_opt( 'email' ) ) : ?>
								<li><a href="mailto:<?php echo esc_attr( antispambot( vg7_opt( 'email' ) ) ); ?>"><span class="vg7-froll" data-vg7-froll><?php echo esc_html( antispambot( vg7_opt( 'email' ) ) ); ?></span></a></li>
							<?php endif; ?>
							<?php if ( vg7_opt( 'address' ) ) : ?>
								<li class="vg7-footer-address"><?php echo nl2br( esc_html( vg7_opt( 'address' ) ) ); ?></li>
							<?php endif; ?>
						</ul>
					</div>
				<?php endif; ?>

				<?php
				/**
				 * Columna extra del footer (por ejemplo, el formulario de suscripción del plugin del sitio).
				 */
				do_action( 'vg7_footer_columns' );
				?>
			</div>
		</div>

		<div class="vg7-footer-copy">
			<p><?php echo esc_html( vg7_opt( 'copyright' ) ); ?></p>
			<div class="vg7-footer-legal">
				<?php foreach ( $vg7_legal as $vg7_item ) : ?>
					<a href="<?php echo esc_url( $vg7_item['url'] ); ?>"><span class="vg7-froll" data-vg7-froll><?php echo esc_html( $vg7_item['title'] ); ?></span></a>
				<?php endforeach; ?>
				<?php if ( ! $vg7_legal && vg7_opt( 'privacy_url' ) ) : ?>
					<a href="<?php echo esc_url( vg7_opt( 'privacy_url' ) ); ?>"><span class="vg7-froll" data-vg7-froll><?php esc_html_e( 'Política de privacidad', 'vg7' ); ?></span></a>
				<?php endif; ?>
				<?php if ( ! $vg7_legal && vg7_opt( 'terms_url' ) ) : ?>
					<a href="<?php echo esc_url( vg7_opt( 'terms_url' ) ); ?>"><span class="vg7-froll" data-vg7-froll><?php esc_html_e( 'Términos y condiciones', 'vg7' ); ?></span></a>
				<?php endif; ?>
			</div>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
