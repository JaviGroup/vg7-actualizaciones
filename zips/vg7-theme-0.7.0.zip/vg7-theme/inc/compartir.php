<?php
/**
 * Imagen al compartir el enlace (Open Graph y tarjeta de X).
 *
 * Cada tema hijo trae su imagen en assets/img/compartir.png (también .jpg, .jpeg o .webp). Si existe, el padre
 * imprime las etiquetas og:* y twitter:card en el <head> de todas las páginas; si no existe, no imprime nada.
 * Con Yoast SEO o Rank Math activos tampoco imprime: ellos manejan el Open Graph y la imagen por defecto se
 * elige en su pantalla Social.
 *
 * Filtros:
 *   vg7_share_image  array( url, width, height, type ) o false: cambiar o quitar la imagen.
 *   vg7_share_tags   bool: false apaga las etiquetas (para otro plugin de SEO).
 */

defined( 'ABSPATH' ) || exit;

/**
 * Imagen para compartir del tema activo (el hijo, o el padre si no hay hijo).
 *
 * @return array|false array( url, width, height, type ), o false si el tema no trae imagen.
 */
function vg7_share_image() {
	$image = false;
	foreach ( array( 'png', 'jpg', 'jpeg', 'webp' ) as $ext ) {
		$relative = 'assets/img/compartir.' . $ext;
		$path     = get_stylesheet_directory() . '/' . $relative;
		if ( ! file_exists( $path ) ) {
			continue;
		}
		$size  = wp_getimagesize( $path );
		$type  = wp_check_filetype( $path );
		$image = array(
			'url'    => get_stylesheet_directory_uri() . '/' . $relative,
			'width'  => $size ? (int) $size[0] : 0,
			'height' => $size ? (int) $size[1] : 0,
			'type'   => (string) $type['type'],
		);
		break;
	}
	return apply_filters( 'vg7_share_image', $image );
}

/**
 * Descripción de la página: el extracto escrito a mano o, si no hay, el lema del sitio.
 *
 * @return string
 */
function vg7_share_description() {
	$text = '';
	if ( is_singular() ) {
		$text = (string) get_post_field( 'post_excerpt', get_queried_object_id() );
	}
	if ( '' === trim( $text ) ) {
		$text = (string) get_bloginfo( 'description' );
	}
	return wp_html_excerpt( trim( wp_strip_all_tags( $text ) ), 200, '…' );
}

/**
 * Imprime las etiquetas Open Graph y la tarjeta de X.
 */
function vg7_share_tags() {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) ) {
		return;
	}
	if ( ! apply_filters( 'vg7_share_tags', true ) ) {
		return;
	}
	$image = vg7_share_image();
	if ( ! $image || empty( $image['url'] ) ) {
		return;
	}

	$name = get_bloginfo( 'name' );
	$url  = '';
	if ( is_singular() ) {
		$url = (string) get_permalink();
	} elseif ( is_front_page() ) {
		$url = home_url( '/' );
	}
	$desc = vg7_share_description();
	// Tarjeta grande solo si la imagen es horizontal; una cuadrada va como miniatura.
	$wide = $image['width'] && $image['height'] && ( $image['width'] / $image['height'] ) >= 1.5;

	$tags = array(
		'og:type'         => 'website',
		'og:locale'       => get_locale(),
		'og:site_name'    => $name,
		'og:title'        => wp_get_document_title(),
		'og:description'  => $desc,
		'og:url'          => $url,
		'og:image'        => $image['url'],
		'og:image:type'   => $image['type'],
		'og:image:width'  => $image['width'] ? (string) $image['width'] : '',
		'og:image:height' => $image['height'] ? (string) $image['height'] : '',
		'og:image:alt'    => $name,
		'twitter:card'    => $wide ? 'summary_large_image' : 'summary',
	);

	echo "\n";
	foreach ( $tags as $key => $value ) {
		if ( '' === $value ) {
			continue;
		}
		$attr = 0 === strpos( $key, 'twitter:' ) ? 'name' : 'property';
		$val  = in_array( $key, array( 'og:url', 'og:image' ), true ) ? esc_url( $value ) : esc_attr( $value );
		printf( "<meta %s=\"%s\" content=\"%s\" />\n", esc_attr( $attr ), esc_attr( $key ), $val ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
add_action( 'wp_head', 'vg7_share_tags', 5 );
