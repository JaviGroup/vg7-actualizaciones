<?php
/**
 * Soportes del tema, ubicaciones de menú y estilos del editor.
 */

defined( 'ABSPATH' ) || exit;

function vg7_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 80,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	/**
	 * Ubicaciones de menú. El tema hijo puede cambiarlas con el filtro vg7_menu_locations.
	 */
	register_nav_menus(
		apply_filters(
			'vg7_menu_locations',
			array(
				'principal' => __( 'Menú principal (header)', 'vg7' ),
				'footer-1'  => __( 'Footer: columna 1', 'vg7' ),
				'footer-2'  => __( 'Footer: columna 2', 'vg7' ),
				'legal'     => __( 'Footer: enlaces legales', 'vg7' ),
			)
		)
	);

	// La marca (colores y fuentes del tema hijo) también dentro del editor
	add_theme_support( 'editor-styles' );
	$editor = array( 'assets/css/vg7.css' );
	if ( vg7_brand_css_path() ) {
		$editor[] = vg7_brand_css_relative();
	}
	add_editor_style( $editor );
}
add_action( 'after_setup_theme', 'vg7_setup' );

/**
 * Ruta absoluta de marca.css del tema hijo, o cadena vacía si no existe.
 */
function vg7_brand_css_path() {
	$path = get_stylesheet_directory() . '/assets/css/marca.css';
	return ( is_child_theme() && file_exists( $path ) ) ? $path : '';
}

/**
 * Ruta de marca.css relativa al tema hijo (add_editor_style la busca primero en el hijo).
 */
function vg7_brand_css_relative() {
	return 'assets/css/marca.css';
}

/**
 * Sin script ni estilos de emojis de WordPress: el navegador ya los dibuja y son una petición extra en cada página.
 */
function vg7_sin_emojis() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'vg7_sin_emojis' );
