<?php
/**
 * Piezas compartidas por el tema y los bloques: iconos, botón, logo, imágenes y utilidades.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Trazos de los iconos (viewBox 24x24, trazo). Los plugins añaden los suyos con el filtro vg7_icons.
 */
function vg7_icon_paths() {
	static $paths = null;
	if ( null !== $paths ) {
		return $paths;
	}
	$paths = apply_filters(
		'vg7_icons',
		array(
			'arrow'    => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
			'arrow-ur' => '<path d="M7 7h10v10"/><path d="M7 17 17 7"/>',
			'chev'     => '<path d="m6 9 6 6 6-6"/>',
			'plus'     => '<path d="M5 12h14"/><path d="M12 5v14"/>',
			'menu'     => '<path d="M4 7h16M4 12h16M4 17h16"/>',
			'x'        => '<path d="M18 6 6 18M6 6l12 12"/>',
			'check'    => '<path d="M20 6 9 17l-5-5"/>',
			'phone'    => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
			'mail'     => '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
			'pin'      => '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
			'clock'    => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
			'shield'   => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
			'star'     => '<path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/>',
			'headset'  => '<path d="M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z"/><path d="M21 16v2a4 4 0 0 1-4 4h-5"/>',
			'fb'       => '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
			'ig'       => '<rect width="20" height="20" x="2" y="2" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><path d="M17.5 6.5h.01"/>',
			'tt'       => '<path d="M15.5 3v2.4a4.6 4.6 0 0 0 4.6 4.6"/><path d="M15.5 3H12v12.5a3 3 0 1 1-3-3"/>',
			'yt'       => '<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/>',
			'in'       => '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/>',
			'x-logo'   => '<path d="M4 4l11.733 16h4.267l-11.733-16z"/><path d="M4 20l6.768-6.768m2.46-2.46L20 4"/>',
			'wa'       => '<path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9l-5.05.9"/><path d="M9 10a.5.5 0 0 0 1 0v-1a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1"/>',
		)
	);
	return $paths;
}

/**
 * Icono SVG en línea (decorativo, oculto para lectores de pantalla).
 *
 * @param string $name  Nombre del icono.
 * @param string $class Clases CSS.
 * @return string
 */
function vg7_icon( $name, $class = '' ) {
	$paths = vg7_icon_paths();
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return sprintf(
		'<svg class="%s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%s</svg>',
		esc_attr( $class ),
		$paths[ $name ]
	);
}

/**
 * Botón doble (texto con giro 3D + caja con flecha). Funciona solo con CSS.
 *
 * @param array $args {
 *     @type string $label   Texto del botón.
 *     @type string $url     Enlace.
 *     @type string $variant '', 'dark', 'ghost', 'light', 'white' u 'outline-white'.
 *     @type string $size    '' o 'sm'.
 *     @type string $icon    Icono de la caja ('arrow', 'arrow-ur', 'phone'...). Vacío = sin caja.
 *     @type string $class   Clases extra.
 *     @type string $tag     'a' (enlace) o 'button' (envío de formulario).
 *     @type array  $attrs   Atributos extra (por ejemplo data-vg7-track).
 * }
 * @return string
 */
function vg7_button( $args ) {
	$a = wp_parse_args(
		$args,
		array(
			'label'   => '',
			'url'     => '#',
			'variant' => '',
			'size'    => '',
			'icon'    => 'arrow-ur',
			'class'   => '',
			'tag'     => 'a',
			'attrs'   => array(),
		)
	);
	if ( '' === trim( (string) $a['label'] ) ) {
		return '';
	}
	$classes = array( 'vg7-btn' );
	if ( $a['variant'] ) {
		$classes[] = 'vg7-btn-' . $a['variant'];
	}
	if ( $a['size'] ) {
		$classes[] = 'vg7-btn-' . $a['size'];
	}
	if ( $a['class'] ) {
		$classes[] = $a['class'];
	}
	$label = esc_html( $a['label'] );
	$inner = sprintf(
		'<span class="vg7-btn-text"><span class="vg7-btn-3d"><span class="vg7-front">%1$s</span><span class="vg7-back" aria-hidden="true">%1$s</span></span></span>',
		$label
	);
	if ( $a['icon'] ) {
		$icon   = vg7_icon( $a['icon'] );
		$inner .= sprintf( '<span class="vg7-btn-arrow" aria-hidden="true"><span class="vg7-btn-arrow-rot">%1$s%1$s</span></span>', $icon );
	}

	$extra = '';
	foreach ( (array) $a['attrs'] as $name => $value ) {
		$extra .= sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( $value ) );
	}

	if ( 'button' === $a['tag'] ) {
		return sprintf( '<button type="submit" class="%s"%s>%s</button>', esc_attr( implode( ' ', $classes ) ), $extra, $inner );
	}
	return sprintf(
		'<a class="%s" href="%s"%s>%s</a>',
		esc_attr( implode( ' ', $classes ) ),
		esc_url( $a['url'], array( 'http', 'https', 'tel', 'mailto' ) ),
		$extra,
		$inner
	);
}

/**
 * Logo del Personalizador o, si no hay, el nombre del sitio en texto.
 * El tema hijo puede reemplazarlo entero con el filtro vg7_logo_html.
 *
 * @param string $size 'md' (header) o 'lg' (footer).
 * @return string
 */
function vg7_logo( $size = 'md' ) {
	$custom = apply_filters( 'vg7_logo_html', '', $size );
	if ( $custom ) {
		return $custom;
	}
	if ( has_custom_logo() ) {
		return sprintf(
			'<a href="%s" class="vg7-logo vg7-logo-%s" rel="home">%s</a>',
			esc_url( home_url( '/' ) ),
			esc_attr( $size ),
			wp_get_attachment_image(
				(int) get_theme_mod( 'custom_logo' ),
				'medium',
				false,
				array(
					'alt'           => get_bloginfo( 'name' ),
					'loading'       => 'eager',
					'fetchpriority' => 'md' === $size ? 'high' : 'auto',
				)
			)
		);
	}
	return sprintf(
		'<a href="%s" class="vg7-logo vg7-logo-%s vg7-logo-text" rel="home">%s</a>',
		esc_url( home_url( '/' ) ),
		esc_attr( $size ),
		esc_html( get_bloginfo( 'name' ) )
	);
}

/**
 * Imagen de la Biblioteca de medios (con srcset) o, si no hay, una imagen de prueba.
 *
 * @param int    $id       ID del adjunto (0 = usar la de prueba).
 * @param string $fallback URL de la imagen de prueba (la pone el plugin del sitio).
 * @param array  $args     class, alt, size, loading ('lazy' o 'eager'), fetchpriority.
 * @return string
 */
function vg7_image( $id, $fallback = '', $args = array() ) {
	$a = wp_parse_args(
		$args,
		array(
			'class'         => '',
			'alt'           => '',
			'size'          => 'large',
			'loading'       => 'lazy',
			'fetchpriority' => '',
		)
	);
	$attrs = array(
		'class'   => $a['class'],
		'loading' => $a['loading'],
	);
	if ( $a['fetchpriority'] ) {
		$attrs['fetchpriority'] = $a['fetchpriority'];
	}
	if ( '' !== $a['alt'] ) {
		$attrs['alt'] = $a['alt'];
	}
	if ( $id ) {
		$html = wp_get_attachment_image( (int) $id, $a['size'], false, $attrs );
		if ( $html ) {
			return $html;
		}
	}
	if ( ! $fallback ) {
		return '';
	}
	return sprintf(
		'<img src="%s" alt="%s" class="%s" loading="%s" decoding="async"%s>',
		esc_url( $fallback ),
		esc_attr( $a['alt'] ),
		esc_attr( $a['class'] ),
		esc_attr( $a['loading'] ),
		$a['fetchpriority'] ? ' fetchpriority="' . esc_attr( $a['fetchpriority'] ) . '"' : ''
	);
}

/**
 * Líneas no vacías de un texto (cada salto de línea = un elemento).
 *
 * @param string $text Texto.
 * @return string[]
 */
function vg7_lines( $text ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $text ) ), 'strlen' ) );
}

/**
 * Convierte "a, b, c" en un arreglo limpio.
 *
 * @param string $text Texto separado por comas.
 * @return string[]
 */
function vg7_list( $text ) {
	return array_values( array_filter( array_map( 'trim', explode( ',', (string) $text ) ), 'strlen' ) );
}

/**
 * Lista de un campo repetible, siempre como arreglo de arreglos.
 *
 * @param mixed $items Valor del atributo.
 * @return array
 */
function vg7_items( $items ) {
	return is_array( $items ) ? array_values( array_filter( $items, 'is_array' ) ) : array();
}

/**
 * Etiqueta de título permitida (para que cada bloque deje elegir H2 o H3 sin romper la jerarquía).
 *
 * @param string $tag     Etiqueta pedida.
 * @param string $default Etiqueta por defecto.
 * @return string
 */
function vg7_heading_tag( $tag, $default = 'h2' ) {
	return in_array( $tag, array( 'h1', 'h2', 'h3', 'h4', 'p' ), true ) ? $tag : $default;
}
