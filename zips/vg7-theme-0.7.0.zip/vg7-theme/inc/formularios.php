<?php
/**
 * Motor de formularios de contacto (solicitudes).
 *
 * - Endpoint público REST: POST /wp-json/vg7/v1/solicitud (sin nonce, para que funcione con caché de página).
 * - Antispam: campo trampa (honeypot), formulario firmado con hora (token) y tiempo mínimo de llenado, límite por IP
 *   (solo cuentan los envíos correctos) y validación en el servidor (teléfono de EE. UU. con reglas de numeración).
 * - El navegador usa assets/js/vg7-forms.js: pide el token al cargar y envía con VG7Forms.send(form).
 * - Guarda cada solicitud como un registro "Solicitudes" en el administrador y avisa por correo.
 * - Lista con columnas, filtro por servicio y exportación a CSV. Ajustes: correos de aviso.
 * - Archivos opcionales (por ejemplo un currículum): un sitio los activa con el filtro vg7_form_files. Se validan en el
 *   servidor (tamaño, extensión y contenido real), se guardan fuera de acceso público y solo el administrador los descarga.
 *
 * El formulario (HTML) lo pone el bloque del sitio; aquí solo se recibe y se guarda.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Campos que se aceptan: nombre => etiqueta. Cualquier otro se ignora.
 * Los archivos que active el sitio (vg7_form_files) se suman solos con su etiqueta.
 */
function vg7_form_fields() {
	$fields = apply_filters(
		'vg7_form_fields',
		array(
			'nombre'              => __( 'Nombre', 'vg7' ),
			'telefono'            => __( 'Teléfono', 'vg7' ),
			'servicio'            => __( 'Servicio', 'vg7' ),
			'plan'                => __( 'Plan', 'vg7' ),
			'acepto_contacto'     => __( 'Acepta ser contactado', 'vg7' ),
			'acepto_promociones'  => __( 'Acepta promociones', 'vg7' ),
			'zip'                 => __( 'Código postal', 'vg7' ),
			'consentimiento'      => __( 'Texto aceptado', 'vg7' ),
			'utm_source'          => 'utm_source',
			'utm_medium'          => 'utm_medium',
			'utm_campaign'        => 'utm_campaign',
			'gclid'               => 'gclid',
			'fbclid'              => 'fbclid',
		)
	);
	foreach ( vg7_form_files() as $name => $cfg ) {
		if ( ! isset( $fields[ $name ] ) ) {
			$fields[ $name ] = $cfg['label'];
		}
	}
	return $fields;
}

/**
 * Archivos que acepta un formulario: nombre del campo => reglas. Por defecto ninguno (el motor no recibe archivos).
 * Un sitio los activa así:
 *
 *   add_filter( 'vg7_form_files', function () {
 *       return array( 'cv' => array( 'label' => 'Currículum', 'exts' => array( 'pdf', 'doc', 'docx' ), 'max' => 5 * MB_IN_BYTES, 'attach' => true ) );
 *   } );
 *
 * exts: solo valen las que el motor sabe comprobar (pdf, doc, docx, odt, rtf, jpg, jpeg, png). max: bytes.
 * attach: el correo de aviso lleva el archivo adjunto.
 */
function vg7_form_files() {
	$known = array_keys( vg7_forms_file_types() );
	$out   = array();
	foreach ( (array) apply_filters( 'vg7_form_files', array() ) as $name => $cfg ) {
		$name = sanitize_key( $name );
		if ( '' === $name || ! is_array( $cfg ) ) {
			continue;
		}
		$cfg         = wp_parse_args(
			$cfg,
			array(
				'label'  => $name,
				'exts'   => array( 'pdf' ),
				'max'    => 5 * MB_IN_BYTES,
				'attach' => true,
			)
		);
		$cfg['exts'] = array_values( array_intersect( array_map( 'strtolower', (array) $cfg['exts'] ), $known ) );
		$cfg['max']  = max( 1, (int) $cfg['max'] );
		if ( $cfg['exts'] ) {
			$out[ $name ] = $cfg;
		}
	}
	return $out;
}

/**
 * Tipos de archivo que se saben comprobar: extensión => tipo de contenido y firma (primeros bytes reales del archivo).
 */
function vg7_forms_file_types() {
	return array(
		'pdf'  => array( 'mime' => 'application/pdf', 'magic' => '%PDF-' ),
		'doc'  => array( 'mime' => 'application/msword', 'magic' => "\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1" ),
		'docx' => array( 'mime' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'magic' => "PK\x03\x04" ),
		'odt'  => array( 'mime' => 'application/vnd.oasis.opendocument.text', 'magic' => "PK\x03\x04" ),
		'rtf'  => array( 'mime' => 'application/rtf', 'magic' => '{\\rtf' ),
		'jpg'  => array( 'mime' => 'image/jpeg', 'magic' => "\xFF\xD8\xFF" ),
		'jpeg' => array( 'mime' => 'image/jpeg', 'magic' => "\xFF\xD8\xFF" ),
		'png'  => array( 'mime' => 'image/png', 'magic' => "\x89PNG\r\n\x1A\n" ),
	);
}

/**
 * URL del endpoint (los bloques la ponen en data-endpoint del formulario).
 */
function vg7_form_endpoint() {
	return esc_url_raw( rest_url( 'vg7/v1/solicitud' ) );
}

function vg7_forms_register_post_type() {
	register_post_type(
		'vg7_solicitud',
		array(
			'labels'             => array(
				'name'          => __( 'Solicitudes', 'vg7' ),
				'singular_name' => __( 'Solicitud', 'vg7' ),
				'menu_name'     => __( 'Solicitudes', 'vg7' ),
				'search_items'  => __( 'Buscar solicitudes', 'vg7' ),
				'not_found'     => __( 'Todavía no hay solicitudes.', 'vg7' ),
			),
			'public'             => false,
			'show_ui'            => true,
			'show_in_rest'       => false,
			'menu_position'      => 26,
			'menu_icon'          => 'dashicons-email-alt',
			'supports'           => array( 'title' ),
			'capability_type'    => array( 'solicitud', 'solicitudes' ),
			'capabilities'       => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'       => true,
			'has_archive'        => false,
			'rewrite'            => false,
			'exclude_from_search' => true,
		)
	);
}
add_action( 'init', 'vg7_forms_register_post_type' );

/* ---------- Recepción ---------- */

function vg7_forms_register_route() {
	register_rest_route(
		'vg7/v1',
		'/solicitud',
		array(
			'methods'             => 'POST',
			'callback'            => 'vg7_forms_handle',
			'permission_callback' => '__return_true',
		)
	);
	register_rest_route(
		'vg7/v1',
		'/token',
		array(
			'methods'             => 'GET',
			'callback'            => 'vg7_forms_token_response',
			'permission_callback' => '__return_true',
		)
	);
}
add_action( 'rest_api_init', 'vg7_forms_register_route' );

/* ---------- Formulario firmado ---------- */

/**
 * Token = hora de emisión + firma HMAC con una clave del sitio. Prueba que el envío viene de una página cargada de
 * verdad y permite medir cuánto tardó la persona en llenar el formulario. No guarda nada en el servidor.
 */
function vg7_forms_token() {
	$ts = (string) time();
	return $ts . '.' . hash_hmac( 'sha256', $ts, wp_salt( 'auth' ) . 'vg7-forms' );
}

function vg7_forms_token_response() {
	$res = new WP_REST_Response( array( 'token' => vg7_forms_token() ), 200 );
	$res->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
	return $res;
}

/**
 * Revisa el token: 'ok', 'missing' (no vino), 'bad' (firma falsa o caducado: más de 8 h) o 'fast' (menos de 4 s).
 */
function vg7_forms_check_token( $token ) {
	if ( ! is_string( $token ) || '' === $token ) {
		return 'missing';
	}
	$parts = explode( '.', $token, 2 );
	if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) ) {
		return 'bad';
	}
	$expected = hash_hmac( 'sha256', $parts[0], wp_salt( 'auth' ) . 'vg7-forms' );
	if ( ! hash_equals( $expected, $parts[1] ) ) {
		return 'bad';
	}
	$age = time() - (int) $parts[0];
	if ( $age > (int) apply_filters( 'vg7_form_token_max_age', 8 * HOUR_IN_SECONDS ) ) {
		return 'bad';
	}
	if ( $age < (int) apply_filters( 'vg7_form_min_seconds', 4 ) ) {
		return 'fast';
	}
	return 'ok';
}

/**
 * Script del navegador (token y envío). Lo piden los bloques con formulario en su view.asset.php.
 */
function vg7_forms_register_script() {
	wp_register_script(
		'vg7-forms',
		VG7_URL . '/assets/js/vg7-forms.js',
		array(),
		VG7_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_add_inline_script(
		'vg7-forms',
		'window.VG7FormsConfig=' . wp_json_encode(
			array(
				'send'  => esc_url_raw( rest_url( 'vg7/v1/solicitud' ) ),
				'token' => esc_url_raw( rest_url( 'vg7/v1/token' ) ),
			)
		) . ';',
		'before'
	);
}
add_action( 'init', 'vg7_forms_register_script' );

/**
 * IP del visitante. Se usa REMOTE_ADDR: los encabezados X-Forwarded-For los puede escribir cualquiera.
 */
function vg7_forms_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
}

/**
 * Límite: 5 envíos correctos por IP cada 10 minutos (los que fallan por un error al escribir no cuentan).
 */
function vg7_forms_limited() {
	return (int) get_transient( 'vg7_form_' . md5( vg7_forms_ip() ) ) >= 5;
}

function vg7_forms_count() {
	$key = 'vg7_form_' . md5( vg7_forms_ip() );
	set_transient( $key, (int) get_transient( $key ) + 1, 10 * MINUTE_IN_SECONDS );
}

function vg7_forms_error( $message, $status = 400 ) {
	return new WP_REST_Response( array( 'ok' => false, 'message' => $message ), $status );
}

/* ---------- Archivos ---------- */

/**
 * Tamaño legible: "0,2 MB" (con coma, como en el resto del sitio).
 */
function vg7_forms_size_label( $bytes ) {
	if ( $bytes < MB_IN_BYTES ) {
		return max( 1, (int) round( $bytes / KB_IN_BYTES ) ) . ' KB';
	}
	return str_replace( '.', ',', number_format( $bytes / MB_IN_BYTES, 1, '.', '' ) ) . ' MB';
}

/**
 * Carpeta privada de los archivos (dentro de uploads, con acceso web denegado).
 *
 * @return string Ruta absoluta sin barra final, o '' si no se pudo crear.
 */
function vg7_forms_files_dir() {
	$uploads = wp_upload_dir( null, false );
	if ( ! empty( $uploads['error'] ) ) {
		return '';
	}
	$dir = $uploads['basedir'] . '/vg7-solicitudes';
	if ( ! wp_mkdir_p( $dir ) ) {
		return '';
	}
	// Apache/LiteSpeed (Hostinger): se niega el acceso directo. En nginx hay que negar la carpeta en la configuración del servidor.
	if ( ! file_exists( $dir . '/.htaccess' ) ) {
		file_put_contents( $dir . '/.htaccess', "# Archivos privados de las solicitudes: solo se descargan desde el administrador.\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	if ( ! file_exists( $dir . '/index.php' ) ) {
		file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	return $dir;
}

/**
 * Revisa el archivo subido en un campo. Devuelve:
 *   array( 'none' => true )                                   no se adjuntó nada;
 *   array( 'error' => 'mensaje' )                             no es válido;
 *   array( 'tmp' => ..., 'ext' => ..., 'name' => ..., 'size' => ... ) válido (todavía sin guardar).
 */
function vg7_forms_check_file( $cfg, $file ) {
	if ( ! is_array( $file ) || ! isset( $file['error'] ) || is_array( $file['error'] ) ) {
		return array( 'none' => true );
	}
	if ( UPLOAD_ERR_NO_FILE === (int) $file['error'] ) {
		return array( 'none' => true );
	}
	/* translators: %s: tamaño máximo, por ejemplo "5,0 MB" */
	$too_big = sprintf( __( 'El archivo es muy pesado. El máximo es %s.', 'vg7' ), vg7_forms_size_label( $cfg['max'] ) );
	if ( in_array( (int) $file['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ) {
		// El límite del servidor (PHP) puede ser menor que el del formulario: se informa el que de verdad aplica.
		/* translators: %s: tamaño máximo, por ejemplo "2,0 MB" */
		return array( 'error' => sprintf( __( 'El archivo es muy pesado. El máximo es %s.', 'vg7' ), vg7_forms_size_label( min( $cfg['max'], (int) wp_max_upload_size() ) ) ) );
	}
	if ( UPLOAD_ERR_OK !== (int) $file['error'] || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
		return array( 'error' => __( 'No pudimos recibir el archivo. Inténtalo de nuevo.', 'vg7' ) );
	}
	$size = (int) filesize( $file['tmp_name'] );
	if ( $size < 1 ) {
		return array( 'error' => __( 'El archivo está vacío.', 'vg7' ) );
	}
	if ( $size > $cfg['max'] ) {
		return array( 'error' => $too_big );
	}
	$name = sanitize_file_name( wp_unslash( (string) ( isset( $file['name'] ) ? $file['name'] : '' ) ) );
	$ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
	/* translators: %s: extensiones permitidas, por ejemplo "PDF, DOC o DOCX" */
	$bad_type = sprintf( __( 'Adjunta un archivo %s.', 'vg7' ), vg7_forms_exts_label( $cfg['exts'] ) );
	if ( ! in_array( $ext, $cfg['exts'], true ) ) {
		return array( 'error' => $bad_type );
	}
	// El contenido real tiene que corresponder a la extensión (un .exe renombrado a .pdf no pasa).
	$types = vg7_forms_file_types();
	$magic = $types[ $ext ]['magic'];
	$head  = (string) file_get_contents( $file['tmp_name'], false, null, 0, strlen( $magic ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( $head !== $magic ) {
		return array( 'error' => $bad_type );
	}
	return array(
		'tmp'  => $file['tmp_name'],
		'ext'  => $ext,
		'name' => mb_substr( $name, 0, 120 ),
		'size' => $size,
	);
}

/**
 * "PDF, DOC o DOCX"
 */
function vg7_forms_exts_label( $exts ) {
	$exts = array_map( 'strtoupper', array_values( array_unique( $exts ) ) );
	if ( count( $exts ) < 2 ) {
		return implode( '', $exts );
	}
	$last = array_pop( $exts );
	return implode( ', ', $exts ) . ' ' . __( 'o', 'vg7' ) . ' ' . $last;
}

/**
 * Guarda un archivo ya validado con un nombre al azar. Devuelve la ruta relativa (AAAA/MM/nombre.ext) o ''.
 */
function vg7_forms_store_file( $checked ) {
	$base = vg7_forms_files_dir();
	if ( '' === $base ) {
		return '';
	}
	$sub = gmdate( 'Y/m' );
	if ( ! wp_mkdir_p( $base . '/' . $sub ) ) {
		return '';
	}
	$rel = $sub . '/' . bin2hex( random_bytes( 16 ) ) . '.' . $checked['ext'];
	if ( ! move_uploaded_file( $checked['tmp'], $base . '/' . $rel ) ) {
		return '';
	}
	chmod( $base . '/' . $rel, 0644 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	return $rel;
}

/**
 * Ruta absoluta de un archivo guardado, solo si la ruta relativa tiene el formato que genera el motor y el archivo existe.
 */
function vg7_forms_file_path( $rel ) {
	if ( ! is_string( $rel ) || ! preg_match( '#^\d{4}/\d{2}/[a-f0-9]{32}\.[a-z0-9]{2,4}$#', $rel ) ) {
		return '';
	}
	$base = vg7_forms_files_dir();
	$path = $base ? $base . '/' . $rel : '';
	return ( $path && is_file( $path ) ) ? $path : '';
}

/**
 * Descarga de un archivo desde el administrador: solo administradores, con enlace firmado (nonce).
 */
function vg7_forms_download_file() {
	$id    = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- se verifica abajo.
	$field = isset( $_GET['campo'] ) ? sanitize_key( wp_unslash( $_GET['campo'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'No tienes permiso.', 'vg7' ), 403 );
	}
	check_admin_referer( 'vg7_archivo_' . $id . '_' . $field );
	$files = vg7_form_files();
	if ( ! $id || 'vg7_solicitud' !== get_post_type( $id ) || ! isset( $files[ $field ] ) ) {
		wp_die( esc_html__( 'Archivo no encontrado.', 'vg7' ), 404 );
	}
	$path = vg7_forms_file_path( (string) get_post_meta( $id, '_vg7_' . $field . '_archivo', true ) );
	if ( '' === $path ) {
		wp_die( esc_html__( 'Archivo no encontrado.', 'vg7' ), 404 );
	}
	$ext   = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
	$types = vg7_forms_file_types();
	$name  = (string) get_post_meta( $id, '_vg7_' . $field . '_nombre', true );
	$name  = '' !== $name ? $name : $field . '.' . $ext;
	nocache_headers();
	header( 'Content-Type: ' . ( isset( $types[ $ext ] ) ? $types[ $ext ]['mime'] : 'application/octet-stream' ) );
	header( 'Content-Disposition: attachment; filename="' . str_replace( '"', '', $name ) . '"; filename*=UTF-8\'\'' . rawurlencode( $name ) );
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Content-Length: ' . filesize( $path ) );
	readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
}
add_action( 'admin_post_vg7_solicitud_archivo', 'vg7_forms_download_file' );

/**
 * Enlace de descarga (firmado) de un archivo de una solicitud.
 */
function vg7_forms_file_link( $id, $field ) {
	return wp_nonce_url( admin_url( 'admin-post.php?action=vg7_solicitud_archivo&id=' . (int) $id . '&campo=' . rawurlencode( $field ) ), 'vg7_archivo_' . (int) $id . '_' . $field );
}

/**
 * Al borrar una solicitud también se borran sus archivos.
 */
function vg7_forms_delete_files( $post_id ) {
	if ( 'vg7_solicitud' !== get_post_type( $post_id ) ) {
		return;
	}
	foreach ( array_keys( (array) get_post_meta( $post_id ) ) as $key ) {
		if ( preg_match( '/^_vg7_[a-z0-9_]+_archivo$/', $key ) ) {
			$path = vg7_forms_file_path( (string) get_post_meta( $post_id, $key, true ) );
			if ( $path ) {
				wp_delete_file( $path );
			}
		}
	}
}
add_action( 'before_delete_post', 'vg7_forms_delete_files' );

function vg7_forms_handle( WP_REST_Request $request ) {
	$params = $request->get_params();

	// Trampa para bots: si viene llena, se responde "bien" y no se guarda nada.
	if ( ! empty( $params['sitio_web'] ) ) {
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}
	// Formulario firmado. Sin token se acepta mientras dure la transición de los sitios ya publicados
	// (filtro vg7_form_allow_missing_token); firma falsa o caducada se rechaza; demasiado rápido = bot (se descarta).
	$token = vg7_forms_check_token( isset( $params['vg7_token'] ) ? $params['vg7_token'] : '' );
	if ( 'fast' === $token || ( 'missing' === $token && ! apply_filters( 'vg7_form_allow_missing_token', true ) ) ) {
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}
	if ( 'bad' === $token ) {
		return vg7_forms_error( __( 'La página lleva mucho tiempo abierta. Recárgala e inténtalo de nuevo.', 'vg7' ) );
	}
	if ( vg7_forms_limited() ) {
		return vg7_forms_error( __( 'Demasiados intentos. Inténtalo de nuevo en unos minutos o llámanos.', 'vg7' ), 429 );
	}

	$data = array();
	foreach ( array_keys( vg7_form_fields() ) as $name ) {
		$value          = isset( $params[ $name ] ) ? $params[ $name ] : '';
		$max            = 'consentimiento' === $name ? 600 : 200;
		$data[ $name ] = is_scalar( $value ) ? mb_substr( sanitize_text_field( (string) $value ), 0, $max ) : '';
	}

	$data['nombre'] = trim( $data['nombre'] );
	$digits         = preg_replace( '/\D+/', '', $data['telefono'] );
	if ( 11 === strlen( $digits ) && '1' === $digits[0] ) {
		$digits = substr( $digits, 1 );
	}
	if ( mb_strlen( $data['nombre'] ) < 2 ) {
		return vg7_forms_error( __( 'Escribe tu nombre.', 'vg7' ) );
	}
	if ( 10 !== strlen( $digits ) ) {
		return vg7_forms_error( __( 'Escribe un teléfono de 10 dígitos.', 'vg7' ) );
	}
	// Numeración de EE. UU.: ni el código de área ni la central empiezan por 0 o 1 (descarta 1234567890 y similares).
	if ( ! preg_match( '/^[2-9]\d{2}[2-9]\d{6}$/', $digits ) ) {
		return vg7_forms_error( __( 'Escribe un teléfono válido de Estados Unidos.', 'vg7' ) );
	}
	// Código postal: solo si el formulario lo trae.
	if ( array_key_exists( 'zip', $params ) && ! preg_match( '/^\d{5}(-\d{4})?$/', trim( $data['zip'] ) ) ) {
		return vg7_forms_error( __( 'Escribe un código postal de 5 dígitos.', 'vg7' ) );
	}
	// Servicio: solo se valida si el sitio da una lista con el filtro vg7_form_servicios (en Wireless es opcional).
	$permitidos = apply_filters( 'vg7_form_servicios', array() );
	if ( $permitidos && array_key_exists( 'servicio', $params ) && ! in_array( $data['servicio'], $permitidos, true ) ) {
		return vg7_forms_error( __( 'Elige un servicio de la lista.', 'vg7' ) );
	}
	// Validación extra de cada sitio (por ejemplo, un correo): el filtro devuelve un mensaje de error o ''.
	$extra = apply_filters( 'vg7_form_validate', '', $data, $params );
	if ( $extra ) {
		return vg7_forms_error( (string) $extra );
	}
	if ( empty( $params['acepto_contacto'] ) ) {
		return vg7_forms_error( __( 'Debes aceptar que te contactemos.', 'vg7' ) );
	}
	// Archivos opcionales: se revisan todos antes de guardar nada.
	$uploads = $request->get_file_params();
	$checked = array();
	foreach ( vg7_form_files() as $field => $cfg ) {
		$data[ $field ] = '';
		$result         = vg7_forms_check_file( $cfg, isset( $uploads[ $field ] ) ? $uploads[ $field ] : null );
		if ( isset( $result['error'] ) ) {
			return vg7_forms_error( $result['error'] );
		}
		if ( ! isset( $result['none'] ) ) {
			$checked[ $field ] = $result;
		}
	}
	// Ajuste final de los datos ya validados (por ejemplo, completar un campo a partir de otro).
	$data = apply_filters( 'vg7_form_data', $data, $params );
	$data['telefono']           = sprintf( '(%s) %s-%s', substr( $digits, 0, 3 ), substr( $digits, 3, 3 ), substr( $digits, 6 ) );
	$data['acepto_contacto']    = 'Sí';
	$data['acepto_promociones'] = ! empty( $params['acepto_promociones'] ) ? 'Sí' : 'No';

	$page = '';
	if ( ! empty( $params['pagina'] ) && is_scalar( $params['pagina'] ) ) {
		$page = esc_url_raw( (string) $params['pagina'] );
	}
	$data['pagina'] = $page;

	// Guardado de los archivos (con nombre al azar, fuera de acceso público).
	$stored = array();
	foreach ( $checked as $field => $file ) {
		$rel = vg7_forms_store_file( $file );
		if ( '' === $rel ) {
			foreach ( $stored as $done ) {
				wp_delete_file( vg7_forms_file_path( $done['rel'] ) );
			}
			return vg7_forms_error( __( 'No pudimos guardar el archivo. Inténtalo de nuevo o escríbenos.', 'vg7' ), 500 );
		}
		$stored[ $field ] = array(
			'rel'  => $rel,
			'file' => $file,
		);
		$data[ $field ]   = $file['name'] . ' (' . vg7_forms_size_label( $file['size'] ) . ')';
	}

	$id = wp_insert_post(
		array(
			'post_type'   => 'vg7_solicitud',
			'post_status' => 'publish',
			'post_title'  => $data['nombre'] . ' · ' . $data['telefono'],
		),
		true
	);
	if ( is_wp_error( $id ) ) {
		foreach ( $stored as $done ) {
			wp_delete_file( vg7_forms_file_path( $done['rel'] ) );
		}
		return vg7_forms_error( __( 'No pudimos guardar tu solicitud. Llámanos, por favor.', 'vg7' ), 500 );
	}
	foreach ( $data as $name => $value ) {
		update_post_meta( $id, '_vg7_' . $name, $value );
	}
	foreach ( $stored as $field => $done ) {
		update_post_meta( $id, '_vg7_' . $field . '_archivo', $done['rel'] );
		update_post_meta( $id, '_vg7_' . $field . '_nombre', $done['file']['name'] );
		update_post_meta( $id, '_vg7_' . $field . '_tamano', $done['file']['size'] );
	}
	vg7_forms_count();

	// El correo sale después de responder al visitante (no lo hace esperar si el servidor de correo tarda).
	add_action(
		'shutdown',
		function () use ( $id, $data ) {
			if ( function_exists( 'fastcgi_finish_request' ) ) {
				fastcgi_finish_request();
			}
			vg7_forms_notify( $id, $data );
		}
	);
	do_action( 'vg7_solicitud_creada', $id, $data );

	return new WP_REST_Response( array( 'ok' => true ), 200 );
}

/* ---------- Aviso por correo ---------- */

function vg7_forms_recipients() {
	$raw  = (string) get_option( 'vg7_forms_emails', '' );
	$list = array_filter( array_map( 'sanitize_email', preg_split( '/[\s,;]+/', $raw ) ) );
	return $list ? array_values( $list ) : array( get_option( 'admin_email' ) );
}

function vg7_forms_notify( $id, $data ) {
	$labels = vg7_form_fields();
	$lines  = array( __( 'Nueva solicitud desde el sitio:', 'vg7' ), '' );
	// Campos que salen en el correo; un sitio con campos propios los suma con el filtro vg7_form_notify_fields.
	$notify = apply_filters( 'vg7_form_notify_fields', array( 'nombre', 'telefono', 'zip', 'servicio', 'plan', 'acepto_promociones', 'utm_source', 'utm_medium', 'utm_campaign', 'gclid', 'fbclid', 'pagina' ) );
	foreach ( $notify as $k ) {
		if ( ! empty( $data[ $k ] ) ) {
			$lines[] = ( isset( $labels[ $k ] ) ? $labels[ $k ] : ucfirst( $k ) ) . ': ' . $data[ $k ];
		}
	}
	$lines[] = '';
	$lines[] = admin_url( 'post.php?post=' . (int) $id . '&action=edit' );

	// Sin saltos de línea en el asunto (evita inyección de encabezados).
	$subject = '[' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . '] ' . __( 'Nueva solicitud', 'vg7' ) . ': ' . str_replace( array( "\r", "\n" ), ' ', $data['nombre'] );
	// Cada sitio puede cambiar el asunto (filtro vg7_form_notify_subject); se vuelven a quitar los saltos de línea.
	$subject = str_replace( array( "\r", "\n" ), ' ', (string) apply_filters( 'vg7_form_notify_subject', $subject, $id, $data ) );
	// Archivos adjuntos (los campos de vg7_form_files con attach activo).
	$attachments = array();
	foreach ( vg7_form_files() as $field => $cfg ) {
		if ( ! empty( $cfg['attach'] ) ) {
			$path = vg7_forms_file_path( (string) get_post_meta( $id, '_vg7_' . $field . '_archivo', true ) );
			if ( $path ) {
				$attachments[] = $path;
			}
		}
	}
	wp_mail( vg7_forms_recipients(), $subject, implode( "\n", $lines ), '', $attachments );
}


/* ---------- Permisos: rol que solo ve la lista ---------- */

/**
 * Permisos propios de las solicitudes (no se mezclan con los de las entradas).
 */
function vg7_forms_caps() {
	return array( 'edit_solicitudes', 'edit_others_solicitudes', 'edit_published_solicitudes', 'edit_private_solicitudes', 'read_private_solicitudes', 'delete_solicitudes', 'delete_others_solicitudes', 'delete_published_solicitudes', 'delete_private_solicitudes', 'publish_solicitudes' );
}

/**
 * Crea el rol "Asesor de solicitudes" (solo ve la lista) y da los permisos al administrador. Una vez por versión.
 */
function vg7_forms_roles() {
	if ( get_option( 'vg7_forms_roles_v' ) === '1' ) {
		return;
	}
	$admin = get_role( 'administrator' );
	if ( $admin ) {
		foreach ( vg7_forms_caps() as $cap ) {
			$admin->add_cap( $cap );
		}
	}
	add_role(
		'vg7_asesor',
		__( 'Asesor de solicitudes', 'vg7' ),
		array(
			'read'                       => true,
			'edit_solicitudes'           => true, // Abre el menú Solicitudes y la lista.
			'edit_others_solicitudes'    => true,
			'edit_published_solicitudes' => true,
		)
	);
	update_option( 'vg7_forms_roles_v', '1' );
}
add_action( 'init', 'vg7_forms_roles', 20 );

/**
 * Solo el administrador puede abrir, editar o borrar una solicitud. El asesor ve la lista con todas las columnas
 * pero no puede cambiar nada.
 */
function vg7_forms_map_caps( $caps, $cap, $user_id, $args ) {
	if ( in_array( $cap, array( 'edit_post', 'delete_post' ), true ) && ! empty( $args[0] ) && 'vg7_solicitud' === get_post_type( $args[0] ) && ! user_can( $user_id, 'manage_options' ) ) {
		return array( 'do_not_allow' );
	}
	return $caps;
}
add_filter( 'map_meta_cap', 'vg7_forms_map_caps', 10, 4 );

/* ---------- Administrador: columnas, filtro y CSV ---------- */

function vg7_forms_columns( $cols ) {
	return array(
		'cb'       => $cols['cb'],
		'title'    => __( 'Solicitud', 'vg7' ),
		'telefono' => __( 'Teléfono', 'vg7' ),
		'servicio' => __( 'Servicio', 'vg7' ),
		'plan'     => __( 'Plan', 'vg7' ),
		'origen'   => __( 'Origen', 'vg7' ),
		'promos'   => __( 'Promociones', 'vg7' ),
		'pagina'   => __( 'Página', 'vg7' ),
		'date'     => __( 'Fecha', 'vg7' ),
	);
}
add_filter( 'manage_vg7_solicitud_posts_columns', 'vg7_forms_columns' );

function vg7_forms_column( $col, $post_id ) {
	if ( 'origen' === $col ) {
		$src = get_post_meta( $post_id, '_vg7_utm_source', true );
		$med = get_post_meta( $post_id, '_vg7_utm_medium', true );
		echo esc_html( $src ? $src . ( $med ? ' / ' . $med : '' ) : ( get_post_meta( $post_id, '_vg7_gclid', true ) ? 'Google Ads' : ( get_post_meta( $post_id, '_vg7_fbclid', true ) ? 'Meta' : 'Directo' ) ) );
	} elseif ( 'promos' === $col ) {
		echo esc_html( (string) get_post_meta( $post_id, '_vg7_acepto_promociones', true ) );
	} elseif ( 'pagina' === $col ) {
		$url = (string) get_post_meta( $post_id, '_vg7_pagina', true );
		echo esc_html( $url ? wp_parse_url( $url, PHP_URL_PATH ) : '' );
	} elseif ( in_array( $col, array( 'telefono', 'servicio', 'plan' ), true ) ) {
		echo esc_html( (string) get_post_meta( $post_id, '_vg7_' . $col, true ) );
	}
}
add_action( 'manage_vg7_solicitud_posts_custom_column', 'vg7_forms_column', 10, 2 );

/**
 * Ficha de la solicitud (solo lectura).
 */
function vg7_forms_metabox() {
	add_meta_box(
		'vg7_solicitud_datos',
		__( 'Datos enviados', 'vg7' ),
		function ( $post ) {
			$labels = vg7_form_fields();
			$labels['pagina'] = __( 'Página', 'vg7' );
			echo '<table class="widefat striped"><tbody>';
			$files = vg7_form_files();
			foreach ( $labels as $k => $label ) {
				$v = get_post_meta( $post->ID, '_vg7_' . $k, true );
				if ( '' === $v ) {
					continue;
				}
				if ( isset( $files[ $k ] ) ) {
					// Archivo: nombre y enlace de descarga (solo el administrador puede abrirlo).
					$has = '' !== vg7_forms_file_path( (string) get_post_meta( $post->ID, '_vg7_' . $k . '_archivo', true ) );
					$cell = esc_html( $v ) . ( $has && current_user_can( 'manage_options' ) ? ' &nbsp; <a class="button button-small" href="' . esc_url( vg7_forms_file_link( $post->ID, $k ) ) . '">' . esc_html__( 'Descargar', 'vg7' ) . '</a>' : '' );
					echo '<tr><th style="width:220px">' . esc_html( $label ) . '</th><td>' . $cell . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- armado con esc_html y esc_url.
					continue;
				}
				echo '<tr><th style="width:220px">' . esc_html( $label ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
			}
			echo '</tbody></table>';
		},
		'vg7_solicitud',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'vg7_forms_metabox' );

function vg7_forms_export_button( $which ) {
	global $typenow;
	if ( 'top' !== $which || 'vg7_solicitud' !== $typenow || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$url = wp_nonce_url( admin_url( 'admin-post.php?action=vg7_solicitudes_csv' ), 'vg7_solicitudes_csv' );
	echo '<a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Exportar a CSV', 'vg7' ) . '</a>';
}
add_action( 'manage_posts_extra_tablenav', 'vg7_forms_export_button' );

/**
 * Evita que Excel ejecute fórmulas (=, +, -, @) al abrir el CSV.
 */
function vg7_forms_csv_cell( $value ) {
	$value = (string) $value;
	if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
		$value = "'" . $value;
	}
	return $value;
}

function vg7_forms_export() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'No tienes permiso.', 'vg7' ), 403 );
	}
	check_admin_referer( 'vg7_solicitudes_csv' );

	// Columnas del CSV; un sitio con campos propios las suma con el filtro vg7_form_export_fields.
	$keys = apply_filters( 'vg7_form_export_fields', array( 'nombre', 'telefono', 'zip', 'servicio', 'plan', 'acepto_promociones', 'consentimiento', 'utm_source', 'utm_medium', 'utm_campaign', 'gclid', 'fbclid', 'pagina' ) );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="solicitudes-' . gmdate( 'Y-m-d' ) . '.csv"' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" ); // BOM para que Excel lea los acentos.
	fputcsv( $out, array_merge( array( 'fecha' ), $keys ) );

	$ids = get_posts(
		array(
			'post_type'      => 'vg7_solicitud',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'orderby'        => 'date',
			'order'          => 'DESC',
		)
	);
	foreach ( $ids as $id ) {
		$row = array( get_the_date( 'Y-m-d H:i', $id ) );
		foreach ( $keys as $k ) {
			$row[] = vg7_forms_csv_cell( get_post_meta( $id, '_vg7_' . $k, true ) );
		}
		fputcsv( $out, $row );
	}
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
}
add_action( 'admin_post_vg7_solicitudes_csv', 'vg7_forms_export' );

/* ---------- Ajustes: correos de aviso ---------- */

function vg7_forms_settings_init() {
	register_setting(
		'vg7_forms',
		'vg7_forms_emails',
		array(
			'type'              => 'string',
			'sanitize_callback' => function ( $value ) {
				return implode( ', ', array_filter( array_map( 'sanitize_email', preg_split( '/[\s,;]+/', (string) $value ) ) ) );
			},
			'default'           => '',
		)
	);
}
add_action( 'admin_init', 'vg7_forms_settings_init' );

function vg7_forms_settings_menu() {
	add_submenu_page( 'edit.php?post_type=vg7_solicitud', __( 'Ajustes de solicitudes', 'vg7' ), __( 'Ajustes', 'vg7' ), 'manage_options', 'vg7-solicitudes-ajustes', 'vg7_forms_settings_page' );
}
add_action( 'admin_menu', 'vg7_forms_settings_menu' );

function vg7_forms_settings_page() {
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Ajustes de solicitudes', 'vg7' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'vg7_forms' ); ?>
			<table class="form-table" role="presentation"><tr>
				<th scope="row"><label for="vg7_forms_emails"><?php esc_html_e( 'Correos que reciben el aviso', 'vg7' ); ?></label></th>
				<td>
					<input type="text" class="regular-text" id="vg7_forms_emails" name="vg7_forms_emails" value="<?php echo esc_attr( (string) get_option( 'vg7_forms_emails', '' ) ); ?>">
					<p class="description"><?php esc_html_e( 'Separados por coma. Si lo dejas vacío, se usa el correo del administrador del sitio.', 'vg7' ); ?></p>
				</td>
			</tr></table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
