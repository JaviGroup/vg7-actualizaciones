<?php
/**
 * Actualizaciones desde el panel de WordPress (el aviso "Hay una nueva versión" y el botón Actualizar) para los paquetes VG7, sin subir zips a mano.
 *
 * Cómo funciona: este tema (el padre) registra una consulta de actualización por cada paquete VG7 que está en uso: él mismo, el tema hijo activo y los
 * plugins "vg7-*" activos. Cada consulta pide un archivo JSON (<slug>.json) con la última versión y la dirección del zip; si la versión es mayor que la
 * instalada, WordPress muestra el aviso y se actualiza con un clic. La consulta la hace la librería Plugin Update Checker 6.0 (MIT, inc/lib/): cada 12 horas
 * y cuando se pulsa "Buscar actualizaciones".
 *
 * Dónde están los JSON y los zips: en un repositorio público de GitHub que solo guarda eso (ver docs/ACTUALIZACIONES.md y `npm run publicar`).
 * La dirección base se define de una de estas formas (en este orden de prioridad):
 *   1. la constante VG7_UPDATES_URL en wp-config.php (por sitio),
 *   2. el filtro vg7_updates_url,
 *   3. la dirección por defecto de VG7_UPDATES_URL_DEFECTO (la del repositorio de actualizaciones del proyecto).
 * Si la dirección queda vacía, no se registra nada (no hay consultas ni carga la librería).
 *
 * Filtros: vg7_updates_url (dirección base), vg7_updates_paquetes (paquetes que se consultan: slug => archivo principal).
 */

defined( 'ABSPATH' ) || exit;

use YahnisElsts\PluginUpdateChecker\v6\PucFactory;

// Dirección por defecto de los JSON (con barra al final): el repositorio público de actualizaciones del proyecto.
if ( ! defined( 'VG7_UPDATES_URL_DEFECTO' ) ) {
	define( 'VG7_UPDATES_URL_DEFECTO', 'https://raw.githubusercontent.com/JaviGroup/vg7-actualizaciones/main/' );
}

/**
 * Dirección base de los JSON de actualización (con barra al final) o '' si está apagado.
 */
function vg7_updates_base() {
	$base = defined( 'VG7_UPDATES_URL' ) ? (string) VG7_UPDATES_URL : (string) VG7_UPDATES_URL_DEFECTO;
	$base = trim( (string) apply_filters( 'vg7_updates_url', $base ) );
	return '' === $base ? '' : trailingslashit( $base );
}

/**
 * Paquetes VG7 en uso: slug (carpeta) => ruta del archivo principal. El tema padre y el hijo activo van por su functions.php; los plugins, por su archivo principal
 * (vg7-<nombre>/vg7-<nombre>.php), solo los activos.
 *
 * @return array
 */
function vg7_updates_paquetes() {
	$paquetes = array();

	$padre              = get_template();
	$paquetes[ $padre ] = VG7_DIR . '/functions.php';
	$hijo               = get_stylesheet();
	if ( $hijo !== $padre && 0 === strpos( $hijo, 'vg7-' ) ) {
		$paquetes[ $hijo ] = get_stylesheet_directory() . '/functions.php';
	}

	foreach ( (array) get_option( 'active_plugins', array() ) as $plugin ) {
		$plugin = (string) $plugin;
		if ( 0 === strpos( $plugin, 'vg7-' ) && false !== strpos( $plugin, '/' ) ) {
			$paquetes[ dirname( $plugin ) ] = WP_PLUGIN_DIR . '/' . $plugin;
		}
	}

	return (array) apply_filters( 'vg7_updates_paquetes', $paquetes );
}

/**
 * Registra las consultas. Se hace al cargar el tema (no solo en el panel) para que las vea también el cron de WordPress.
 */
function vg7_updates_registrar() {
	$base = vg7_updates_base();
	if ( '' === $base ) {
		return;
	}
	$lib = VG7_DIR . '/inc/lib/plugin-update-checker/plugin-update-checker.php';
	if ( ! file_exists( $lib ) ) {
		return;
	}
	require_once $lib;

	foreach ( vg7_updates_paquetes() as $slug => $archivo ) {
		if ( ! is_string( $archivo ) || ! file_exists( $archivo ) ) {
			continue;
		}
		PucFactory::buildUpdateChecker( $base . $slug . '.json', $archivo, $slug );
	}
}
add_action( 'after_setup_theme', 'vg7_updates_registrar', 20 );
