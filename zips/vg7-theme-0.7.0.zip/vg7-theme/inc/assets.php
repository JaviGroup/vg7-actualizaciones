<?php
/**
 * CSS y JS.
 *
 * - vg7.css y tema.js se cargan en todo el sitio (header, footer, botones, enlaces).
 * - El motor de animaciones (vg7-motion) y sus librerías (GSAP, ScrollTrigger, SplitText, Lenis)
 *   solo se registran: los carga WordPress cuando un bloque de la página lo pide en su view.asset.php.
 * - El kit del editor (vg7-editor-kit) lo piden los index.asset.php de los bloques.
 */

defined( 'ABSPATH' ) || exit;

function vg7_register_assets() {
	$vendor = VG7_URL . '/assets/vendor/';
	$defer  = array(
		'in_footer' => true,
		'strategy'  => 'defer',
	);

	wp_register_script( 'vg7-gsap', $vendor . 'gsap.min.js', array(), '3.15.0', $defer );
	wp_register_script( 'vg7-scrolltrigger', $vendor . 'ScrollTrigger.min.js', array( 'vg7-gsap' ), '3.15.0', $defer );
	wp_register_script( 'vg7-splittext', $vendor . 'SplitText.min.js', array( 'vg7-gsap' ), '3.15.0', $defer );
	wp_register_script( 'vg7-lenis', $vendor . 'lenis.min.js', array(), '1.3.26', $defer );
	// Scroll suave (Lenis): activo por defecto; un sitio lo apaga con add_filter( 'vg7_lenis', '__return_false' ).
	$lenis = (bool) apply_filters( 'vg7_lenis', true );
	wp_register_script(
		'vg7-motion',
		VG7_URL . '/assets/js/vg7-motion.js',
		$lenis ? array( 'vg7-gsap', 'vg7-scrolltrigger', 'vg7-splittext', 'vg7-lenis' ) : array( 'vg7-gsap', 'vg7-scrolltrigger', 'vg7-splittext' ),
		VG7_VERSION,
		$defer
	);
	if ( ! $lenis ) {
		wp_add_inline_script( 'vg7-motion', 'window.VG7Config=Object.assign(window.VG7Config||{},{lenis:false});', 'before' );
	}

	wp_register_script(
		'vg7-editor-kit',
		VG7_URL . '/assets/js/editor-kit.js',
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ),
		VG7_VERSION,
		true
	);
}
add_action( 'init', 'vg7_register_assets', 5 );

function vg7_enqueue_front() {
	wp_enqueue_style( 'vg7', VG7_URL . '/assets/css/vg7.css', array(), VG7_VERSION );

	$brand = vg7_brand_css_path();
	if ( $brand ) {
		wp_enqueue_style(
			'vg7-marca',
			get_stylesheet_directory_uri() . '/assets/css/marca.css',
			array( 'vg7' ),
			(string) filemtime( $brand )
		);
	}

	wp_enqueue_script(
		'vg7-tema',
		VG7_URL . '/assets/js/tema.js',
		array(),
		VG7_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'vg7_enqueue_front' );

/**
 * Marca que hay JS (y si habrá animación) antes de pintar, para que las secciones fijas
 * no salten al cargar. Solo en páginas con bloques VG7. Si el motor no arranca en 4 s,
 * se muestra todo sin animación (el contenido nunca queda oculto).
 */
function vg7_head_flag() {
	echo "<script>document.documentElement.classList.add('js');</script>\n";
	if ( ! vg7_page_has_blocks() ) {
		return;
	}
	echo "<script>(function(d){if(!matchMedia('(prefers-reduced-motion: reduce)').matches)d.classList.add('vg7-motion');setTimeout(function(){d.classList.add('vg7-ready');if(!(window.VG7&&window.VG7.motion))d.classList.remove('vg7-motion')},4000)})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'vg7_head_flag', 1 );
