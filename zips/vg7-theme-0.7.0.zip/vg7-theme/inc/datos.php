<?php
/**
 * Datos del sitio editables en Apariencia → Personalizar → Datos del sitio.
 *
 * El tema hijo o el plugin del sitio pueden añadir campos o cambiar los valores por defecto
 * con el filtro vg7_settings:
 *
 *   add_filter( 'vg7_settings', function ( $s ) {
 *       $s['phone'][1] = '888 526 2755';
 *       return $s;
 *   } );
 */

defined( 'ABSPATH' ) || exit;

/**
 * Campos: clave => array( etiqueta, valor por defecto, tipo ). Tipos: text, link, textarea.
 */
function vg7_settings() {
	return apply_filters(
		'vg7_settings',
		array(
			'phone'       => array( __( 'Teléfono (como se muestra)', 'vg7' ), '', 'text' ),
			'phone_link'  => array( __( 'Teléfono (enlace, ej. tel:+18885262755)', 'vg7' ), '', 'link' ),
			'whatsapp'    => array( __( 'WhatsApp (enlace, ej. https://wa.me/18885262755)', 'vg7' ), '', 'link' ),
			'email'       => array( __( 'Correo de contacto', 'vg7' ), '', 'text' ),
			'address'     => array( __( 'Dirección', 'vg7' ), '', 'textarea' ),
			'cta_label'   => array( __( 'Botón del header: texto', 'vg7' ), __( 'Contáctanos', 'vg7' ), 'text' ),
			'cta_url'     => array( __( 'Botón del header: enlace', 'vg7' ), '#contacto', 'link' ),
			'footer_text' => array( __( 'Texto del footer', 'vg7' ), '', 'textarea' ),
			'facebook'    => array( 'Facebook (URL)', '', 'link' ),
			'instagram'   => array( 'Instagram (URL)', '', 'link' ),
			'tiktok'      => array( 'TikTok (URL)', '', 'link' ),
			'youtube'     => array( 'YouTube (URL)', '', 'link' ),
			'linkedin'    => array( 'LinkedIn (URL)', '', 'link' ),
			'x'           => array( 'X (URL)', '', 'link' ),
			'privacy_url' => array( __( 'Política de privacidad (URL)', 'vg7' ), '', 'link' ),
			'terms_url'   => array( __( 'Términos y condiciones (URL)', 'vg7' ), '', 'link' ),
			'copyright'   => array( __( 'Texto de copyright ({año} = año actual)', 'vg7' ), 'Copyright © {año}', 'text' ),
		)
	);
}

/**
 * Valor de un dato del sitio (o su valor por defecto).
 *
 * @param string $key Clave del dato.
 * @return string
 */
function vg7_opt( $key ) {
	$settings = vg7_settings();
	$default  = isset( $settings[ $key ] ) ? $settings[ $key ][1] : '';
	$value    = (string) get_theme_mod( 'vg7_' . $key, $default );
	return str_replace( '{año}', gmdate( 'Y' ), $value );
}

/**
 * Redes sociales con valor: clave => array( icono, nombre ).
 */
function vg7_social_links() {
	$nets = array(
		'facebook'  => array( 'fb', 'Facebook' ),
		'instagram' => array( 'ig', 'Instagram' ),
		'tiktok'    => array( 'tt', 'TikTok' ),
		'youtube'   => array( 'yt', 'YouTube' ),
		'linkedin'  => array( 'in', 'LinkedIn' ),
		'x'         => array( 'x-logo', 'X' ),
		'whatsapp'  => array( 'wa', 'WhatsApp' ),
	);
	$out = array();
	foreach ( $nets as $key => $net ) {
		$url = vg7_opt( $key );
		if ( $url ) {
			$out[ $key ] = array(
				'icon' => $net[0],
				'name' => $net[1],
				'url'  => $url,
			);
		}
	}
	return $out;
}

function vg7_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'vg7_datos',
		array(
			'title'    => __( 'Datos del sitio', 'vg7' ),
			'priority' => 30,
		)
	);
	foreach ( vg7_settings() as $key => $conf ) {
		$type = isset( $conf[2] ) ? $conf[2] : 'text';
		$wp_customize->add_setting(
			'vg7_' . $key,
			array(
				'default'           => $conf[1],
				'sanitize_callback' => 'link' === $type ? 'vg7_sanitize_link' : ( 'textarea' === $type ? 'sanitize_textarea_field' : 'sanitize_text_field' ),
			)
		);
		$wp_customize->add_control(
			'vg7_' . $key,
			array(
				'label'   => $conf[0],
				'section' => 'vg7_datos',
				'type'    => 'textarea' === $type ? 'textarea' : 'text',
			)
		);
	}
}
add_action( 'customize_register', 'vg7_customize_register' );

/**
 * Acepta URLs completas, enlaces tel:/mailto: y anclas (#seccion).
 *
 * @param string $value Valor escrito.
 * @return string
 */
function vg7_sanitize_link( $value ) {
	$value = trim( (string) $value );
	if ( '' === $value || 0 === strpos( $value, '#' ) ) {
		return sanitize_text_field( $value );
	}
	return esc_url_raw( $value, array( 'http', 'https', 'tel', 'mailto' ) );
}
