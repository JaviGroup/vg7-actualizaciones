<?php
/**
 * API de bloques para los plugins de cada sitio.
 *
 * En el plugin del sitio (los plugins cargan antes que el tema, por eso va dentro de "init"):
 *
 *   add_action( 'init', function () {
 *       if ( function_exists( 'vg7_register_blocks' ) ) {
 *           vg7_register_blocks( __DIR__ . '/bloques', array( 'slug' => 'vg7-wireless', 'title' => 'Viva Wireless' ) );
 *       }
 *   } );
 */

defined( 'ABSPATH' ) || exit;

/**
 * Nombres de los bloques registrados con vg7_register_blocks().
 *
 * @param string|null $add Nombre a añadir (uso interno).
 * @return string[]
 */
function vg7_block_names( $add = null ) {
	static $names = array();
	if ( $add ) {
		$names[] = $add;
	}
	return $names;
}

/**
 * Categorías del insertador añadidas por los plugins.
 *
 * @param array|null $add array( 'slug' => ..., 'title' => ... ) (uso interno).
 * @return array
 */
function vg7_block_categories( $add = null ) {
	static $cats = array();
	if ( $add && ! empty( $add['slug'] ) ) {
		$cats[ $add['slug'] ] = $add;
	}
	return $cats;
}

/**
 * Registra todos los bloques de una carpeta (cada subcarpeta con su block.json).
 *
 * @param string $dir      Carpeta con los bloques.
 * @param array  $category Categoría del insertador: array( 'slug' => ..., 'title' => ... ).
 * @return string[] Nombres registrados.
 */
function vg7_register_blocks( $dir, $category = array() ) {
	if ( $category ) {
		vg7_block_categories( $category );
	}
	$registered = array();
	foreach ( (array) glob( trailingslashit( $dir ) . '*/block.json' ) as $block_json ) {
		$type = register_block_type( dirname( $block_json ) );
		if ( $type ) {
			vg7_block_names( $type->name );
			$registered[] = $type->name;
		}
	}
	return $registered;
}

/**
 * Bloques genéricos del tema padre (vg7-theme/bloques), si los hay.
 */
function vg7_register_theme_blocks() {
	if ( is_dir( VG7_DIR . '/bloques' ) ) {
		vg7_register_blocks(
			VG7_DIR . '/bloques',
			array(
				'slug'  => 'vg7',
				'title' => __( 'VG7: secciones', 'vg7' ),
			)
		);
	}
}
add_action( 'init', 'vg7_register_theme_blocks' );

/**
 * Categorías al principio del insertador.
 *
 * @param array $categories Categorías de WordPress.
 * @return array
 */
function vg7_inserter_categories( $categories ) {
	foreach ( array_reverse( vg7_block_categories() ) as $cat ) {
		array_unshift(
			$categories,
			array(
				'slug'  => $cat['slug'],
				'title' => $cat['title'],
			)
		);
	}
	return $categories;
}
add_filter( 'block_categories_all', 'vg7_inserter_categories' );

/**
 * ¿El contenido usa algún bloque VG7? Entonces la página va a ancho completo y sin título
 * (las secciones traen su propio diseño) y se prepara el motor de animaciones.
 *
 * @param int|WP_Post|null $post Entrada (por defecto, la actual).
 * @return bool
 */
function vg7_page_has_blocks( $post = null ) {
	if ( null === $post && ! is_singular() ) {
		return false;
	}
	$post = get_post( $post );
	if ( ! $post ) {
		return false;
	}
	foreach ( vg7_block_names() as $name ) {
		if ( has_block( $name, $post ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Atributos del contenedor de una sección: clases, data-vg7 (animación) y el ID para el menú.
 *
 * @param array  $attributes Campos del bloque.
 * @param string $name       Nombre de la animación (data-vg7). Vacío = sin animación.
 * @param string $class      Clases de la sección.
 * @return string
 */
function vg7_section_attrs( $attributes, $name, $class ) {
	$extra = array( 'class' => trim( 'vg7-section ' . $class ) );
	if ( $name ) {
		$extra['data-vg7'] = $name;
	}
	if ( ! empty( $attributes['sectionId'] ) ) {
		$extra['id'] = sanitize_title( $attributes['sectionId'] );
	}
	return get_block_wrapper_attributes( $extra );
}
