<?php
/**
 * Menús de Apariencia → Menús como árbol, para que el header y el footer los pinten a su manera.
 * Si una ubicación no tiene menú, se usa el del filtro vg7_default_menu (vacío por defecto).
 */

defined( 'ABSPATH' ) || exit;

/**
 * Devuelve el menú como árbol: [ ['title','url','children'=>[...]], ... ].
 *
 * @param string $location Ubicación del menú.
 * @return array
 */
function vg7_menu_tree( $location ) {
	$locations = get_nav_menu_locations();
	$items     = empty( $locations[ $location ] ) ? array() : wp_get_nav_menu_items( $locations[ $location ] );
	if ( ! $items ) {
		return apply_filters( 'vg7_default_menu', array(), $location );
	}
	$by_parent = array();
	foreach ( $items as $item ) {
		$by_parent[ (int) $item->menu_item_parent ][] = $item;
	}
	$build = function ( $parent ) use ( &$build, $by_parent ) {
		$out = array();
		if ( empty( $by_parent[ $parent ] ) ) {
			return $out;
		}
		foreach ( $by_parent[ $parent ] as $item ) {
			$out[] = array(
				'title'    => $item->title,
				'url'      => $item->url,
				'children' => $build( (int) $item->ID ),
			);
		}
		return $out;
	};
	return $build( 0 );
}
