<?php
/**
 * Páginas. Si la página usa bloques VG7 va a ancho completo y sin título (cada sección trae
 * su propio diseño y su H1 lo pone el primer bloque); si no, se muestra como página de texto.
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="principal" class="vg7-main">
	<?php
	while ( have_posts() ) :
		the_post();
		if ( vg7_page_has_blocks() ) :
			?>
			<div class="vg7-blocks"><?php the_content(); ?></div>
		<?php else : ?>
			<article class="vg7-wrap vg7-page">
				<h1 class="vg7-page-title"><?php the_title(); ?></h1>
				<div class="vg7-prose"><?php the_content(); ?></div>
			</article>
		<?php endif; ?>
	<?php endwhile; ?>
</main>
<?php
get_footer();
