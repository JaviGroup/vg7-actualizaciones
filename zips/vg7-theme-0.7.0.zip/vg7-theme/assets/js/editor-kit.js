/**
 * VG7 Theme: kit del editor.
 *
 * Cada bloque declara sus campos y el kit arma la barra lateral y la vista previa real (render.php):
 *
 *   VG7Editor.register('vg7-wireless/faq', [
 *     { title: 'Encabezado', fields: [
 *       { key: 'title', label: 'Título', type: 'textarea' },
 *       { key: 'image', label: 'Imagen', type: 'image' }          // guarda imageId + imageUrl
 *     ]},
 *     { title: 'Preguntas', fields: [
 *       { key: 'items', type: 'repeater', itemLabel: 'Pregunta', titleKey: 'q', add: { q: 'Nueva pregunta' },
 *         fields: [ { key: 'q', label: 'Pregunta' }, { key: 'a', label: 'Respuesta', type: 'textarea' } ] }
 *     ]}
 *   ]);
 *
 * Tipos: text (por defecto), textarea, url, number, toggle, select (options), image, repeater.
 * Campos listos: VG7Editor.SECTION_ID (ancla para el menú) y VG7Editor.HEADING (nivel del título).
 */
(function (wp) {
	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var be = wp.blockEditor;
	var c = wp.components;
	var ServerSideRender = wp.serverSideRender;

	var SIZE = { __nextHasNoMarginBottom: true, __next40pxDefaultSize: true };

	function gap() { return el('div', { style: { height: 12 } }); }

	function imageControl(label, id, url, onChange) {
		return el('div', null,
			el('p', { style: { margin: '0 0 8px', fontSize: 11, fontWeight: 500, textTransform: 'uppercase' } }, label),
			el(be.MediaUploadCheck, null,
				el(be.MediaUpload, {
					allowedTypes: ['image'],
					value: id,
					onSelect: function (m) { onChange(m.id, m.url); },
					render: function (o) {
						return el('div', null,
							url ? el('img', { src: url, alt: '', style: { display: 'block', width: '100%', height: 'auto', marginBottom: 8 } })
								: el('p', { style: { margin: '0 0 8px', color: '#757575' } }, 'Se muestra la imagen de prueba.'),
							el(c.Button, { variant: 'secondary', onClick: o.open }, id ? 'Cambiar imagen' : 'Elegir imagen'),
							id ? el(c.Button, { variant: 'link', isDestructive: true, style: { marginLeft: 8 }, onClick: function () { onChange(0, ''); } }, 'Quitar') : null
						);
					}
				})
			)
		);
	}

	// Un campo simple. get(key) lee y put(obj) guarda (en el bloque o en un elemento de la lista).
	function control(f, get, put) {
		var type = f.type || 'text';
		if (type === 'image') {
			return imageControl(f.label, get(f.key + 'Id'), get(f.key + 'Url'), function (id, url) {
				var o = {}; o[f.key + 'Id'] = id; o[f.key + 'Url'] = url; put(o);
			});
		}
		var set = function (v) { var o = {}; o[f.key] = type === 'number' ? Number(v) : v; put(o); };
		if (type === 'textarea') {
			return el(c.TextareaControl, { __nextHasNoMarginBottom: true, label: f.label, help: f.help, value: get(f.key) || '', rows: f.rows || 4, onChange: set });
		}
		if (type === 'toggle') {
			return el(c.ToggleControl, { __nextHasNoMarginBottom: true, label: f.label, help: f.help, checked: !!get(f.key), onChange: set });
		}
		if (type === 'select') {
			return el(c.SelectControl, Object.assign({ label: f.label, help: f.help, value: get(f.key), options: f.options, onChange: set }, SIZE));
		}
		return el(c.TextControl, Object.assign({
			label: f.label,
			help: f.help,
			type: type === 'number' ? 'number' : (type === 'url' ? 'url' : 'text'),
			value: get(f.key) == null ? '' : get(f.key),
			onChange: set
		}, SIZE));
	}

	// Lista repetible con subir, bajar, quitar y añadir
	function repeater(f, attributes, setAttributes) {
		var items = attributes[f.key] || [];
		function save(list) { var o = {}; o[f.key] = list; setAttributes(o); }
		function update(i, patch) {
			save(items.map(function (it, j) { return j === i ? Object.assign({}, it, patch) : it; }));
		}
		function move(i, dir) {
			var list = items.slice(); var t = list[i];
			list[i] = list[i + dir]; list[i + dir] = t; save(list);
		}
		var max = f.max || 99;
		var min = f.min || 0;

		return el('div', null,
			f.help ? el('p', { style: { marginTop: 0, color: '#757575' } }, f.help) : null,
			items.map(function (it, i) {
				var title = (f.itemLabel || 'Elemento') + ' ' + (i + 1) + (f.titleKey && it[f.titleKey] ? ': ' + String(it[f.titleKey]).slice(0, 28) : '');
				return el(c.PanelBody, { key: i, title: title, initialOpen: false },
					f.fields.map(function (sub, k) {
						return el(Fragment, { key: k },
							control(sub, function (key) { return it[key]; }, function (patch) { update(i, patch); }),
							gap()
						);
					}),
					el('div', { style: { display: 'flex', gap: 4, flexWrap: 'wrap' } },
						el(c.Button, { variant: 'tertiary', size: 'small', disabled: i === 0, onClick: function () { move(i, -1); } }, '↑ Subir'),
						el(c.Button, { variant: 'tertiary', size: 'small', disabled: i === items.length - 1, onClick: function () { move(i, 1); } }, '↓ Bajar'),
						el(c.Button, { variant: 'tertiary', size: 'small', isDestructive: true, disabled: items.length <= min, onClick: function () { save(items.filter(function (_, j) { return j !== i; })); } }, 'Quitar')
					)
				);
			}),
			items.length < max ? el('div', { style: { marginTop: 12 } },
				el(c.Button, { variant: 'secondary', onClick: function () { save(items.concat([Object.assign({}, f.add || {})])); } }, '+ Añadir ' + (f.itemLabel || 'elemento').toLowerCase())
			) : null
		);
	}

	window.VG7Editor = {
		SECTION_ID: { key: 'sectionId', label: 'ID de la sección', help: 'Para enlazarla desde el menú: si pones "planes", el enlace es #planes' },
		HEADING: { key: 'headingTag', label: 'Nivel del título', type: 'select', help: 'Solo puede haber un H1 por página (normalmente, el del primer bloque).', options: [
			{ label: 'H1 (título principal de la página)', value: 'h1' },
			{ label: 'H2 (sección)', value: 'h2' },
			{ label: 'H3 (subsección)', value: 'h3' }
		] },
		register: function (name, panels) {
			wp.blocks.registerBlockType(name, {
				edit: function (props) {
					var a = props.attributes;
					var set = props.setAttributes;
					var blockProps = be.useBlockProps();
					return el(Fragment, null,
						el(be.InspectorControls, null,
							panels.map(function (p, i) {
								return el(c.PanelBody, { key: i, title: p.title, initialOpen: i === 0 },
									p.fields.map(function (f, k) {
										return el(Fragment, { key: k },
											f.type === 'repeater' ? repeater(f, a, set) : control(f, function (key) { return a[key]; }, set),
											gap()
										);
									})
								);
							})
						),
						el('div', blockProps,
							// Vista previa real (render.php); no clicable para que los enlaces no saquen del editor
							el('div', { style: { pointerEvents: 'none' } },
								el(ServerSideRender, { block: name, attributes: a })
							)
						)
					);
				},
				save: function () { return null; }
			});
		}
	};
})(window.wp);
