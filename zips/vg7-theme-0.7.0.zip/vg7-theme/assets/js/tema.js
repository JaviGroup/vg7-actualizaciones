/**
 * VG7 Theme: se carga en todo el sitio (sin librerías).
 * - Menús desplegables y menú móvil
 * - Enlaces con texto que sube (data-vg7-froll, solo CSS)
 * - Enlaces internos (#seccion) compensando el header fijo
 * - Medición: VG7Track.event(nombre, datos) y clics con data-vg7-track
 */
(function () {
	// ---------- Medición (GA4 con gtag o GTM con dataLayer, y Píxel de Meta) ----------
	function trackEvent(name, params) {
		params = params || {};
		if (typeof window.gtag === 'function') window.gtag('event', name, params);
		else if (Array.isArray(window.dataLayer)) window.dataLayer.push(Object.assign({ event: name }, params));
		if (typeof window.fbq === 'function' && name === 'generate_lead') window.fbq('track', 'Lead');
	}
	window.VG7Track = { event: trackEvent };

	document.addEventListener('click', function (e) {
		var el = e.target.closest && e.target.closest('[data-vg7-track]');
		if (!el) return;
		var params = {};
		if (el.dataset.vg7Ubicacion) params.ubicacion = el.dataset.vg7Ubicacion;
		if (el.dataset.vg7Valor) params.valor = el.dataset.vg7Valor;
		trackEvent(el.dataset.vg7Track, params);
	});

	// ---------- Texto que sube (dos copias; la segunda oculta para lectores de pantalla) ----------
	document.querySelectorAll('[data-vg7-froll]').forEach(function (el) {
		var t = el.textContent;
		el.textContent = '';
		var a = document.createElement('span'); a.textContent = t;
		var b = document.createElement('span'); b.textContent = t; b.setAttribute('aria-hidden', 'true');
		el.appendChild(a); el.appendChild(b);
	});

	// ---------- Menús desplegables ----------
	document.querySelectorAll('.vg7-dd').forEach(function (dd) {
		var btn = dd.querySelector('[data-vg7-dd]');
		var timer;
		var hoverOpenedAt = 0;
		function set(open) {
			if (open) dd.setAttribute('data-open', ''); else dd.removeAttribute('data-open');
			btn.setAttribute('aria-expanded', String(open));
		}
		// Con ratón, el hover ya lo abrió: el clic que sigue no debe cerrarlo
		btn.addEventListener('click', function () {
			if (Date.now() - hoverOpenedAt < 600) return;
			set(!dd.hasAttribute('data-open'));
		});
		dd.addEventListener('pointerenter', function (e) {
			if (e.pointerType !== 'mouse') return;
			clearTimeout(timer);
			if (!dd.hasAttribute('data-open')) hoverOpenedAt = Date.now();
			set(true);
		});
		dd.addEventListener('pointerleave', function (e) {
			if (e.pointerType !== 'mouse') return;
			timer = setTimeout(function () { set(false); }, 120);
		});
		document.addEventListener('click', function (e) { if (!dd.contains(e.target)) set(false); });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape') set(false); });
	});

	// ---------- Menú móvil ----------
	var menuBtn = document.querySelector('[data-vg7-menu-btn]');
	var menu = document.getElementById('vg7-menu-movil');
	function setMenu(open) {
		if (!menu || !menuBtn) return;
		menu.hidden = !open;
		menuBtn.setAttribute('aria-expanded', String(open));
		menuBtn.setAttribute('aria-label', open ? menuBtn.dataset.labelClose : menuBtn.dataset.labelOpen);
		menuBtn.querySelector('[data-icon-open]').hidden = open;
		menuBtn.querySelector('[data-icon-close]').hidden = !open;
		document.documentElement.classList.toggle('vg7-menu-open', open);
	}
	if (menuBtn && menu) {
		menuBtn.addEventListener('click', function () { setMenu(menu.hidden); });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
		menu.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
		window.matchMedia('(min-width: 1024px)').addEventListener('change', function (m) { if (m.matches) setMenu(false); });
	}

	// ---------- Enlaces internos ----------
	// Si el motor de animaciones está activo (Lenis), él hace el desplazamiento suave.
	var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('a[href*="#"]');
		if (!a || a.hostname !== location.hostname || a.pathname !== location.pathname) return;
		var id = a.hash;
		if (!id || id.length < 2) return;
		var target = document.getElementById(decodeURIComponent(id.slice(1)));
		if (!target) return;
		e.preventDefault();
		var header = document.querySelector('[data-vg7-header]');
		var offset = header ? header.offsetHeight + 16 : 0;
		if (window.VG7 && window.VG7.scrollTo) {
			window.VG7.scrollTo(target, -offset);
		} else {
			var top = target.getBoundingClientRect().top + window.scrollY - offset;
			window.scrollTo({ top: top, behavior: reduce ? 'auto' : 'smooth' });
		}
		if (history.replaceState) history.replaceState(null, '', id);
		target.setAttribute('tabindex', '-1');
		target.focus({ preventScroll: true });
	});
})();
