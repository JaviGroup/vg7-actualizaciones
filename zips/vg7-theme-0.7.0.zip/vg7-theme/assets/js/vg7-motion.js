/**
 * VG7 Theme: motor de animaciones.
 * Solo se carga en páginas con bloques que lo piden (view.asset.php → 'vg7-motion').
 *
 * Cada bloque registra su animación con:
 *   VG7.register('nombre', function (el, ctx) { ... });
 * y se ejecuta una vez por cada elemento con data-vg7="nombre".
 *
 * ctx = { gsap, ScrollTrigger, hasGsap, split(el, type), motion, height(el, open, dur), refresh(), lenis }
 * Si motion es false (movimiento reducido o librerías sin cargar), el bloque solo prepara
 * su interacción, sin animar, y el contenido debe quedar visible.
 *
 * Efectos compartidos por atributos:
 *   data-vg7-head (con data-vg7-split en el título y data-vg7-after en lo que sigue)
 *   data-vg7-roll (letras que ruedan al pasar el ratón)
 */
(function () {
	var root = document.documentElement;
	var hasGsap = !!(window.gsap && window.ScrollTrigger && window.SplitText);
	var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var motion = hasGsap && !reduce;
	var registry = {};
	var lenis = null;
	var started = false;

	if (hasGsap) gsap.registerPlugin(ScrollTrigger, SplitText);

	function split(el, type) {
		return SplitText.create(el, { type: type || 'words,chars', tag: 'span' });
	}

	var refreshTimer;
	function refreshSoon() {
		if (!hasGsap) return;
		clearTimeout(refreshTimer);
		refreshTimer = setTimeout(function () { ScrollTrigger.refresh(); }, 250);
	}

	// Abre o cierra un elemento animando su altura (0 ↔ contenido). Sin GSAP, cambia al instante.
	function height(el, open, dur) {
		if (hasGsap) {
			gsap.to(el, { height: open ? 'auto' : 0, duration: motion ? dur : 0, ease: 'power2.inOut', overwrite: true, onComplete: refreshSoon });
		} else {
			el.style.height = open ? 'auto' : '0px';
		}
	}

	var ctx = {
		gsap: window.gsap,
		ScrollTrigger: window.ScrollTrigger,
		hasGsap: hasGsap,
		split: split,
		motion: motion,
		height: height,
		refresh: refreshSoon,
		lenis: null
	};

	if (!motion) root.classList.remove('vg7-motion');
	else root.classList.add('vg7-motion');

	window.VG7 = {
		motion: motion,
		register: function (name, fn) {
			registry[name] = fn;
			if (started) run(name);
		},
		refresh: function () {
			if (hasGsap) ScrollTrigger.refresh();
		},
		// Lo usa tema.js para los enlaces internos
		scrollTo: function (target, offset) {
			if (lenis) lenis.scrollTo(target, { offset: offset || 0 });
			else window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY + (offset || 0), behavior: reduce ? 'auto' : 'smooth' });
		}
	};

	function run(name) {
		document.querySelectorAll('[data-vg7="' + name + '"]').forEach(function (el) {
			if (el.__vg7Done) return;
			el.__vg7Done = true;
			try { registry[name](el, ctx); } catch (e) { console.error('[VG7] ' + name, e); }
		});
	}

	// ---------- Scroll suave ----------
	function initLenis() {
		// Un sitio puede apagar el scroll suave con el filtro vg7_lenis (window.VG7Config.lenis = false).
		if (!motion || !window.Lenis || (window.VG7Config && window.VG7Config.lenis === false)) return;
		lenis = new Lenis({
			duration: 1.3,
			easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); },
			smoothWheel: true,
			touchMultiplier: 2
		});
		ctx.lenis = lenis;
		window.VG7.lenis = lenis; // lo usan los temas hijos (por ejemplo, para pausar el scroll con el menú móvil abierto)
		lenis.on('scroll', ScrollTrigger.update);
		gsap.ticker.add(function (time) { lenis.raf(time * 1000); });
		gsap.ticker.lagSmoothing(0);
	}

	// ---------- Efectos compartidos ----------

	// Letras que ruedan + cambio de color: <span data-vg7-roll>Texto</span>
	function initRoll() {
		document.querySelectorAll('[data-vg7-roll]').forEach(function (el) {
			var t = el.textContent.trim();
			el.innerHTML = '<span class="vg7-roll-box"><span></span><span aria-hidden="true"></span></span>';
			var spans = el.querySelectorAll('.vg7-roll-box > span');
			spans[0].textContent = t;
			spans[1].textContent = t;
			if (!motion) return;
			var a = split(spans[0], 'chars');
			var b = split(spans[1], 'chars');
			var color = getComputedStyle(root).getPropertyValue('--vg7-accent').trim();
			var to = { yPercent: -100 };
			if (color) to.color = color;
			var tl = gsap.timeline({ paused: true, defaults: { duration: 0.35, ease: 'power2.inOut', stagger: { each: 0.015 } } });
			tl.to(a.chars, to, 0).to(b.chars, to, 0);
			var host = el.closest('a, button') || el;
			host.addEventListener('mouseenter', function () { tl.play(); });
			host.addEventListener('mouseleave', function () { tl.reverse(); });
			host.addEventListener('focus', function () { tl.play(); });
			host.addEventListener('blur', function () { tl.reverse(); });
		});
	}

	// Encabezados de sección: etiqueta que sube + letras del título
	function initHeads() {
		if (!motion) return;
		document.querySelectorAll('[data-vg7-head]').forEach(function (head) {
			var tl = gsap.timeline({ scrollTrigger: { trigger: head, start: 'top 90%', once: true } });
			var badge = head.querySelector('.vg7-badge');
			var title = head.querySelector('[data-vg7-split]');
			var after = head.querySelectorAll('[data-vg7-after]');
			if (badge) tl.from(badge, { opacity: 0, yPercent: 100, duration: 0.6, ease: 'power1.out' }, 0);
			if (title) {
				var s = split(title);
				tl.fromTo(s.chars, { opacity: 0, y: '60%' }, { opacity: 1, y: '0%', duration: 0.7, ease: 'power2.out', stagger: { amount: 0.8 } }, 0.19);
			}
			if (after.length) tl.from(after, { opacity: 0, yPercent: 60, duration: 0.7, ease: 'power2.out', stagger: 0.12 }, 0.6);
		});
	}

	// ---------- Arranque ----------
	function start() {
		if (started) return;
		started = true;
		initRoll();
		initHeads();
		Object.keys(registry).forEach(run);
		root.classList.add('vg7-ready');
		if (hasGsap) ScrollTrigger.refresh();
	}

	initLenis();

	if (!motion) {
		if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
		else start();
		return;
	}

	var fontsReady = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
	var go = function () {
		Promise.race([fontsReady, new Promise(function (r) { setTimeout(r, 1200); })]).then(start);
	};
	if (document.readyState === 'complete') go();
	else window.addEventListener('load', go);
	setTimeout(start, 3000);
})();
