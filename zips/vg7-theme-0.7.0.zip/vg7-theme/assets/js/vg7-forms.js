/*
 * VG7: envío de formularios al motor de solicitudes del tema (inc/formularios.php).
 *
 * - Al cargar, pide un token firmado (GET /wp-json/vg7/v1/token): prueba que el envío sale de una página real y
 *   permite medir el tiempo de llenado. Se pide en cada carga, así funciona aunque la página esté en caché.
 * - VG7Forms.send(form) envía el FormData del formulario (más la página y el token) y devuelve una promesa que
 *   resuelve { ok: true } o { ok: false, message } (message solo si lo manda el servidor, ya en español).
 *
 * Lo piden los bloques con formulario en su view.asset.php: array( 'vg7-forms' ).
 */
(function () {
	'use strict';
	var cfg = window.VG7FormsConfig || {};
	var tokenPromise = null;

	function getToken() {
		if (!tokenPromise) {
			tokenPromise = fetch(cfg.token, { headers: { Accept: 'application/json' }, cache: 'no-store', credentials: 'same-origin' })
				.then(function (r) { return r.ok ? r.json() : {}; })
				.then(function (j) { return j && j.token ? String(j.token) : ''; })
				.catch(function () { return ''; });
		}
		return tokenPromise;
	}

	function send(form) {
		return getToken().then(function (token) {
			var data = new FormData(form);
			data.append('pagina', window.location.href.split('#')[0]);
			if (token) data.append('vg7_token', token);
			return fetch(cfg.send, { method: 'POST', body: data, headers: { Accept: 'application/json' }, credentials: 'same-origin' })
				.then(function (r) {
					return r.json().catch(function () { return {}; }).then(function (j) {
						return { ok: r.ok && j.ok === true, message: j.ok === false ? j.message : undefined };
					});
				})
				.catch(function () { return { ok: false }; });
		});
	}

	window.VG7Forms = { send: send, token: getToken };
	if (document.querySelector('form[data-vg7-form]')) getToken();
})();
