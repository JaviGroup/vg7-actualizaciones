<?php
/**
 * Página no encontrada.
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="principal" class="vg7-main vg7-wrap vg7-page">
	<p class="vg7-eyebrow">404</p>
	<h1 class="vg7-page-title"><?php esc_html_e( 'No encontramos esta página', 'vg7' ); ?></h1>
	<p><?php esc_html_e( 'Puede que el enlace haya cambiado. Vuelve al inicio o usa el menú.', 'vg7' ); ?></p>
	<div class="vg7-actions"><?php echo vg7_button( array( 'label' => __( 'Ir al inicio', 'vg7' ), 'url' => home_url( '/' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
</main>
<?php
get_footer();
