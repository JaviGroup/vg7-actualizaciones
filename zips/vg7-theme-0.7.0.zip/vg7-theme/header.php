<?php
/**
 * Header del sitio. El tema hijo puede reemplazarlo con su propio header.php
 * o solo cambiar su aspecto con CSS (clases vg7-header-*).
 */

defined( 'ABSPATH' ) || exit;

$vg7_menu  = vg7_menu_tree( 'principal' );
$vg7_phone = vg7_opt( 'phone' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a href="#principal" class="vg7-skip"><?php esc_html_e( 'Saltar al contenido', 'vg7' ); ?></a>

<header class="vg7-header" data-vg7-header>
	<div class="vg7-wrap vg7-header-bar">
		<?php echo vg7_logo(); // phpcs:ignore WordPress.Security.EscapeOutput -- escapado en vg7_logo(). ?>

		<?php if ( $vg7_menu ) : ?>
			<nav class="vg7-nav" aria-label="<?php esc_attr_e( 'Principal', 'vg7' ); ?>">
				<?php foreach ( $vg7_menu as $vg7_i => $vg7_item ) : ?>
					<?php if ( ! empty( $vg7_item['children'] ) ) : ?>
						<div class="vg7-dd">
							<button type="button" class="vg7-nav-link" aria-expanded="false" aria-controls="vg7-dd-<?php echo (int) $vg7_i; ?>" data-vg7-dd>
								<span class="vg7-froll" data-vg7-froll><?php echo esc_html( $vg7_item['title'] ); ?></span>
								<?php echo vg7_icon( 'chev', 'vg7-dd-chev' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</button>
							<div id="vg7-dd-<?php echo (int) $vg7_i; ?>" class="vg7-dd-panel">
								<?php foreach ( $vg7_item['children'] as $vg7_child ) : ?>
									<a href="<?php echo esc_url( $vg7_child['url'] ); ?>"><?php echo esc_html( $vg7_child['title'] ); ?></a>
								<?php endforeach; ?>
							</div>
						</div>
					<?php else : ?>
						<a class="vg7-nav-link" href="<?php echo esc_url( $vg7_item['url'] ); ?>"><span class="vg7-froll" data-vg7-froll><?php echo esc_html( $vg7_item['title'] ); ?></span></a>
					<?php endif; ?>
				<?php endforeach; ?>
			</nav>
		<?php endif; ?>

		<div class="vg7-header-actions">
			<?php if ( $vg7_phone ) : ?>
				<a class="vg7-nav-link vg7-header-phone" href="<?php echo esc_url( vg7_opt( 'phone_link' ), array( 'tel', 'http', 'https' ) ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="header">
					<?php echo vg7_icon( 'phone', 'vg7-icon-sm' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<span class="vg7-froll" data-vg7-froll><?php echo esc_html( $vg7_phone ); ?></span>
				</a>
			<?php endif; ?>
			<?php
			echo vg7_button( // phpcs:ignore WordPress.Security.EscapeOutput
				array(
					'label'   => vg7_opt( 'cta_label' ),
					'url'     => vg7_opt( 'cta_url' ),
					'variant' => 'dark',
					'size'    => 'sm',
					'icon'    => 'arrow',
					'class'   => 'vg7-header-cta',
				)
			);
			?>
			<button type="button" class="vg7-menu-btn" aria-expanded="false" aria-controls="vg7-menu-movil" aria-label="<?php esc_attr_e( 'Abrir menú', 'vg7' ); ?>" data-vg7-menu-btn data-label-open="<?php esc_attr_e( 'Abrir menú', 'vg7' ); ?>" data-label-close="<?php esc_attr_e( 'Cerrar menú', 'vg7' ); ?>">
				<span data-icon-open><?php echo vg7_icon( 'menu', 'vg7-icon-md' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
				<span data-icon-close hidden><?php echo vg7_icon( 'x', 'vg7-icon-md' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			</button>
		</div>
	</div>

	<div id="vg7-menu-movil" class="vg7-menu-movil" hidden data-lenis-prevent>
		<nav class="vg7-wrap" aria-label="<?php esc_attr_e( 'Menú móvil', 'vg7' ); ?>">
			<?php foreach ( $vg7_menu as $vg7_item ) : ?>
				<?php if ( ! empty( $vg7_item['children'] ) ) : ?>
					<p class="vg7-eyebrow vg7-menu-movil-group"><?php echo esc_html( $vg7_item['title'] ); ?></p>
					<div class="vg7-menu-movil-sub">
						<?php foreach ( $vg7_item['children'] as $vg7_child ) : ?>
							<a href="<?php echo esc_url( $vg7_child['url'] ); ?>"><?php echo esc_html( $vg7_child['title'] ); ?></a>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<a class="vg7-menu-movil-link" href="<?php echo esc_url( $vg7_item['url'] ); ?>"><?php echo esc_html( $vg7_item['title'] ); ?></a>
				<?php endif; ?>
			<?php endforeach; ?>
			<?php if ( $vg7_phone ) : ?>
				<a class="vg7-menu-movil-link vg7-menu-movil-phone" href="<?php echo esc_url( vg7_opt( 'phone_link' ), array( 'tel', 'http', 'https' ) ); ?>" data-vg7-track="clic_llamar" data-vg7-ubicacion="menu_movil"><?php echo esc_html( $vg7_phone ); ?></a>
			<?php endif; ?>
			<?php echo vg7_button( array( 'label' => vg7_opt( 'cta_label' ), 'url' => vg7_opt( 'cta_url' ), 'icon' => 'arrow', 'class' => 'vg7-menu-movil-cta' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</nav>
	</div>
</header>
