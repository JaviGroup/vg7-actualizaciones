<?php
/**
 * Plantilla general: entradas, blog, archivos y búsqueda.
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="principal" class="vg7-main vg7-wrap vg7-page">
	<?php if ( is_singular() ) : ?>
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article>
				<h1 class="vg7-page-title"><?php the_title(); ?></h1>
				<p class="vg7-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></p>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="vg7-featured"><?php the_post_thumbnail( 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?></div>
				<?php endif; ?>
				<div class="vg7-prose"><?php the_content(); ?></div>
			</article>
		<?php endwhile; ?>

	<?php elseif ( have_posts() ) : ?>
		<h1 class="vg7-page-title">
			<?php
			if ( is_home() && ! is_front_page() ) {
				single_post_title();
			} elseif ( is_search() ) {
				/* translators: %s: término buscado */
				printf( esc_html__( 'Resultados para "%s"', 'vg7' ), esc_html( get_search_query() ) );
			} elseif ( is_archive() ) {
				the_archive_title();
			} else {
				esc_html_e( 'Novedades', 'vg7' );
			}
			?>
		</h1>
		<div class="vg7-cards">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article class="vg7-card">
					<?php if ( has_post_thumbnail() ) : ?>
						<a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php the_post_thumbnail( 'medium_large', array( 'class' => 'vg7-card-img' ) ); ?></a>
					<?php endif; ?>
					<div class="vg7-card-body">
						<p class="vg7-meta"><?php echo esc_html( get_the_date() ); ?></p>
						<h2 class="vg7-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></p>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
		<div class="vg7-pagination"><?php the_posts_pagination(); ?></div>

	<?php else : ?>
		<h1 class="vg7-page-title"><?php esc_html_e( 'No encontramos resultados', 'vg7' ); ?></h1>
		<p><?php esc_html_e( 'Prueba con otra búsqueda o vuelve al inicio.', 'vg7' ); ?></p>
		<div class="vg7-actions"><?php echo vg7_button( array( 'label' => __( 'Ir al inicio', 'vg7' ), 'url' => home_url( '/' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
	<?php endif; ?>
</main>
<?php
get_footer();
