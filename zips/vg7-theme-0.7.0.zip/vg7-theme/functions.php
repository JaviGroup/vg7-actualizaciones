<?php
/**
 * VG7 Theme: tema padre.
 *
 * inc/setup.php    soportes del tema, menús y estilos del editor
 * inc/assets.php   CSS, JS del tema, motor de animaciones y kit del editor
 * inc/datos.php    datos del sitio (Apariencia → Personalizar → Datos del sitio)
 * inc/menus.php    menús como árbol
 * inc/helpers.php  iconos, botón, logo e imágenes
 * inc/bloques.php  API para que los plugins registren sus bloques
 * inc/formularios.php  solicitudes: endpoint, guardado, correo y CSV
 * inc/compartir.php  imagen y etiquetas Open Graph al compartir el enlace
 * inc/actualizaciones.php  avisos de actualización en el panel (JSON en GitHub) para el tema, el hijo y los plugins vg7-*
 */

defined( 'ABSPATH' ) || exit;

define( 'VG7_VERSION', '0.7.0' );
define( 'VG7_DIR', get_template_directory() );
define( 'VG7_URL', get_template_directory_uri() );

require_once VG7_DIR . '/inc/setup.php';
require_once VG7_DIR . '/inc/assets.php';
require_once VG7_DIR . '/inc/datos.php';
require_once VG7_DIR . '/inc/menus.php';
require_once VG7_DIR . '/inc/helpers.php';
require_once VG7_DIR . '/inc/bloques.php';
require_once VG7_DIR . '/inc/formularios.php';
require_once VG7_DIR . '/inc/compartir.php';
require_once VG7_DIR . '/inc/actualizaciones.php';
