<?php
/**
 * Plugin Name:       VG7 Seguridad
 * Description:       Endurecimiento básico para los sitios VG7: cabeceras de seguridad (HSTS, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, X-Frame-Options), XML-RPC apagado, versión de WordPress oculta, listado de usuarios bloqueado y mensaje de login genérico. Sirve para cualquier tema; no cambia el diseño ni guarda datos.
 * Version:           0.1.0
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Author:            Javier Martínez
 * License:           GPL-2.0-or-later
 * Text Domain:       vg7-seguridad
 *
 * Lo que NO hace (va en el hosting, en wp-config.php o en un plugin de seguridad): firewall, escaneo de malware, límite de intentos de
 * login, 2FA, copias de seguridad y la política CSP (cada sitio carga sus propios scripts de medición).
 */

defined( 'ABSPATH' ) || exit;

define( 'VG7S_VERSION', '0.1.0' );

// Con DISALLOW_FILE_EDIT nadie puede editar el código de temas y plugins desde el panel (lo ideal es ponerlo también en wp-config.php).
if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
	define( 'DISALLOW_FILE_EDIT', true );
}

/**
 * Cabeceras de seguridad. Se pueden cambiar o quitar con el filtro vg7_seguridad_cabeceras (nombre => valor; un valor vacío quita la cabecera).
 *
 * - X-Frame-Options SAMEORIGIN: la página solo se puede incrustar en el mismo sitio (el editor y el Personalizador de WordPress lo necesitan).
 * - HSTS solo con HTTPS. Sin "preload" a propósito (inscribir el dominio en esa lista es difícil de deshacer).
 * - Permissions-Policy apaga cámara, micrófono, ubicación, pagos y USB, que estos sitios no usan.
 */
function vg7s_cabeceras() {
	$headers = array(
		'X-Content-Type-Options' => 'nosniff',
		'X-Frame-Options'        => 'SAMEORIGIN',
		'Referrer-Policy'        => 'strict-origin-when-cross-origin',
		'Permissions-Policy'     => 'camera=(), microphone=(), geolocation=(), payment=(), usb=()',
	);
	if ( is_ssl() ) {
		$headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
	}
	return (array) apply_filters( 'vg7_seguridad_cabeceras', $headers );
}

function vg7s_enviar_cabeceras() {
	if ( headers_sent() ) {
		return;
	}
	foreach ( vg7s_cabeceras() as $name => $value ) {
		if ( '' !== (string) $value ) {
			header( $name . ': ' . $value );
		}
	}
}
add_action( 'send_headers', 'vg7s_enviar_cabeceras' );
add_action( 'admin_init', 'vg7s_enviar_cabeceras' );
add_action( 'login_init', 'vg7s_enviar_cabeceras' );

/**
 * XML-RPC apagado (lo usan los ataques de fuerza bruta y de pingback). Si un sitio necesita la app móvil de WordPress o Jetpack,
 * se reactiva con: add_filter( 'vg7_seguridad_xmlrpc', '__return_true' );
 */
function vg7s_xmlrpc() {
	if ( apply_filters( 'vg7_seguridad_xmlrpc', false ) ) {
		return;
	}
	// Una petición directa a xmlrpc.php se corta aquí (si no, WordPress sigue contestando system.listMethods y system.multicall).
	if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
		status_header( 403 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo 'XML-RPC desactivado.';
		exit;
	}
	add_filter( 'xmlrpc_enabled', '__return_false' );
	add_filter( 'xmlrpc_methods', '__return_empty_array' );
	add_filter(
		'wp_headers',
		function ( $headers ) {
			unset( $headers['X-Pingback'] );
			return $headers;
		}
	);
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
}
add_action( 'init', 'vg7s_xmlrpc' );

/**
 * Versión de WordPress oculta: sin la etiqueta generator (HTML y feeds) y sin ?ver= de la versión de WordPress en los archivos de estilos y
 * scripts del núcleo. Los ?ver= de temas y plugins se dejan, porque sirven para que el navegador baje el archivo nuevo al actualizar.
 */
add_filter( 'the_generator', '__return_empty_string' );
remove_action( 'wp_head', 'wp_generator' );

function vg7s_quitar_version_wp( $src ) {
	if ( is_string( $src ) && false !== strpos( $src, 'ver=' ) ) {
		$parts = wp_parse_url( $src );
		if ( ! empty( $parts['query'] ) ) {
			parse_str( $parts['query'], $query );
			if ( isset( $query['ver'] ) && get_bloginfo( 'version' ) === $query['ver'] ) {
				return remove_query_arg( 'ver', $src );
			}
		}
	}
	return $src;
}
add_filter( 'style_loader_src', 'vg7s_quitar_version_wp', 20 );
add_filter( 'script_loader_src', 'vg7s_quitar_version_wp', 20 );

/**
 * Listado de usuarios bloqueado para quien no ha iniciado sesión: REST (/wp-json/wp/v2/users), ?author=N, la página de autor y el mapa del sitio.
 */
function vg7s_rest_usuarios( $endpoints ) {
	if ( ! is_user_logged_in() ) {
		foreach ( array_keys( $endpoints ) as $route ) {
			if ( 0 === strpos( $route, '/wp/v2/users' ) ) {
				unset( $endpoints[ $route ] );
			}
		}
	}
	return $endpoints;
}
add_filter( 'rest_endpoints', 'vg7s_rest_usuarios' );

function vg7s_bloquear_autores() {
	if ( is_user_logged_in() || is_admin() ) {
		return;
	}
	$author_param = isset( $_GET['author'] ) ? sanitize_text_field( wp_unslash( $_GET['author'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- solo se lee para bloquear la consulta.
	if ( '' !== $author_param || is_author() ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'vg7s_bloquear_autores', 1 );

function vg7s_sitemap_sin_usuarios( $provider, $name ) {
	return 'users' === $name ? false : $provider;
}
add_filter( 'wp_sitemaps_add_provider', 'vg7s_sitemap_sin_usuarios', 10, 2 );

/**
 * Login con un mensaje genérico: no dice si el usuario existe o si fue la contraseña lo que falló.
 */
function vg7s_error_login() {
	return __( 'Los datos de acceso no son correctos.', 'vg7-seguridad' );
}
add_filter( 'login_errors', 'vg7s_error_login' );
